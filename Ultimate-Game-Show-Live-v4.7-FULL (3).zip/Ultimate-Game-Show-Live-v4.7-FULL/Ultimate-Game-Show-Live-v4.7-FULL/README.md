# Ultimate Game Show Live V4.7

Live interactive wheel game with separate host, TV audience, and mobile contestant interfaces.

Start with [V4.7_START_HERE.md](V4.7_START_HERE.md). On Windows, extract the full release and run `START_GAME.bat`.

## Main files

- `index.html` — host controller
- `audience.html` — fullscreen TV display
- `remote-controller/index.html` — phone controller source
- `js/app.js` — game flow and scoring
- `js/buzzer.js` — WebRTC phone/session host
- `js/spotify.js` — Spotify OAuth PKCE and playback ducking
- `js/v4-content.js` — visual-theme registry
- `js/core-puzzles.js` — 1,000-puzzle everyday library
- `puzzle-packs/theme-addons.js` — optional themed add-ons
- `tests/validate_build.py` — release validation

The app is static and must be served over HTTP. The included launch scripts start the complete game locally at `http://127.0.0.1:8765/index.html`. Only the contents of `remote-controller` should be published to the public GitHub Pages controller repository. The Spotify callback also uses the local `127.0.0.1` host address shown in the game settings.
