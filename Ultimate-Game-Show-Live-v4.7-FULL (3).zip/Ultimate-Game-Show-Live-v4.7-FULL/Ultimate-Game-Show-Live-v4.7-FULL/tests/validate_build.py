#!/usr/bin/env python3
from html.parser import HTMLParser
from pathlib import Path
import re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]
class Scan(HTMLParser):
    def __init__(self): super().__init__(); self.ids=[]; self.refs=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.append(a['id'])
        for key in ('src','href'):
            v=a.get(key,'').split('?')[0]
            if v and not re.match(r'^(?:https?:|data:|#)',v):self.refs.append(v)

for name in ('index.html','audience.html','remote-controller/index.html'):
    p=ROOT/name;s=Scan();s.feed(p.read_text(encoding='utf-8'))
    dup={x for x in s.ids if s.ids.count(x)>1}
    if dup:errors.append(f'{name}: duplicate ids {sorted(dup)}')
    for ref in s.refs:
        target=(p.parent/ref).resolve()
        if not target.exists():errors.append(f'{name}: missing asset {ref}')

required=['solve-modal','btn-fullscreen-live','btn-skip-bonus','spotify-bar','spotify-device','btn-spotify-dock','native-media-panel','host-command-dock','btn-start-round','btn-audience-relaunch','setup-puzzle-theme','setup-puzzle-category','btn-player-moderation','btn-manage-leaderboard','btn-clear-leaderboard-title','btn-tv-settings','tv-settings-panel','btn-tv-top25']
host=(ROOT/'index.html').read_text(encoding='utf-8')
for item in required:
    if f'id="{item}"' not in host:errors.append(f'missing host control {item}')
app=(ROOT/'js/app.js').read_text(encoding='utf-8')
remote=(ROOT/'remote-controller/index.html').read_text(encoding='utf-8')
aud=(ROOT/'audience.html').read_text(encoding='utf-8')
for marker in ('boardRows','revealRSTLNESequential','audience-bonus-cards','exportLeaderboardJpeg','wheel-game-audio-start','audience-leaderboard','wheel-audience-message','onProfileUpdate','isSensiblePuzzle','drawQueuedPuzzles','ugslPuzzleQueueV47','UGSL_THEME_PACKS'):
    if marker not in app:errors.append(f'app integration missing {marker}')
for marker in ('boardRows','DISCONNECT / JOIN NEW GAME','selectedAlert',"'chosen':'faded'",'avatarEmoji','EDIT NAME / PHOTO','profile-update','applyBuzzFeedback','tossup-locked','phoneWheel','session-reset','heartbeatTimer','wildCardCounts','sessionId','protocolVersion:47','gestureId','spin-accepted'):
    if marker not in remote:errors.append(f'mobile integration missing {marker}')
for marker in ('audBonusCards','audBonusPrize','leaderQR','leaderPageLabel','paintLeaderboardPage','leaderNeonChase','leaderNeonColor','audIntroAudio','bonusFlip','selectionWinChime','drawAvatar','audLiveMessage','television-safe audience canvas','one fixed 16:9 television canvas','audBuzzStrobe','fitAudienceBoard','bonus-prize-status','hideBonusCards'):
    if marker not in aud:errors.append(f'audience integration missing {marker}')
if '<audio id="introAudio"' in host:errors.append('intro audio still routed through host')
if "assets/audio/custom/intro-theme.mp3" not in aud:errors.append('audience intro soundtrack missing')
css=(ROOT/'css/styles.css').read_text(encoding='utf-8')
for marker in ('V4.4 EMERGENCY LAYOUT HOTFIX',"grid-template-areas:'wheel puzzle tools'",'.tossup-dock-start'):
    if marker not in css:errors.append(f'V4.4 layout safeguard missing {marker}')
for asset in ('toss_up_solve.mp3','toss_up_music.mp3','speed_up.mp3','RSTLNE.mp3','puzzle_solve.mp3','ding.mp3','countdown.mp3','buzzer.mp3','bankrupt.mp3'):
    if not (ROOT/'assets/audio/custom'/asset).exists():errors.append(f'missing custom audio {asset}')

for asset in ('CREATE_DESKTOP_SHORTCUT.bat','assets/branding/ultimate-game-show-logo.ico'):
    if not (ROOT/asset).exists():errors.append(f'missing launcher asset {asset}')

for theme in ('hollywood','easter','summer','beach','patriotic','vegas'):
    if f'assets/themes/{theme}-tile.svg' not in (ROOT/'js/v4-content.js').read_text(encoding='utf-8'):
        errors.append(f'missing paired tile mapping for {theme}')

for js in ('js/app.js','js/buzzer.js','js/spotify.js','js/media-player.js','js/v4-content.js','js/core-puzzles.js','puzzle-packs/theme-addons.js'):
    r=subprocess.run(['node','--check',str(ROOT/js)],capture_output=True,text=True)
    if r.returncode:errors.append(f'{js}: {r.stderr.strip()}')

for html in ('index.html','audience.html','controller.html','remote-controller/index.html'):
    source=(ROOT/html).read_text(encoding='utf-8')
    for i,match in enumerate(re.finditer(r'<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)</script>',source,re.I)):
        code=match.group(1)
        if not code.strip():continue
        r=subprocess.run(['node','--check','-'],input=code,capture_output=True,text=True)
        if r.returncode:errors.append(f'{html}: inline script {i+1}: {r.stderr.strip()}')

core_check=subprocess.run(['node','-e',"global.window={};require('./js/core-puzzles.js');const p=window.UGSL_CORE_PUZZLES||[];if(p.length!==1000)process.exit(2);if(new Set(p.map(x=>x.id)).size!==1000)process.exit(3);if(new Set(p.map(x=>x.text)).size!==1000)process.exit(4);if(p.some(x=>x.theme!=='general'||x.text.length>42||!/^[A-Z0-9 &'!?-]+$/.test(x.text)||/ENJOYING THE NEON BOULEVARD/.test(x.text)))process.exit(5)"],cwd=ROOT,capture_output=True,text=True)
if core_check.returncode:errors.append(f'core puzzle library validation failed ({core_check.returncode})')
content=(ROOT/'js/v4-content.js').read_text(encoding='utf-8')
if 'WHEEL_V4_PUZZLES' in content or 'UGSL_THEME_PACKS' in content:errors.append('theme puzzle content leaked into core visual registry')
if re.search(r"TOTALLY AWESOME|CASSETTE MIXTAPE|TROPICAL ISLAND GETAWAY|CHRISTMAS TREE ORNAMENT",app):errors.append('theme puzzle content leaked into core app logic')

if errors:
    print('\n'.join('FAIL: '+x for x in errors));sys.exit(1)
print('PASS: HTML ids/assets, required integrations, audio mapping, and JavaScript syntax')
