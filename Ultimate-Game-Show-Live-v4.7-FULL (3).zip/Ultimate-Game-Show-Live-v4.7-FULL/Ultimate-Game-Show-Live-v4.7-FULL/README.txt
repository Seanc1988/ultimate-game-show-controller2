VERSION 3 LIVE SHOW BUILD: Read VERSION_3_READ_ME.txt first for the audience
display, show intro, remote-controller option, host console, and soundboard.

COMPETITIVE QA UPDATE: Read QA-UPDATE.txt for revised turn rules, phone
buzzer behavior, recovery limits, and the pre-event checklist.

VERSION 4 IMPORTANT: Read V4_START_HERE.txt first. Launch with START_GAME.bat
(Windows) or START_GAME.command (Mac); do not open index.html directly when using
the audience display or phone controllers.

==============================================================
  INTERACTIVE WHEEL GAME — A Custom Wheel Party Game
  Browser party game · No install · Works offline
==============================================================

👉 NEW HERE? Open START_HERE.html first.

WHAT TO OPEN
------------
  index.html        ← The game. Double-click to play.
  START_HERE.html   ← Quick start guide (open in browser).
  USER_GUIDE.html   ← Full host manual (open in browser).
  HOST_CHEAT_SHEET.html ← One-page printable host reference.

FOLDERS
-------
  css/           Styles
  js/            Game logic
  assets/        Intro video (plays automatically)
  puzzle-packs/  5 bonus puzzle banks you can add in the editor

PUZZLE CONTENT
--------------
  • 213 built-in puzzles across many categories
  • 205 bonus pack puzzles in puzzle-packs/
  • Add packs from the editor without erasing the built-in bank

HOW TO PLAY (30 SECONDS)
------------------------
  1. Double-click index.html
  2. Pick TV Mode (a host runs it) or Hostless (type answers, auto-judged)
  3. Add your players (names, colors, avatars)
  4. Start Game — spin, call letters, and solve the puzzle!

A first-time How-to-Play guide pops up automatically and explains the
special wedges (MYSTERY, DOUBLE, WILD, FREE PLAY). You can reopen it any time from
the ? button.

When only one letter remains, solve first to bank the full value or call
the final missing letter correctly for an automatic half-value finish.

Correct solves bank at least $1,000 by default. The game explains when
that minimum solve award raises a smaller round bank.

BIG-SCREEN READY
----------------
The game auto-scales up to fill large displays — from a laptop (about
1280px wide and up) to an 80-inch 4K TV. Just open it on the display
you're casting to — no settings needed. (For very small windows or
tablets, widen the window so nothing is cut off.)
For a clean, controls-hidden display add ?tv to the address (optional).

HOST CHEAT SHEET
----------------
Open HOST_CHEAT_SHEET.html and print it or save it as a PDF. It fits on
one page and covers the live controls, special wedges, correction tools,
and phone-buzzer reminders.

GAME LENGTH PRESETS
-------------------
In the editor, use Classic Balanced for a tighter 5-round game or High-Stakes
Party for a full-length 10-round event. Ten main rounds can still continue into
a bonus or tiebreaker finale if the end-game rules call for it.

OPTIONAL: PHONE BUZZERS
-----------------------
During toss-up rounds players can buzz in from their phones. Use the
visible 📱 Connect Phone Buzzers button or the ⋯ menu, then have each player scan
their QR code. In TV Mode, each blank toss-up board waits until the host
clicks Start Toss-Up. (This feature needs an internet connection; the rest of
the game works fully offline.)

SYSTEM REQUIREMENTS
-------------------
  • A modern browser: Chrome, Edge, Safari, or Firefox
  • Works on Windows, macOS, ChromeOS, and Linux
  • No installation, no accounts (core game needs no internet)
  • Chrome is recommended on macOS; Safari is supported

PRINTING THE GUIDES TO PDF
--------------------------
  1. Open START_HERE.html, USER_GUIDE.html, or HOST_CHEAT_SHEET.html in Chrome/Edge.
  2. Press Ctrl+P (Windows) or Cmd+P (Mac).
  3. Choose "Save as PDF" and click Save.

TROUBLESHOOTING QUICK FIXES
---------------------------
  • Unzip first. Do not run the game from inside the ZIP preview.
  • Keep index.html, css/, js/, assets/, and puzzle-packs/ together.
  • If styles look broken, move the whole folder back together and reopen index.html.
  • If custom settings do not save, use Chrome/Edge and avoid private browsing.
  • Phone buzzers are optional and need internet on every device; the core game is offline.

SUPPORT
-------
Message me through the Etsy listing — I respond within 24 hours.

==============================================================
  Thanks for purchasing — and happy spinning! 🎡
==============================================================



UI AND RECOVERY UPDATE
Balanced preset: 5 rounds, $5,000 bonus, no Mystery or $5,000 wheel wedge.
High-Stakes preset: 10 rounds, $50,000 bonus, Mystery jackpot. Save to apply.
Hint price: $300 plus $150 for each distinct revealed letter type. One hint
per player per regular round; the current price is shown before purchase.
Same Letter: main words share an initial; connecting words may differ.
Before & After: expressions share a word or word part; compounds may split.
Movie Night is for teens/adults and includes mature-film references, familiar
quotes and shortened titles. Preview every pack for your group.
Resume now preserves bonus/qualifier puzzles, revealed letters, finalists,
lockouts and earned qualifier seats. Click Start Toss-Up to resume reveals.
Phones reconnect separately. Use the same browser, folder and settings.
Ordinary turn timers restart on Resume; current bonus duels have no solve countdown.
NEW IN v2.0.4
• Real CC0 crowd cheers and friendly boos at key game moments
• Low-volume suspense music for toss-ups, sudden death, and the bonus solve
• A final winner sting, automatic music ducking, and separate crowd/music controls
• See AUDIO_CREDITS.txt for source and license details
