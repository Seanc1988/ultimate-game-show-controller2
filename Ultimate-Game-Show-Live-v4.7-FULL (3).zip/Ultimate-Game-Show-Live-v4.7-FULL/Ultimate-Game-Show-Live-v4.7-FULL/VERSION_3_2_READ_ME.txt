ULTIMATE GAME SHOW LIVE — VERSION 3.2

This folder is a separate build. Version 3.1 remains unchanged.

STARTING THE GAME
1. Extract the entire ZIP to a normal folder.
2. On Windows, double-click START_GAME.bat.
3. Chrome or Edge opens the host console.
4. Before the game, click Set Up Audience Screen and move it to the TV.
5. Click FULL SCREEN inside the audience window (browsers require a click).
6. Open Contestant Sign-Up Pool to display the public sign-up QR.

PHONE CONTROLLER
The game points to:
https://seanc1988.github.io/ultimate-game-show-controller/

The public page must contain the matching V3.2 index.html for the new phone
puzzle, advantage, selection-result, special-wedge, and bonus-wheel screens.

SOUND EFFECTS
The Soundboard.com Wheel of Fortune page supplied for this build states that
its uploader does not own the recordings. Those recordings were therefore not
copied or redistributed in this package. The built-in game effects remain in
place. Licensed replacement files can be mapped to the existing sound events.

TESTING
Use V3.2_TEST_CHECKLIST.txt. Test with the exact host laptop, TV resolution,
browser, venue network, and at least one iPhone before a live event.
