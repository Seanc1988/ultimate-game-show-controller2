#!/bin/bash
cd "$(dirname "$0")"
python3 launch_game.py
