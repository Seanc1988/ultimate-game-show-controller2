@echo off
setlocal
cd /d "%~dp0"
set "GAME_ROOT=%~dp0"
set "SHORTCUT=%USERPROFILE%\Desktop\Ultimate Game Show Live.lnk"
set "TARGET=%~dp0START_GAME.bat"
set "ICON=%~dp0assets\branding\ultimate-game-show-logo.ico"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$shell=New-Object -ComObject WScript.Shell; $link=$shell.CreateShortcut($env:SHORTCUT); $link.TargetPath=$env:TARGET; $link.WorkingDirectory=$env:GAME_ROOT; $link.IconLocation=$env:ICON+',0'; $link.Description='Ultimate Game Show Live v4.4'; $link.Save()"
if errorlevel 1 (
  echo The desktop shortcut could not be created.
) else (
  echo Ultimate Game Show Live was added to your desktop.
)
pause
