INTERACTIVE WHEEL GAME — VERSION 3.1 STABILITY BUILD
=====================================================

WHAT CHANGED IN 3.1
-------------------
- More compatible iPhone controller with visible load/reconnect errors.
- Fullscreen audience board now fills approximately 96% of the display width.
- Larger contestant names and totals with a bright NOW PLAYING highlight.
- Intro video is preloaded at 1080p/30; host audio is separated to prevent two
  simultaneous video decodes from freezing the show laptop.
- Host logo, always-visible host answer, click-or-type A-Z letters, Skip Player,
  Skip Round, and a large Continue button after every completed puzzle.
- Broadcast-style flow: two opening toss-ups, Rounds 1–3, Triple Toss-Up,
  Round 4, Final Spin/Speed-Up, and Bonus Round.
- Round 1 Gift Tag, Round 2 Mystery, Round 3 Express, Wild Card and Free Play.
- Select 2–6 players at setup.
- Optional QR contestant pool with Draw Next, Fill All, reset-and-keep-names,
  and start-fresh controls.

IMPORTANT: Before testing phone sign-up, replace index.html and peerjs.min.js in
the GitHub controller repository with the copies in remote-controller.

BEFORE THE EVENT
----------------
1. Run START_GAME.bat (Windows) or START_GAME.command (macOS).
2. On the opening screen, click SET UP AUDIENCE SCREEN.
3. Move the audience window to the TV if the browser does not place it there.
4. Click FULL SCREEN inside the audience window if browser security prevents
   automatic fullscreen. The browser bars should disappear.
5. Choose TV Mode, enter the contestants, and connect phones if using them.
6. Click START GAME SHOW. The supplied intro plays, then the first toss-up loads
   in its ready state. The host still clicks Start Toss-Up when everyone is ready.

AUDIENCE WAITING SCREEN
-----------------------
The transparent Ultimate Game Show Live logo appears prominently above the
waiting message. A smaller copy remains visible on the live puzzle-board screen.

Before the intro, the TV displays:

OUR GAME SHOW WILL BEGIN SOON
Looking to participate?
Sign up now with your host for a chance to play.

HOST SCREEN
-----------
- HOST ANSWER displays the complete answer only on the laptop.
- Letter buttons are larger and more prominent.
- Clicking a vowel directly subtracts the configured vowel price automatically.
  There is no separate Buy Vowel step.
- SKIP PLAYER immediately passes control and supports Undo Last Action.
- SOUND EFFECTS opens applause, laugh, buzzer, correct, wrong, boo, fanfare,
  and drum-roll buttons.

PHONE CONNECTION MODES
----------------------
REMOTE MODE (DEFAULT): V3 automatically uses the live controller at
https://seanc1988.github.io/ultimate-game-show-controller/. Contestants may use
cellular data or any Wi-Fi. The address can still be changed from the Phone
Buzzers window if the controller is moved later.

FULLSCREEN / SECOND DISPLAY
---------------------------
Version 3 asks supported Chromium browsers for access to connected screens and
tries to open, move, and size the audience window on a secondary display. Browser
security may require a one-time permission and one click on FULL SCREEN. After
that, the display contains no browser chrome. Chrome or Edge is recommended.

INTRO AUDIO
-----------
The host copy plays the intro with audio. The audience-window copy is muted to
avoid echo/delay; route the laptop's audio to the venue sound system.
