@echo off
title Ultimate Game Show Live v4.4
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py launch_game.py
) else (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch_game.ps1"
)
