(function(){
  'use strict';
  const MAX=30, DB_NAME='wheelShowMusicV43', STORE='songs';
  const $=id=>document.getElementById(id);
  let db=null,songs=[],index=-1,duckDepth=0,restoreVolume=.6;
  function openDb(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE,{keyPath:'id',autoIncrement:true})};r.onsuccess=()=>{db=r.result;resolve(db)};r.onerror=()=>reject(r.error)})}
  function tx(mode='readonly'){return db.transaction(STORE,mode).objectStore(STORE)}
  function request(req){return new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
  async function reload(){songs=await request(tx().getAll());songs.sort((a,b)=>(a.added||0)-(b.added||0));render();if(index>=songs.length)index=songs.length-1}
  function render(){const list=$('native-song-list');if(!list)return;list.innerHTML='';songs.forEach((s,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=`${i+1}. ${s.name}`;list.appendChild(o)});if(index>=0)list.value=String(index);$('native-now-playing').textContent=songs.length?`${songs.length}/${MAX} songs ready`:'No local songs loaded'}
  function loadTrack(i,autoplay=false){if(!songs.length)return;index=(i+songs.length)%songs.length;const a=$('native-audio'),song=songs[index];if(a.dataset.url)URL.revokeObjectURL(a.dataset.url);const url=URL.createObjectURL(song.blob);a.dataset.url=url;a.src=url;$('native-song-list').value=String(index);$('native-now-playing').textContent=song.name;if(autoplay)a.play().catch(()=>{})}
  function toggle(){const a=$('native-audio');if(!a.src){loadTrack(index<0?0:index,true);return}if(a.paused)a.play().catch(()=>{});else a.pause()}
  async function addFiles(files){const room=Math.max(0,MAX-songs.length),chosen=[...(files||[])].filter(f=>f.type.startsWith('audio/')).slice(0,room);if(!chosen.length){$('native-now-playing').textContent=room?'Choose audio files.':'30-song limit reached.';return}for(const f of chosen)await request(tx('readwrite').add({name:f.name,type:f.type,blob:f,added:Date.now()+Math.random()}));await reload();$('native-now-playing').textContent=`Added ${chosen.length} song${chosen.length===1?'':'s'} · ${songs.length}/${MAX}`}
  async function clearAll(){if(!confirm('Remove all locally uploaded songs from this browser?'))return;await request(tx('readwrite').clear());$('native-audio').pause();$('native-audio').removeAttribute('src');index=-1;await reload()}
  function beginDuck(){duckDepth++;if(duckDepth!==1)return;const a=$('native-audio');restoreVolume=a.volume;a.volume=Math.min(.15,restoreVolume)}
  function endDuck(){duckDepth=Math.max(0,duckDepth-1);if(!duckDepth){const a=$('native-audio');a.volume=restoreVolume}}
  async function init(){
    if(!$('native-media-panel'))return;
    try{await openDb();await reload()}catch(e){$('native-now-playing').textContent='Local song storage is unavailable in this browser.'}
    const panel=$('native-media-panel'),togglePanel=$('native-media-toggle'),audio=$('native-audio');
    togglePanel.onclick=()=>{const compact=panel.classList.toggle('compact');togglePanel.setAttribute('aria-expanded',compact?'false':'true')};
    $('native-song-files').onchange=e=>{addFiles(e.target.files);e.target.value=''};
    $('native-song-list').onchange=e=>loadTrack(Number(e.target.value),false);
    $('native-prev').onclick=()=>loadTrack(index<0?0:index-1,true);$('native-play').onclick=toggle;$('native-next').onclick=()=>loadTrack(index<0?0:index+1,true);
    audio.onplay=()=>{$('native-play').textContent='❚❚'};audio.onpause=()=>{$('native-play').textContent='▶'};audio.onended=()=>loadTrack(index+1,true);
    const saved=Math.max(0,Math.min(1,Number(localStorage.getItem('wheelNativeVolumeV43')||.6)));audio.volume=saved;$('native-volume').value=String(Math.round(saved*100));
    $('native-volume').oninput=e=>{audio.volume=Number(e.target.value)/100;restoreVolume=audio.volume;localStorage.setItem('wheelNativeVolumeV43',String(audio.volume))};
    $('native-clear').onclick=clearAll;
    $('audience-message-submit').onclick=()=>{const message=$('audience-message-input').value.trim();if(!message){$('native-now-playing').textContent='Enter an audience message first.';return}document.dispatchEvent(new CustomEvent('wheel-audience-message',{detail:{message}}))};
    $('audience-message-clear').onclick=()=>{document.dispatchEvent(new CustomEvent('wheel-audience-message',{detail:{message:''}}));$('audience-message-input').value=''};
    document.addEventListener('wheel-game-audio-start',beginDuck);document.addEventListener('wheel-game-audio-end',endDuck);document.addEventListener('wheel-native-duck',e=>{beginDuck();setTimeout(endDuck,Math.max(150,Number(e.detail?.duration)||1200))});
  }
  addEventListener('DOMContentLoaded',init,{once:true});
})();
