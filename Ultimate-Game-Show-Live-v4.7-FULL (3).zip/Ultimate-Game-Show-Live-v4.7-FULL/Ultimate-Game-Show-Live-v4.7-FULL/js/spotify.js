(function(){
  'use strict';
  const KEY='wheelSpotifyV44',LEGACY_KEY='wheelSpotifyV43',DEFAULT_CLIENT_ID='89c8b87baed44c4b92690e72f52e42ed';
  const REDIRECT='http://127.0.0.1:8765/index.html',authBase='https://accounts.spotify.com',apiBase='https://api.spotify.com/v1';
  const scopes=['user-read-private','user-read-playback-state','user-modify-playback-state','playlist-read-private','playlist-read-collaborative'];
  let cfg={clientId:DEFAULT_CLIENT_ID,accessToken:'',refreshToken:'',expiresAt:0,volume:55,duckPause:false,deviceId:''};
  let activeAudio=new Set(),wasPlaying=false,restoreTimer=0;
  const $=id=>document.getElementById(id);
  function load(){try{Object.assign(cfg,JSON.parse(localStorage.getItem(KEY)||localStorage.getItem(LEGACY_KEY)||'{}'))}catch(_){}if(!cfg.clientId)cfg.clientId=DEFAULT_CLIENT_ID}
  function save(){localStorage.setItem(KEY,JSON.stringify(cfg))}
  function bytes(n){const a=new Uint8Array(n);crypto.getRandomValues(a);return a}
  function b64(a){return btoa(String.fromCharCode(...a)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
  async function challenge(v){return b64(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v))))}
  function popupContext(){try{const v=JSON.parse(window.name||'{}');return v&&v.wheelSpotify?v:null}catch(_){return null}}
  async function connect(){
    cfg.clientId=$('spotify-client-id').value.trim()||DEFAULT_CLIENT_ID;cfg.duckPause=$('spotify-duck-pause').checked;save();
    const verifier=b64(bytes(64)),state=b64(bytes(20));
    const q=new URLSearchParams({client_id:cfg.clientId,response_type:'code',redirect_uri:REDIRECT,scope:scopes.join(' '),code_challenge_method:'S256',code_challenge:await challenge(verifier),state,show_dialog:'true'});
    const win=window.open('about:blank','wheelSpotifyOAuth','popup=yes,width=620,height=780,left=100,top=60');
    if(!win){status('Allow pop-ups, then click Connect Spotify again.');return}
    win.name=JSON.stringify({wheelSpotify:true,verifier,state,clientId:cfg.clientId});win.location.replace(authBase+'/authorize?'+q);status('Finish Spotify sign-in in the pop-up window.');
  }
  async function exchange(code,ctx){const body=new URLSearchParams({client_id:ctx.clientId,grant_type:'authorization_code',code,redirect_uri:REDIRECT,code_verifier:ctx.verifier});const r=await fetch(authBase+'/api/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});if(!r.ok)throw new Error('Spotify authorization failed ('+r.status+').');return r.json()}
  function setTokens(t){cfg.accessToken=t.access_token||cfg.accessToken;cfg.refreshToken=t.refresh_token||cfg.refreshToken;cfg.expiresAt=Date.now()+Math.max(30,(t.expires_in||3600)-30)*1000;save()}
  async function token(){if(cfg.accessToken&&Date.now()<cfg.expiresAt)return cfg.accessToken;if(!cfg.refreshToken)return'';const body=new URLSearchParams({client_id:cfg.clientId,grant_type:'refresh_token',refresh_token:cfg.refreshToken});const r=await fetch(authBase+'/api/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});if(!r.ok){cfg.accessToken='';cfg.refreshToken='';save();return''}setTokens(await r.json());return cfg.accessToken}
  async function api(path,opt={}){const t=await token();if(!t)throw new Error('Connect Spotify first.');const headers={Authorization:'Bearer '+t,...(opt.headers||{})};if(opt.body)headers['Content-Type']='application/json';const r=await fetch(apiBase+path,{...opt,headers});if(r.status===204)return null;if(!r.ok){let detail='';try{detail=(await r.json())?.error?.message||''}catch(_){}throw new Error(detail||('Spotify request failed ('+r.status+').'))}return r.json()}
  function status(message,artist){if($('spotify-title'))$('spotify-title').textContent=message;if($('spotify-artist'))$('spotify-artist').textContent=artist||''}
  function deviceQuery(){return cfg.deviceId?'?device_id='+encodeURIComponent(cfg.deviceId):''}
  async function loadDevices(){try{const d=await api('/me/player/devices'),s=$('spotify-device');s.innerHTML='<option value="">Automatic / active device</option>';for(const dev of d.devices||[]){const o=document.createElement('option');o.value=dev.id;o.textContent=(dev.is_active?'● ':'')+dev.name+' · '+dev.type;s.appendChild(o)}if(cfg.deviceId&&[...s.options].some(o=>o.value===cfg.deviceId))s.value=cfg.deviceId;if(!(d.devices||[]).length)status('No Spotify playback device found','Open Spotify on a phone or computer, then reconnect.')}catch(e){status(e.message)}}
  async function refreshNow(){if(!cfg.accessToken&&!cfg.refreshToken)return;try{const p=await api('/me/player');$('spotify-connect').textContent='Spotify Connected';if(!p||!p.item){status('Spotify connected','Choose a device and playlist');return}status(p.item.name,(p.item.artists||[]).map(a=>a.name).join(', '));$('spotify-play').textContent=p.is_playing?'❚❚':'▶';const img=p.item.album?.images?.[2]?.url||p.item.album?.images?.[0]?.url;if(img){$('spotify-art').src=img;$('spotify-art').hidden=false}}catch(e){status(e.message)}}
  async function loadPlaylists(){try{const d=await api('/me/playlists?limit=50'),s=$('spotify-playlist');s.innerHTML='<option value="">Choose playlist</option>';for(const p of d.items||[]){const o=document.createElement('option');o.value=p.uri;o.textContent=p.name;s.appendChild(o)}}catch(e){status(e.message)}}
  async function command(path,opt={}){try{await api(path,opt);setTimeout(refreshNow,350);return true}catch(e){status(e.message);return false}}
  async function activateDevice(){if(!cfg.deviceId)return true;return command('/me/player',{method:'PUT',body:JSON.stringify({device_ids:[cfg.deviceId],play:false})})}
  async function playPlaylist(uri){if(!uri)return;status('Starting playlist…');if(!(await activateDevice()))return;await new Promise(r=>setTimeout(r,250));const ok=await command('/me/player/play'+deviceQuery(),{method:'PUT',body:JSON.stringify({context_uri:uri})});if(!ok)status('Could not start playback','Open Spotify on the selected device and try again.')}
  async function duck(){clearTimeout(restoreTimer);if(activeAudio.size!==1)return;try{const p=await api('/me/player');wasPlaying=!!p?.is_playing;if(!wasPlaying)return;if(cfg.duckPause)await api('/me/player/pause'+deviceQuery(),{method:'PUT'});else await api('/me/player/volume?volume_percent=15'+(cfg.deviceId?'&device_id='+encodeURIComponent(cfg.deviceId):''),{method:'PUT'})}catch(_){}}
  function restore(){clearTimeout(restoreTimer);restoreTimer=setTimeout(async()=>{if(activeAudio.size||!wasPlaying)return;try{if(cfg.duckPause)await api('/me/player/play'+deviceQuery(),{method:'PUT'});else await api('/me/player/volume?volume_percent='+cfg.volume+(cfg.deviceId?'&device_id='+encodeURIComponent(cfg.deviceId):''),{method:'PUT'})}catch(_){}},450)}
  async function handleCallback(){const q=new URLSearchParams(location.search),code=q.get('code');if(!code)return false;const ctx=popupContext();try{if(!ctx||q.get('state')!==ctx.state)throw new Error('Spotify security check failed. Please reconnect.');const tokens=await exchange(code,ctx);if(window.opener&&!window.opener.closed){window.opener.postMessage({type:'wheel-spotify-oauth',tokens,clientId:ctx.clientId},'*');document.body.innerHTML='<main style="font:700 22px Arial;padding:40px">Spotify connected. This window can close.</main>';setTimeout(()=>window.close(),500)}else{load();cfg.clientId=ctx.clientId;setTokens(tokens);history.replaceState({},'',REDIRECT)}return true}catch(e){document.body.innerHTML='<main style="font:700 20px Arial;padding:40px">'+String(e.message).replace(/[<>&]/g,'')+'</main>';return true}}
  async function init(){
    if(await handleCallback())return;load();if(!$('spotify-bar'))return;
    $('spotify-client-id').value=cfg.clientId;$('spotify-duck-pause').checked=!!cfg.duckPause;$('spotify-volume').value=cfg.volume;$('spotify-redirect-uri').textContent=REDIRECT;
    const openSpotify=()=>{$('spotify-bar').classList.remove('compact');$('spotify-collapse').setAttribute('aria-expanded','true');};
    $('spotify-collapse').onclick=()=>{const compact=$('spotify-bar').classList.toggle('compact');$('spotify-collapse').setAttribute('aria-expanded',compact?'false':'true')};$('spotify-settings').onclick=()=>$('spotify-config').hidden=!$('spotify-config').hidden;$('spotify-connect').onclick=connect;$('spotify-save').onclick=connect;
    const dock=$('btn-spotify-dock');if(dock)dock.onclick=()=>{openSpotify();$('spotify-bar').scrollIntoView?.({block:'nearest'});status(cfg.accessToken||cfg.refreshToken?'Spotify controls ready':'Connect Spotify to begin',cfg.accessToken||cfg.refreshToken?'Choose a device or playlist':'')};
    $('spotify-prev').onclick=()=>command('/me/player/previous'+deviceQuery(),{method:'POST'});$('spotify-next').onclick=()=>command('/me/player/next'+deviceQuery(),{method:'POST'});
    $('spotify-play').onclick=async()=>{try{const p=await api('/me/player');await command('/me/player/'+(p?.is_playing?'pause':'play')+deviceQuery(),{method:'PUT'})}catch(e){status(e.message)}};
    $('spotify-volume').onchange=e=>{cfg.volume=+e.target.value;save();command('/me/player/volume?volume_percent='+cfg.volume+(cfg.deviceId?'&device_id='+encodeURIComponent(cfg.deviceId):''),{method:'PUT'})};
    $('spotify-device').onchange=e=>{cfg.deviceId=e.target.value;save();if(cfg.deviceId)activateDevice()};$('spotify-playlist').onchange=e=>playPlaylist(e.target.value);
    addEventListener('message',async e=>{if(e.data?.type!=='wheel-spotify-oauth')return;cfg.clientId=e.data.clientId||cfg.clientId;setTokens(e.data.tokens||{});status('Spotify connected','Loading devices and playlists…');await Promise.all([loadDevices(),loadPlaylists(),refreshNow()])});
    document.addEventListener('wheel-game-audio-start',e=>{activeAudio.add(e.detail?.key||'game');duck()});document.addEventListener('wheel-game-audio-end',e=>{activeAudio.delete(e.detail?.key||'game');restore()});
    if(cfg.accessToken||cfg.refreshToken){await Promise.all([refreshNow(),loadPlaylists(),loadDevices()]);setInterval(refreshNow,5000)}
  }
  window.WheelSpotify={duck,restore,refresh:refreshNow,loadDevices};addEventListener('DOMContentLoaded',init,{once:true});
})();
