/* Spin & Solve - wheel game */
(() => {
  const VOWELS = 'AEIOU';
  const ALPHA  = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

  // Safari private browsing and restricted local-file contexts can deny storage.
  // Keep the game playable even when preferences cannot persist.
  function storageGet(key, fallback = null){
    try { const value = localStorage.getItem(key); return value === null ? fallback : value; }
    catch (_) { return fallback; }
  }
  function storageSet(key, value){
    try { localStorage.setItem(key, value); return true; }
    catch (_) { return false; }
  }
  function storageRemove(key){
    try { localStorage.removeItem(key); return true; }
    catch (_) { return false; }
  }

  const defaults = {
    // ~100 puzzles, each tagged diff: 'easy' | 'med' | 'hard'.
    // Difficulty feeds the round curve: toss-ups & Round 1 pull EASY, Round 2 MED, Round 3 & BONUS HARD.
    puzzles: [
      /* PHRASE */
      { cat: 'PHRASE', diff: 'easy', text: 'BREAK THE ICE' },
      { cat: 'PHRASE', diff: 'easy', text: 'A PIECE OF CAKE' },
      { cat: 'PHRASE', diff: 'easy', text: 'HOME SWEET HOME' },
      { cat: 'PHRASE', diff: 'easy', text: 'BREAK A LEG' },
      { cat: 'PHRASE', diff: 'easy', text: 'GO WITH THE FLOW' },
      { cat: 'PHRASE', diff: 'easy', text: 'NO PAIN NO GAIN' },
      { cat: 'PHRASE', diff: 'med',  text: 'BEAT AROUND THE BUSH' },
      { cat: 'PHRASE', diff: 'med',  text: 'ONCE IN A BLUE MOON' },
      { cat: 'PHRASE', diff: 'med',  text: 'EASIER SAID THAN DONE' },
      { cat: 'PHRASE', diff: 'med',  text: 'BURN THE MIDNIGHT OIL' },
      { cat: 'PHRASE', diff: 'med',  text: 'HIT THE NAIL ON THE HEAD' },
      { cat: 'PHRASE', diff: 'hard', text: 'A BLESSING IN DISGUISE' },
      { cat: 'PHRASE', diff: 'hard', text: 'THE BALL IS IN YOUR COURT' },
      { cat: 'PHRASE', diff: 'hard', text: 'EVERY CLOUD HAS A SILVER LINING' },
      /* THING */
      { cat: 'THING', diff: 'easy', text: 'SHOOTING STAR' },
      { cat: 'THING', diff: 'easy', text: 'ELECTRIC GUITAR' },
      { cat: 'THING', diff: 'easy', text: 'ROLLER COASTER' },
      { cat: 'THING', diff: 'easy', text: 'BEACH BALL' },
      { cat: 'THING', diff: 'easy', text: 'RUBBER DUCK' },
      { cat: 'THING', diff: 'easy', text: 'TEDDY BEAR' },
      { cat: 'THING', diff: 'med',  text: 'CHOCOLATE FOUNTAIN' },
      { cat: 'THING', diff: 'med',  text: 'WIRELESS HEADPHONES' },
      { cat: 'THING', diff: 'med',  text: 'GRANDFATHER CLOCK' },
      { cat: 'THING', diff: 'med',  text: 'COFFEE TABLE BOOK' },
      { cat: 'THING', diff: 'med',  text: 'MESSAGE IN A BOTTLE' },
      { cat: 'THING', diff: 'hard', text: 'VINTAGE RECORD PLAYER' },
      /* PLACE */
      { cat: 'PLACE', diff: 'easy', text: 'NEW YORK CITY' },
      { cat: 'PLACE', diff: 'easy', text: 'TIMES SQUARE' },
      { cat: 'PLACE', diff: 'easy', text: 'GRAND CANYON' },
      { cat: 'PLACE', diff: 'easy', text: 'WHITE HOUSE' },
      { cat: 'PLACE', diff: 'med',  text: 'EIFFEL TOWER' },
      { cat: 'PLACE', diff: 'med',  text: 'NIAGARA FALLS' },
      { cat: 'PLACE', diff: 'med',  text: 'GOLDEN GATE BRIDGE' },
      { cat: 'PLACE', diff: 'med',  text: 'MOUNT EVEREST' },
      { cat: 'PLACE', diff: 'hard', text: 'GREAT WALL OF CHINA' },
      { cat: 'PLACE', diff: 'hard', text: 'LEANING TOWER OF PISA' },
      { cat: 'PLACE', diff: 'hard', text: 'SYDNEY OPERA HOUSE' },
      /* PERSON */
      { cat: 'PERSON', diff: 'easy', text: 'TAYLOR SWIFT' },
      { cat: 'PERSON', diff: 'easy', text: 'MICHAEL JORDAN' },
      { cat: 'PERSON', diff: 'easy', text: 'ELVIS PRESLEY' },
      { cat: 'PERSON', diff: 'med',  text: 'OPRAH WINFREY' },
      { cat: 'PERSON', diff: 'med',  text: 'ALBERT EINSTEIN' },
      { cat: 'PERSON', diff: 'hard', text: 'LEONARDO DA VINCI' },
      { cat: 'PERSON', diff: 'hard', text: 'WILLIAM SHAKESPEARE' },
      /* EVENT */
      { cat: 'EVENT', diff: 'easy', text: 'BIRTHDAY PARTY' },
      { cat: 'EVENT', diff: 'easy', text: 'SUMMER VACATION' },
      { cat: 'EVENT', diff: 'easy', text: 'ROAD TRIP' },
      { cat: 'EVENT', diff: 'med',  text: 'GRADUATION CEREMONY' },
      { cat: 'EVENT', diff: 'med',  text: 'WEDDING RECEPTION' },
      { cat: 'EVENT', diff: 'med',  text: 'FAMILY REUNION' },
      /* TITLE */
      { cat: 'TITLE', diff: 'easy', text: 'STAR WARS' },
      { cat: 'TITLE', diff: 'easy', text: 'THE LION KING' },
      { cat: 'TITLE', diff: 'easy', text: 'TOY STORY' },
      { cat: 'TITLE', diff: 'med',  text: 'THE WIZARD OF OZ' },
      { cat: 'TITLE', diff: 'med',  text: 'THE GREAT GATSBY' },
      { cat: 'TITLE', diff: 'med',  text: 'ROMEO AND JULIET' },
      { cat: 'TITLE', diff: 'hard', text: 'PRIDE AND PREJUDICE' },
      { cat: 'TITLE', diff: 'hard', text: 'TO KILL A MOCKINGBIRD' },
      /* FOOD & DRINK */
      { cat: 'FOOD & DRINK', diff: 'easy', text: 'PEPPERONI PIZZA' },
      { cat: 'FOOD & DRINK', diff: 'easy', text: 'FRENCH FRIES' },
      { cat: 'FOOD & DRINK', diff: 'easy', text: 'ICE CREAM SUNDAE' },
      { cat: 'FOOD & DRINK', diff: 'easy', text: 'GRILLED CHEESE' },
      { cat: 'FOOD & DRINK', diff: 'easy', text: 'APPLE PIE' },
      { cat: 'FOOD & DRINK', diff: 'med',  text: 'STRAWBERRY SHORTCAKE' },
      { cat: 'FOOD & DRINK', diff: 'med',  text: 'CHICKEN NOODLE SOUP' },
      { cat: 'FOOD & DRINK', diff: 'med',  text: 'ICED CARAMEL LATTE' },
      { cat: 'FOOD & DRINK', diff: 'hard', text: 'SPAGHETTI AND MEATBALLS' },
      /* OCCUPATION */
      { cat: 'OCCUPATION', diff: 'easy', text: 'SCHOOL TEACHER' },
      { cat: 'OCCUPATION', diff: 'easy', text: 'POLICE OFFICER' },
      { cat: 'OCCUPATION', diff: 'easy', text: 'BUS DRIVER' },
      { cat: 'OCCUPATION', diff: 'med',  text: 'FLIGHT ATTENDANT' },
      { cat: 'OCCUPATION', diff: 'med',  text: 'BRAIN SURGEON' },
      { cat: 'OCCUPATION', diff: 'hard', text: 'MARINE BIOLOGIST' },
      /* AROUND THE HOUSE */
      { cat: 'AROUND THE HOUSE', diff: 'easy', text: 'KITCHEN SINK' },
      { cat: 'AROUND THE HOUSE', diff: 'easy', text: 'FRONT DOOR' },
      { cat: 'AROUND THE HOUSE', diff: 'easy', text: 'COFFEE MUG' },
      { cat: 'AROUND THE HOUSE', diff: 'med',  text: 'WASHING MACHINE' },
      { cat: 'AROUND THE HOUSE', diff: 'med',  text: 'REMOTE CONTROL' },
      { cat: 'AROUND THE HOUSE', diff: 'hard', text: 'GARAGE DOOR OPENER' },
      /* SEASONAL */
      { cat: 'SEASONAL', diff: 'easy', text: 'CHRISTMAS TREE' },
      { cat: 'SEASONAL', diff: 'easy', text: 'PUMPKIN PIE' },
      { cat: 'SEASONAL', diff: 'easy', text: 'TRICK OR TREAT' },
      { cat: 'SEASONAL', diff: 'easy', text: 'SANTA CLAUS' },
      { cat: 'SEASONAL', diff: 'med',  text: 'EASTER EGG HUNT' },
      { cat: 'SEASONAL', diff: 'med',  text: 'NEW YEAR\'S EVE' },
      { cat: 'SEASONAL', diff: 'med',  text: 'FOURTH OF JULY' },
      { cat: 'SEASONAL', diff: 'hard', text: 'JINGLE ALL THE WAY' },
      /* BEFORE & AFTER */
      { cat: 'BEFORE & AFTER', diff: 'med',  text: 'ICE CREAM CHEESE' },
      { cat: 'BEFORE & AFTER', diff: 'med',  text: 'MOVIE STAR FISH' },
      { cat: 'BEFORE & AFTER', diff: 'med',  text: 'RAIN BOW TIE' },
      { cat: 'BEFORE & AFTER', diff: 'med',  text: 'COFFEE BREAK DANCE' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'PEANUT BUTTER CUP CAKE' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'FRENCH TOAST MASTER' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'GREEN HOUSE PARTY' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'HONEY MOON LIGHT' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'SUN FLOWER POWER' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'BUTTER FLY SWATTER' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'FAMILY GAME NIGHT OWL' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'SCHOOL BUS DRIVER' },
      /* SAME LETTER */
      { cat: 'SAME LETTER', diff: 'med',  text: 'BIG BOLD BUTTONS' },
      { cat: 'SAME LETTER', diff: 'med',  text: 'SUPER SOFT SWEATER' },
      { cat: 'SAME LETTER', diff: 'med',  text: 'BRIGHT BLUE BALLOON' },
      { cat: 'SAME LETTER', diff: 'med',  text: 'SWEET SUMMER SUNSET' },
      { cat: 'SAME LETTER', diff: 'med',  text: 'FANCY FRENCH FRIES' },
      { cat: 'SAME LETTER', diff: 'hard', text: 'SILVER SCREEN STAR' },
      { cat: 'SAME LETTER', diff: 'hard', text: 'PERFECT PAIR OF PANTS' },
      { cat: 'SAME LETTER', diff: 'hard', text: 'COOL CALM AND COLLECTED' },
      { cat: 'SAME LETTER', diff: 'hard', text: 'WILD WACKY WEEKEND' },
      { cat: 'SAME LETTER', diff: 'hard', text: 'TINY TODDLER TANTRUM' },
      /* ---- HARD TIER EXPANSION ---- */
      { cat: 'PHRASE', diff: 'hard', text: 'A PENNY FOR YOUR THOUGHTS' },
      { cat: 'PHRASE', diff: 'hard', text: 'CURIOSITY KILLED THE CAT' },
      { cat: 'PHRASE', diff: 'hard', text: 'ACTIONS SPEAK LOUDER THAN WORDS' },
      { cat: 'PHRASE', diff: 'hard', text: 'THE EARLY BIRD CATCHES THE WORM' },
      { cat: 'THING', diff: 'hard', text: 'STAINLESS STEEL REFRIGERATOR' },
      { cat: 'THING', diff: 'hard', text: 'CRYSTAL CHANDELIER' },
      { cat: 'THING', diff: 'hard', text: 'SPIRAL STAIRCASE' },
      { cat: 'PLACE', diff: 'hard', text: 'STATUE OF LIBERTY' },
      { cat: 'PLACE', diff: 'hard', text: 'BUCKINGHAM PALACE' },
      { cat: 'PLACE', diff: 'hard', text: 'AMAZON RAINFOREST' },
      { cat: 'PERSON', diff: 'hard', text: 'WINSTON CHURCHILL' },
      { cat: 'PERSON', diff: 'hard', text: 'FLORENCE NIGHTINGALE' },
      { cat: 'PERSON', diff: 'hard', text: 'CHRISTOPHER COLUMBUS' },
      { cat: 'EVENT', diff: 'hard', text: 'SURPRISE BIRTHDAY PARTY' },
      { cat: 'EVENT', diff: 'hard', text: 'HIGH SCHOOL REUNION' },
      { cat: 'EVENT', diff: 'hard', text: 'RETIREMENT CELEBRATION' },
      { cat: 'TITLE', diff: 'hard', text: 'THE LORD OF THE RINGS' },
      { cat: 'TITLE', diff: 'hard', text: 'GONE WITH THE WIND' },
      { cat: 'TITLE', diff: 'hard', text: 'THE CATCHER IN THE RYE' },
      { cat: 'FOOD & DRINK', diff: 'hard', text: 'BARBECUE PULLED PORK' },
      { cat: 'FOOD & DRINK', diff: 'hard', text: 'CHOCOLATE LAVA CAKE' },
      { cat: 'FOOD & DRINK', diff: 'hard', text: 'FETTUCCINE ALFREDO' },
      { cat: 'OCCUPATION', diff: 'hard', text: 'AEROSPACE ENGINEER' },
      { cat: 'OCCUPATION', diff: 'hard', text: 'INVESTIGATIVE JOURNALIST' },
      { cat: 'OCCUPATION', diff: 'hard', text: 'ORCHESTRA CONDUCTOR' },
      { cat: 'AROUND THE HOUSE', diff: 'hard', text: 'WALK IN CLOSET' },
      { cat: 'AROUND THE HOUSE', diff: 'hard', text: 'KITCHEN ISLAND COUNTERTOP' },
      { cat: 'AROUND THE HOUSE', diff: 'hard', text: 'GRANITE COUNTERTOP' },
      { cat: 'SEASONAL', diff: 'hard', text: 'THANKSGIVING DINNER' },
      { cat: 'SEASONAL', diff: 'hard', text: 'NEW YEARS RESOLUTION' },
      { cat: 'SEASONAL', diff: 'hard', text: 'GINGERBREAD HOUSE' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'CARD BOARD GAME' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'FIRE WORK OUT' },
      { cat: 'SAME LETTER', diff: 'hard', text: 'GIANT GREEN GRASSHOPPER' },
      { cat: 'SAME LETTER', diff: 'hard', text: 'DARK DUSTY DESERT DUNES' },
      /* ---- EASY TIER EXPANSION ---- */
      { cat: 'PHRASE', diff: 'easy', text: 'TIME FLIES' },
      { cat: 'PHRASE', diff: 'easy', text: 'GOOD AS GOLD' },
      { cat: 'PHRASE', diff: 'easy', text: 'FACE THE MUSIC' },
      { cat: 'THING', diff: 'easy', text: 'FERRIS WHEEL' },
      { cat: 'THING', diff: 'easy', text: 'PAPER AIRPLANE' },
      { cat: 'THING', diff: 'easy', text: 'BICYCLE BELL' },
      { cat: 'PLACE', diff: 'easy', text: 'CENTRAL PARK' },
      { cat: 'PLACE', diff: 'easy', text: 'SANDY BEACH' },
      { cat: 'PLACE', diff: 'easy', text: 'CITY HALL' },
      { cat: 'PERSON', diff: 'easy', text: 'ABRAHAM LINCOLN' },
      { cat: 'PERSON', diff: 'easy', text: 'SERENA WILLIAMS' },
      { cat: 'EVENT', diff: 'easy', text: 'MOVIE NIGHT' },
      { cat: 'EVENT', diff: 'easy', text: 'GAME NIGHT' },
      { cat: 'TITLE', diff: 'easy', text: 'FROZEN' },
      { cat: 'TITLE', diff: 'easy', text: 'FINDING NEMO' },
      { cat: 'FOOD & DRINK', diff: 'easy', text: 'HOT DOG' },
      { cat: 'FOOD & DRINK', diff: 'easy', text: 'CHEESE BURGER' },
      { cat: 'FOOD & DRINK', diff: 'easy', text: 'ORANGE JUICE' },
      { cat: 'OCCUPATION', diff: 'easy', text: 'FIRE FIGHTER' },
      { cat: 'OCCUPATION', diff: 'easy', text: 'MAIL CARRIER' },
      { cat: 'AROUND THE HOUSE', diff: 'easy', text: 'KITCHEN TABLE' },
      { cat: 'AROUND THE HOUSE', diff: 'easy', text: 'BACK YARD' },
      { cat: 'SEASONAL', diff: 'easy', text: 'SNOW ANGEL' },
      { cat: 'SEASONAL', diff: 'easy', text: 'CANDY CANE' },
      { cat: 'SEASONAL', diff: 'easy', text: 'BEACH DAY' },
      /* ---- MEDIUM TIER EXPANSION ---- */
      { cat: 'PHRASE', diff: 'med',  text: 'TWO PEAS IN A POD' },
      { cat: 'PHRASE', diff: 'med',  text: 'WHEN IN ROME' },
      { cat: 'THING', diff: 'med',  text: 'TRAMPOLINE PARK' },
      { cat: 'THING', diff: 'med',  text: 'PICNIC BASKET' },
      { cat: 'PLACE', diff: 'med',  text: 'YELLOWSTONE PARK' },
      { cat: 'PLACE', diff: 'med',  text: 'TROPICAL ISLAND' },
      { cat: 'PERSON', diff: 'med',  text: 'MARTIN LUTHER KING' },
      { cat: 'PERSON', diff: 'med',  text: 'WALT DISNEY' },
      { cat: 'EVENT', diff: 'med',  text: 'BABY SHOWER' },
      { cat: 'EVENT', diff: 'med',  text: 'BLOCK PARTY' },
      { cat: 'TITLE', diff: 'med',  text: 'JURASSIC PARK' },
      { cat: 'TITLE', diff: 'med',  text: 'THE SOUND OF MUSIC' },
      { cat: 'FOOD & DRINK', diff: 'med',  text: 'CHICKEN ALFREDO' },
      { cat: 'FOOD & DRINK', diff: 'med',  text: 'BLUEBERRY PANCAKES' },
      { cat: 'OCCUPATION', diff: 'med',  text: 'SOFTWARE DEVELOPER' },
      { cat: 'OCCUPATION', diff: 'med',  text: 'DENTAL HYGIENIST' },
      { cat: 'AROUND THE HOUSE', diff: 'med',  text: 'KITCHEN CABINET' },
      { cat: 'SEASONAL', diff: 'med',  text: 'HALLOWEEN COSTUME' },
      { cat: 'SAME LETTER', diff: 'med',  text: 'SLOW SLEEPY SLOTH' },
      { cat: 'BEFORE & AFTER', diff: 'med',  text: 'TENNIS BALL GAME' },
      /* ---- ORIGINAL PARTY-FRIENDLY PUZZLES ---- */
      { cat: 'PHRASE', diff: 'easy', text: 'READ THE ROOM' },
      { cat: 'PHRASE', diff: 'easy', text: 'SAVE IT FOR LATER' },
      { cat: 'PHRASE', diff: 'med',  text: 'THE PLOT THICKENS' },
      { cat: 'PHRASE', diff: 'hard', text: 'LIGHTNING IN A BOTTLE' },
      { cat: 'THING', diff: 'easy', text: 'SECRET RECIPE' },
      { cat: 'THING', diff: 'med',  text: 'HANDWRITTEN NOTE' },
      { cat: 'THING', diff: 'med',  text: 'BACKUP PLAN' },
      { cat: 'THING', diff: 'hard', text: 'MIDNIGHT TRAIN TICKET' },
      { cat: 'PLACE', diff: 'easy', text: 'CORNER CAFE' },
      { cat: 'PLACE', diff: 'med',  text: 'HIDDEN GARDEN' },
      { cat: 'PLACE', diff: 'hard', text: 'ROOFTOP OBSERVATORY' },
      { cat: 'EVENT', diff: 'easy', text: 'TALENT SHOW' },
      { cat: 'EVENT', diff: 'med',  text: 'SURPRISE INSPECTION' },
      { cat: 'EVENT', diff: 'hard', text: 'LAST MINUTE ROAD TRIP' },
      { cat: 'PERSON', diff: 'easy', text: 'TEAM CAPTAIN' },
      { cat: 'PERSON', diff: 'med',  text: 'MYSTERY GUEST' },
      { cat: 'PERSON', diff: 'hard', text: 'QUIET GENIUS' },
      { cat: 'FOOD & DRINK', diff: 'easy', text: 'MIDNIGHT SNACK' },
      { cat: 'FOOD & DRINK', diff: 'med',  text: 'SECRET SAUCE' },
      { cat: 'FOOD & DRINK', diff: 'hard', text: 'BURNT TOAST BRUNCH' },
      { cat: 'SAME LETTER', diff: 'med',  text: 'CLEVER COOKIE CRUMBS' },
      { cat: 'SAME LETTER', diff: 'hard', text: 'BRAVE BRIGHT BRAINSTORM' },
      { cat: 'BEFORE & AFTER', diff: 'med',  text: 'GAME NIGHT LIGHT' },
      { cat: 'BEFORE & AFTER', diff: 'hard', text: 'SECRET AGENT ORANGE' },
    ],
    // 24 slices. Median pushed to ~$900; one $5,000 spike; new MYSTERY / DOUBLE / WILD wedges add gameplay-altering moments.
    slices: ['700','900','MYSTERY','800','1100','BANKRUPT','650','1000','900','750','LOSE','800','1200','WILD','950','750','BANKRUPT','5000','900','1100','FREE','700','800','1500'],
    party:  ['Sing a song','Tell a joke','Truth','Dare','Trivia','Wild card','Dance','Skip turn','Compliment','Funny face','Imitate someone','Free spin'],
    players: [
      {name:'Player 1', color:'#ff2f7f', avatar:'🦊'},
      {name:'Player 2', color:'#ffd60a', avatar:'🦁'},
      {name:'Player 3', color:'#27d9ff', avatar:'🐼'}
    ],
    bgImage: '',
    tileImage: '',
    timeLimit: 20,
    autoAdvance: true,
    vowelCost: 250,
    solveBonus: 1000,
    solveMode: 'tv', // 'tv' = host clicks who solved (was 'party'); 'hostless' = type-and-auto-verify (was 'quiz')
    shuffle: true,
    maxRounds: 0,
    enabledCategories: [],
    roundMode: true,
    roundCount: 4,
    roundMultipliers: [1, 1.5, 2],
    tossupEnabled: true,
    tossupValues: [1000, 2000, 3000],
    tossupRevealMs: 1500,
    tossupControlMode: 'phones',
    bonusEnabled: true,
    bonusPrize: 50000,
    bonusTimerSeconds: 20,
    crowdEnabled: true,
    crowdVolume: 0.60,
    musicEnabled: true,
    musicVolume: 0.22,
    welcomeMessage: '',
    winnerMessage: 'Congratulations to tonight’s champion!',
    visualTheme: 'classic',
    puzzleDifficulty: 'random',
    puzzleTheme: 'all',
    sponsorEnabled: false,
    sponsorSlides: [],
    buildVersion: 47
  };

  if (Array.isArray(window.UGSL_CORE_PUZZLES) && window.UGSL_CORE_PUZZLES.length === 1000) {
    defaults.puzzles = window.UGSL_CORE_PUZZLES.slice();
  }

  const state = {
    cfg: load(),
    mode: 'classic',
    puzzleIdx: 0,
    revealed: new Set(),     // letters revealed
    used: new Set(),         // letters guessed (any)
    puzzle: null,
    spinValue: null,
    spinning: false,
    turnTransition: false,
    canGuess: false,
    activePlayer: 0,
    scores: [],              // round bank per player
    totals: [],              // total per player
    freePlay: false,
    expressMode: false,
    speedUpMode: false,
    speedUpAwaitingSpin: false,
    speedUpValue: 0,
    muted: storageGet('spinSolveMuted') === '1',
    timeLeft: 0,
    timerLimit: 0,
    timerDeadline: 0,
    timerHandle: null,
    timerGen: 0,
    turnTimerToken: 0,
    turnExpireHandle: null,
    timerActive: false,
    bonusTimerActive: false,
    roundOver: false,
    advanceHandle: null,
    activePuzzles: null,
    phases: null,
    phase: null,
    tossupRevealHandle: null,
    tossupStarted: false,
    tossupLockout: new Set(),
    tossupQueue: [],
    bonusLetters: new Set(),
    bonusTimerHandle: null,
    bonusReadyHandle: null,
    bonusPicking: false,
    bonusEnvelopeReady: false,
    bonusJudging: false,
    leaderboardRecorded: false,
  };

  let modalResolve = null;
  let solveModalResolve = null;

  /* ---------- AUDIENCE DISPLAY ---------- */
  const audienceChannel = typeof BroadcastChannel !== 'undefined'
    ? new BroadcastChannel('interactive-wheel-audience-v1') : null;

  function audienceSnapshot(){
    const live = document.getElementById('screen-classic')?.classList.contains('active');
    const phaseBanner = document.getElementById('phase-banner');
    return {
      type: 'audience-state',
      category: live ? (document.getElementById('category')?.textContent || '') : '',
      phase: live && phaseBanner && phaseBanner.style.display !== 'none' ? phaseBanner.textContent : '',
      boardHtml: live ? (document.getElementById('puzzle-board')?.innerHTML || '') : '',
      welcomeMessage: String(state.cfg.welcomeMessage || ''),
      winnerMessage: String(state.cfg.winnerMessage || ''),
      visualTheme: String(state.cfg.visualTheme || 'classic'),
      tileImage: String(state.cfg.tileImage || ''),
      roundOver: !!state.roundOver,
      sponsorEnabled: !!state.cfg.sponsorEnabled,
      sponsorSlides: (!live || state.roundOver) ? (state.cfg.sponsorSlides || []) : [],
      pool: buzzerAvailable() && window.WheelBuzzer.getPoolState ? window.WheelBuzzer.getPoolState() : {enabled:false},
      players: (state.cfg.players || []).map((p, i) => ({
        name: p.name,
        color: p.color,
        avatar: p.avatar || '⭐',
        active: i === state.activePlayer,
        round: state.scores[i] || 0,
        total: state.totals[i] || 0
        , wild: (state.wildCards && state.wildCards[i]) || 0
        , buzzed: i === state.buzzedPlayer
      }))
    };
  }

  function publishAudienceDisplay(){
    if (!audienceChannel) return;
    try { audienceChannel.postMessage(audienceSnapshot()); } catch (_) {}
  }

  function publishAudienceSpin(type, detail = {}){
    if (!audienceChannel) return;
    try { audienceChannel.postMessage(Object.assign({ type }, detail)); } catch (_) {}
  }

  function applyVisualTheme(){
    const key=String(state.cfg.visualTheme||'classic');
    const themes=window.WHEEL_V4_VISUAL_THEMES||{};
    const t=themes[key]||themes.classic;
    document.body.dataset.showTheme=key;
    if(t){document.documentElement.style.setProperty('--show-accent',t.accent);document.documentElement.style.setProperty('--show-accent-2',t.accent2);document.documentElement.style.setProperty('--show-cover',t.cover);document.documentElement.style.setProperty('--show-bg',t.bg);document.documentElement.style.setProperty('--show-art',t.art||'none');document.documentElement.style.setProperty('--show-tile-art',state.cfg.tileImage?`url("${state.cfg.tileImage}")`:(t.tileArt||'none'));document.documentElement.style.setProperty('--show-icon',state.cfg.tileImage?'""':`"${t.icon||'✦'}"`)}
    publishAudienceDisplay();
  }

  let introAudienceFinished = null;
  if (audienceChannel) audienceChannel.onmessage = e => {
    if (e.data && e.data.type === 'audience-ready') publishAudienceDisplay();
    if (e.data && e.data.type === 'audience-intro-finished' && typeof introAudienceFinished === 'function') introAudienceFinished();
  };

  // Optional puzzle content is supplied only by external add-on packs.
  const THEME_NIGHT_PACKS = window.UGSL_THEME_PACKS || {};

  let audienceWindow = null;
  async function openAudienceDisplay(){
    if (location.protocol === 'file:') {
      msg('Use START_GAME.bat first, then open the Audience Display.');
      return;
    }
    let target = null;
    try {
      if (window.getScreenDetails) {
        const details = await window.getScreenDetails();
        target = details.screens.find(s => !s.isPrimary) || details.currentScreen || null;
      }
    } catch (_) {}
    const left = target ? target.availLeft : screen.availLeft;
    const top = target ? target.availTop : screen.availTop;
    const width = target ? target.availWidth : Math.min(1280, screen.availWidth);
    const height = target ? target.availHeight : Math.min(720, screen.availHeight);
    const win = window.open('audience.html', 'wheelAudience', `popup=yes,left=${left},top=${top},width=${width},height=${height}`);
    if (!win) msg('The browser blocked the audience window. Allow pop-ups, then try again.');
    else {
      audienceWindow = win;
      setTimeout(() => {
        try { win.moveTo(left, top); win.resizeTo(width, height); win.focus(); win.document.documentElement.requestFullscreen?.().catch(()=>{}); } catch (_) {}
        publishAudienceDisplay();
      }, 650);
    }
  }

  function remoteSpinAllowed(){
    const phaseType = state.phase && state.phase.type;
    return phaseType === 'round' && !state.speedUpMode && !state.speedUpAwaitingSpin && !state.roundOver && !state.spinning && !state.spinPending &&
      !state.solveLocked && !state.turnTransition && !state.canGuess && !state.freePlay &&
      !document.getElementById('modal')?.classList.contains('show');
  }

  function syncRemoteControls(){
    if (!buzzerAvailable()) return;
    const phonePuzzle = state.puzzle ? [...state.puzzle.text].map(ch => /[A-Z]/.test(ch) ? (state.revealed.has(ch) ? ch : '＿') : ch).join('') : '';
    const boardRows = [];
    if (state.puzzle) {
      const lines = fitPuzzleLines(state.puzzle.text, 14, 4);
      const topPad = Math.max(0, Math.floor((4 - lines.length) / 2));
      for (let r = 0; r < 4; r++) {
        const lineIdx = r - topPad;
        const line = (lineIdx >= 0 && lineIdx < lines.length) ? lines[lineIdx] : '';
        const leftPad = Math.max(0, Math.floor((14 - line.length) / 2));
        const cells = [];
        for (let c = 0; c < 14; c++) {
          const idx = c - leftPad;
          const ch = idx >= 0 && idx < line.length ? line[idx] : '';
          cells.push({
            char: (!ch || ch === ' ') ? '' : (!/[A-Z]/.test(ch) || state.revealed.has(ch) ? ch : ''),
            active: !!ch && ch !== ' ',
            revealed: !!ch && (!/[A-Z]/.test(ch) || state.revealed.has(ch))
          });
        }
        boardRows.push(cells);
      }
    }
    window.WheelBuzzer.setGameState({
      activePlayer: state.activePlayer,
      spinEnabled: remoteSpinAllowed(),
      status: remoteSpinAllowed() ? `${state.cfg.players[state.activePlayer]?.name || 'Player'} may spin` : 'Wait for the host',
      category: state.puzzle?.cat || '',
      puzzle: phonePuzzle,
      boardRows,
      advantages: (state.cfg.players || []).map((_,i) => {
        const held=[];
        const wild=(state.wildCards&&state.wildCards[i])||0;
        if(wild)held.push(`Wild Card${wild>1?' ×'+wild:''}`);
        if(i===state.activePlayer&&state.freePlay)held.push('Free Play');
        if(i===state.activePlayer&&state.expressMode)held.push('Express');
        if(i===state.activePlayer&&state.pendingDouble)held.push('2× Consonant');
        return held;
      }),
      wildCardCounts: (state.cfg.players || []).map((_,i)=>(state.wildCards&&state.wildCards[i])||0),
      wildArmedPlayer: Number.isInteger(state.wildArmedPlayer) ? state.wildArmedPlayer : null,
      canGuess: !!state.canGuess
    });
  }

  function showSpecialNotice(title, copy, kicker='SPECIAL WEDGE'){
    publishAudienceSpin('audience-notice',{title,copy,kicker});
    if(buzzerAvailable()&&window.WheelBuzzer.broadcastNotice)window.WheelBuzzer.broadcastNotice({title,copy,kicker});
  }
  function clearSpecialNotice(){
    publishAudienceSpin('audience-notice-clear');
    if(buzzerAvailable()&&window.WheelBuzzer.clearNotice)window.WheelBuzzer.clearNotice();
  }

  /* ---------- persistence ---------- */
  const AVATAR_OPTIONS = ['🐼','🦁','🐯','🦊','🐻','🐨','🐶','🐱','🐰','🦝','🐸','🦄','🐵','🐧','🦉','🐺','🐮','🐷','🐔','🦒','🐘','🦓','🐢','🦋'];
  const COLOR_PRESETS = ['#ff2f7f','#ffd60a','#27d9ff','#39d353','#b07bff','#ff7042','#1463ff','#00b88a'];
  function normalizePlayers(arr){
    if (!Array.isArray(arr)) return defaults.players.slice();
    return arr.map((p, i) => {
      if (typeof p === 'string') {
        return { name: p, color: COLOR_PRESETS[i % COLOR_PRESETS.length], avatar: AVATAR_OPTIONS[i % AVATAR_OPTIONS.length] };
      }
      return {
        name: (p && p.name) || `Player ${i+1}`,
        color: (p && p.color) || COLOR_PRESETS[i % COLOR_PRESETS.length],
        avatar: (p && p.avatar) || AVATAR_OPTIONS[i % AVATAR_OPTIONS.length]
      };
    });
  }
  function load(){
    try {
      const cfg = Object.assign({}, defaults, JSON.parse(storageGet('spinSolveCfg', '{}') || '{}'));
      if (validateImportedCfg(cfg)) return JSON.parse(JSON.stringify(defaults));
      cfg.puzzles = cfg.puzzles.map(p => ({...p, text:p.text.trim().toUpperCase().replace(/\s+/g,' ')}));
      let repairedCfg = false;
      cfg.players = normalizePlayers(cfg.players);
      // V3.1 adopts the complete four-round television cadence. Migrate only
      // older three-round builds; later user choices remain untouched.
      if (!cfg.buildVersion || cfg.buildVersion < 31) {
        if ((cfg.roundCount | 0) === 3) cfg.roundCount = 4;
        cfg.buildVersion = 31;
        repairedCfg = true;
      }
      if (!cfg.buildVersion || cfg.buildVersion < 32) {
        if (!cfg.bonusTimerSeconds || cfg.bonusTimerSeconds === 10) cfg.bonusTimerSeconds = 20;
        cfg.buildVersion = 32;
        repairedCfg = true;
      }
      if (!cfg.buildVersion || cfg.buildVersion < 33) {
        cfg.buildVersion = 33;
        repairedCfg = true;
      }
      if (!cfg.buildVersion || cfg.buildVersion < 40) {
        cfg.slices = (Array.isArray(cfg.slices) ? cfg.slices : defaults.slices).filter(s => !['GIFT','DOUBLE'].includes(String(s).toUpperCase()));
        cfg.visualTheme = cfg.visualTheme || 'classic';
        cfg.buildVersion = 40;
        repairedCfg = true;
      }
      if (!cfg.buildVersion || cfg.buildVersion < 41) {
        if(Array.isArray(window.WHEEL_V4_PUZZLES)&&window.WHEEL_V4_PUZZLES.length>5000&&(!Array.isArray(cfg.puzzles)||cfg.puzzles.length<=1200))cfg.puzzles=window.WHEEL_V4_PUZZLES.slice();
        cfg.puzzleDifficulty = cfg.puzzleDifficulty || 'random';
        cfg.sponsorEnabled = !!cfg.sponsorEnabled;
        cfg.sponsorSlides = Array.isArray(cfg.sponsorSlides) ? cfg.sponsorSlides : [];
        cfg.buildVersion = 41;
        repairedCfg = true;
      }
      if (!cfg.buildVersion || cfg.buildVersion < 42) {
        cfg.slices = (Array.isArray(cfg.slices) ? cfg.slices : defaults.slices).filter(s => !['GIFT','DOUBLE'].includes(String(s).toUpperCase()));
        cfg.buildVersion = 42;
        repairedCfg = true;
      }
      if (!cfg.buildVersion || cfg.buildVersion < 43) {
        const userPuzzles = (Array.isArray(cfg.puzzles) ? cfg.puzzles : []).filter(p => !p.theme);
        const next = Array.isArray(window.WHEEL_V4_PUZZLES) ? window.WHEEL_V4_PUZZLES.slice() : [];
        const seen = new Set(next.map(p => `${String(p.cat).toUpperCase()}|${String(p.text).toUpperCase()}`));
        userPuzzles.forEach(p => { const k=`${String(p.cat).toUpperCase()}|${String(p.text).toUpperCase()}`; if(!seen.has(k)){seen.add(k);next.push(p);} });
        if (next.length) cfg.puzzles = next;
        cfg.puzzleTheme = cfg.puzzleTheme || 'all';
        cfg.buildVersion = 43;
        repairedCfg = true;
      }
      if (!cfg.buildVersion || cfg.buildVersion < 47) {
        const custom = (Array.isArray(cfg.puzzles) ? cfg.puzzles : []).filter(p => p && p.custom === true);
        cfg.puzzles = (Array.isArray(window.UGSL_CORE_PUZZLES) ? window.UGSL_CORE_PUZZLES : defaults.puzzles).slice();
        custom.forEach(p => cfg.puzzles.push(Object.assign({}, p, {custom:true,theme:'general'})));
        cfg.puzzleTheme = 'all';
        cfg.buildVersion = 47;
        storageRemove('ugslPuzzleQueueV47');
        repairedCfg = true;
      }
      // Heal stale default names from older builds (shipped Red/Yellow/Blue).
      // Only triggers when the WHOLE set is exactly the old defaults, so custom
      // names are never touched.
      const oldDefaults = ['RED','YELLOW','BLUE'];
      if (Array.isArray(cfg.players) && cfg.players.length === 3 &&
          cfg.players.every((p,i) => (p.name||'').trim().toUpperCase() === oldDefaults[i])) {
        cfg.players = cfg.players.map((p,i) => Object.assign({}, p, { name: 'Player ' + (i+1) }));
        repairedCfg = true;
      }
      // Heal shipped toss-up reveal defaults to the calmer game-show cadence.
      // Preserve values a buyer intentionally customized in the editor.
      if (cfg.tossupRevealMs === 700 || cfg.tossupRevealMs === 2200) {
        cfg.tossupRevealMs = 1500;
        repairedCfg = true;
      }
      // Older or corrupted saved settings could contain a 1-4 second turn timer,
      // even though the current editor only supports 5-300 seconds. Heal those
      // values to the buyer-friendly default while preserving timer-off (0).
      const savedTimeLimit = Number(cfg.timeLimit);
      const healedTimeLimit = !Number.isFinite(savedTimeLimit)
        ? 20
        : (savedTimeLimit <= 0 ? 0 : (savedTimeLimit < 5 ? 20 : clampTimer(savedTimeLimit)));
      if (cfg.timeLimit !== healedTimeLimit) {
        cfg.timeLimit = healedTimeLimit;
        repairedCfg = true;
      }
      if (repairedCfg) storageSet('spinSolveCfg', JSON.stringify(cfg));
      return cfg;
    } catch(e){ return {...defaults}; }
  }
  function save(){ return storageSet('spinSolveCfg', JSON.stringify(state.cfg)); }

  /* ---------- TURN TIMER ---------- */
  function renderTimer(){
    const num = document.getElementById('timer-num');
    const pill = document.getElementById('timer-pill');
    if (!num || !pill) return;
    const enabled = (state.cfg.timeLimit || 0) > 0 || state.bonusTimerActive;
    pill.style.display = enabled ? '' : 'none';
    if (!enabled) return;
    if (!state.timerActive) {
      num.textContent = '--';
      pill.classList.remove('warn','urgent','expired');
      return;
    }
    num.textContent = Math.max(0, Math.ceil(state.timeLeft));
    const limit = state.timerLimit || state.cfg.timeLimit || 20;
    const pct = state.timeLeft / limit;
    pill.classList.toggle('warn',  pct > 0 && pct <= .5 && pct > .25);
    pill.classList.toggle('urgent', pct > 0 && pct <= .25);
    pill.classList.toggle('expired', state.timeLeft <= 0);
  }
  // A generation token guards the countdown interval. Every start/stop/pause bumps
  // it, so any orphaned interval (e.g. left over from a previous game or screen)
  // self-terminates on its next tick instead of corrupting the live timer. This is
  // the fix for stale timers accelerating the countdown and passing turns early.
  function syncTimeFromDeadline(){
    if (!state.timerDeadline) return state.timeLeft;
    state.timeLeft = Math.max(0, (state.timerDeadline - Date.now()) / 1000);
    return state.timeLeft;
  }

  function _armTimerInterval(){
    const gen = ++state.timerGen;
    const token = state.turnTimerToken;
    state.timerDeadline = Date.now() + Math.max(0, state.timeLeft) * 1000;
    const h = setInterval(() => {
      if (gen !== state.timerGen) { clearInterval(h); return; }  // stale → kill self
      syncTimeFromDeadline();
      renderTimer();
      if (state.timeLeft <= 0) {
        clearInterval(h);
        if (state.timerHandle === h) state.timerHandle = null;
        state.turnExpireHandle = setTimeout(() => {
          state.turnExpireHandle = null;
          if (gen !== state.timerGen || token !== state.turnTimerToken || !state.timerActive || state.roundOver) return;
          stopTurnTimer();
          onTurnTimeExpire();
        }, 350);
      }
    }, 100);
    state.timerHandle = h;
  }
  function startTurnTimer(){
    stopTurnTimer();
    const rawLimit = Number(state.cfg.timeLimit);
    let effectiveLimit = 0;
    if (Number.isFinite(rawLimit) && rawLimit > 0) {
      effectiveLimit = rawLimit < 5 ? 20 : clampTimer(rawLimit);
    } else if (!Number.isFinite(rawLimit)) {
      effectiveLimit = 20;
    }
    state.cfg.timeLimit = effectiveLimit;
    if (effectiveLimit <= 0) return;
    if (state.roundOver) return;
    state.timeLeft = effectiveLimit;
    state.timerLimit = effectiveLimit;
    state.turnTimerToken = (state.turnTimerToken | 0) + 1;
    state.timerActive = true;
    renderTimer();
    _armTimerInterval();
  }
  function pauseTimer(){
    syncTimeFromDeadline();
    state.timerGen = (state.timerGen | 0) + 1;   // invalidate the running tick
    if (state.timerHandle) { clearInterval(state.timerHandle); state.timerHandle = null; }
    state.timerDeadline = 0;
    renderTimer();
  }
  function resumeTimer(){
    if (!state.timerActive || state.timerHandle || state.roundOver) return;
    if (state.solveLocked) return; // don't resume while solve modal is open
    if (state.timeLeft <= 0) return;
    _armTimerInterval();
  }
  function stopTurnTimer(){
    state.turnTimerToken = (state.turnTimerToken | 0) + 1;
    state.timerGen = (state.timerGen | 0) + 1;   // invalidate any running tick
    if (state.timerHandle) { clearInterval(state.timerHandle); state.timerHandle = null; }
    if (state.turnExpireHandle) { clearTimeout(state.turnExpireHandle); state.turnExpireHandle = null; }
    state.timerDeadline = 0;
    state.timerActive = false;
    renderTimer();
  }
  function onTurnTimeExpire(){
    msg(`Time's up — turn passes.`);
    sfx.buzzer();
    state.canGuess = false;
    state.spinValue = null;
    state.freePlay = false;
    nextPlayer();
  }
  // Stop every gameplay timer/interval at once — called when leaving the game,
  // starting a new game, or on game over, so nothing leaks across screens/modes
  // and decrements the shared countdown of the next game.
  function stopAllGameTimers(){
    stopTurnTimer();
    if (typeof stopBonusTimer === 'function') stopBonusTimer();
    if (typeof stopTossupReveal === 'function') stopTossupReveal();
    if (state.advanceHandle) { clearInterval(state.advanceHandle); state.advanceHandle = null; }
    if (state.bonusReadyHandle) { clearTimeout(state.bonusReadyHandle); state.bonusReadyHandle = null; }
    state.bonusTimerActive = false;
    state.turnTransition = false;
    document.getElementById('hostTurnTransition')?.remove();
    if (typeof showAudio !== 'undefined') showAudio.stopAll();
    if (typeof customAudio !== 'undefined') customAudio.stopAll();
  }

  /* ---------- THEMES ---------- */
  const THEMES = ['classic','royal','hollywood','vegas'];
  function getTheme(){ return storageGet('spinSolveTheme', 'classic') || 'classic'; }
  function setTheme(name){
    const idx = THEMES.indexOf(name);
    const t = idx >= 0 ? name : 'classic';
    document.documentElement.setAttribute('data-theme', t);
    storageSet('spinSolveTheme', t);
  }
  const THEME_LABELS = {classic:'Classic TV',royal:'Royal Purple',hollywood:'Hollywood Red',vegas:'Vegas Gold'};
  function cycleTheme(){
    const cur = getTheme();
    const next = THEMES[(THEMES.indexOf(cur) + 1) % THEMES.length];
    setTheme(next);
    showThemeBanner(THEME_LABELS[next] || next.toUpperCase());
  }
  function showThemeBanner(label){
    let el = document.getElementById('theme-banner');
    if (!el) {
      el = document.createElement('div');
      el.id = 'theme-banner';
      el.className = 'theme-banner';
      document.body.appendChild(el);
    }
    el.textContent = label;
    el.classList.remove('show'); void el.offsetWidth; el.classList.add('show');
    clearTimeout(showThemeBanner._t);
    showThemeBanner._t = setTimeout(()=>el.classList.remove('show'), 1400);
  }

  /* ---------- BACKGROUND ---------- */
  function applyBackground(){
    const url = state.cfg.bgImage || '';
    const stage = document.getElementById('screen-classic');
    const party = document.getElementById('screen-party');
    [stage, party].forEach(el => {
      if (!el) return;
      if (url){
        el.style.backgroundImage = `linear-gradient(rgba(3,5,15,.55),rgba(3,5,15,.72)),url("${url}")`;
        el.style.backgroundSize = 'cover';
        el.style.backgroundPosition = 'center center';
        el.style.backgroundRepeat = 'no-repeat';
      } else {
        el.style.backgroundImage = '';
        el.style.backgroundSize = '';
        el.style.backgroundPosition = '';
        el.style.backgroundRepeat = '';
      }
    });
  }

  /* ---------- AUDIO ---------- */
  let ac = null;
  function ensureAudio(){
    if (state.muted) return null;
    if (!ac) {
      try { ac = new (window.AudioContext || window.webkitAudioContext)(); }
      catch(e){ return null; }
    }
    if (ac.state === 'suspended') ac.resume();
    return ac;
  }
  function tone(freq, dur, type='sine', gainV=.14, delay=0){
    const c = ensureAudio(); if (!c) return;
    const t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gainV, t + 0.005);
    g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(g).connect(c.destination);
    o.start(t); o.stop(t + dur + .02);
  }
  function spotifyMoment(ms=1200){try{window.WheelSpotify?.duck();document.dispatchEvent(new CustomEvent('wheel-native-duck',{detail:{duration:ms}}));setTimeout(()=>window.WheelSpotify?.restore(),ms)}catch(_){}}
  function seq(notes){
    let d = 0;
    notes.forEach(n => { tone(n[0], n[1], n[2]||'sine', n[3]||.14, d); d += n[1]*.65; });
    spotifyMoment(Math.max(700,(d+.3)*1000));
  }
  function tickSound(progress){
    const c = ensureAudio(); if (!c) return;
    const t = c.currentTime;
    const o = c.createOscillator(), g = c.createGain();
    o.type = 'triangle';
    // pitch glides down as wheel slows
    o.frequency.setValueAtTime(950 - progress*420, t);
    g.gain.setValueAtTime(.001, t);
    g.gain.linearRampToValueAtTime(.07, t + .003);
    g.gain.exponentialRampToValueAtTime(.0001, t + .045);
    o.connect(g).connect(c.destination);
    o.start(t); o.stop(t + .06);
  }
  function noiseBurst(dur=.6, gainV=.16){
    const c = ensureAudio(); if (!c) return;
    const t = c.currentTime;
    const buf = c.createBuffer(1, c.sampleRate*dur, c.sampleRate);
    const data = buf.getChannelData(0);
    for (let i=0;i<data.length;i++) data[i] = (Math.random()*2-1) * (1 - i/data.length);
    const src = c.createBufferSource(); src.buffer = buf;
    const g = c.createGain(); g.gain.value = gainV;
    const f = c.createBiquadFilter(); f.type='bandpass'; f.frequency.value=1800; f.Q.value=.9;
    src.connect(f).connect(g).connect(c.destination);
    src.start(t); src.stop(t + dur + .05);
  }

  // A dense room-applause texture made from randomized hand-clap impulses.
  // This replaces the old crowd-cheer recording.
  function applauseBurst(dur=2.5){
    spotifyMoment(dur*1000+350);
    const c = ensureAudio(); if (!c || state.muted || state.cfg.crowdEnabled === false) return;
    const length = Math.ceil(c.sampleRate * dur);
    const buf = c.createBuffer(2, length, c.sampleRate);
    for (let ch=0; ch<2; ch++) {
      const data = buf.getChannelData(ch);
      for (let clap=0; clap<190; clap++) {
        const start = Math.floor((Math.random() * dur) * c.sampleRate);
        const clapLen = Math.floor((.018 + Math.random() * .045) * c.sampleRate);
        const strength = .12 + Math.random() * .34;
        for (let j=0; j<clapLen && start+j<length; j++) {
          const env = Math.exp(-j / (clapLen * .22));
          data[start+j] += (Math.random()*2-1) * strength * env;
        }
      }
    }
    const src = c.createBufferSource(); src.buffer = buf;
    const hp = c.createBiquadFilter(); hp.type='highpass'; hp.frequency.value=480;
    const peak = c.createBiquadFilter(); peak.type='peaking'; peak.frequency.value=1650; peak.Q.value=.7; peak.gain.value=5;
    const g = c.createGain();
    const volume = Math.max(.08, Math.min(.55, Number(state.cfg.crowdVolume ?? .60) * .55));
    g.gain.setValueAtTime(.001, c.currentTime);
    g.gain.linearRampToValueAtTime(volume, c.currentTime + .18);
    g.gain.setValueAtTime(volume, c.currentTime + Math.max(.2,dur-.45));
    g.gain.exponentialRampToValueAtTime(.001, c.currentTime + dur);
    src.connect(hp).connect(peak).connect(g).connect(c.destination);
    src.start(); src.stop(c.currentTime + dur + .03);
  }

  // Licensed local recordings add crowd warmth and game-show tension while the
  // existing Web Audio tones keep immediate button feedback crisp. Everything is
  // lazy-played after a player gesture, so the game remains browser-policy safe.
  const showAudio = (() => {
    const files = {
      cheer: 'assets/audio/crowd-cheer.mp3',
      boo: 'assets/audio/friendly-boo.mp3',
      suspense: 'assets/audio/suspense-loop.mp3',
      victory: 'assets/audio/victory-sting.mp3'
    };
    const tracks = {};
    let suspenseWanted = false;

    function get(name){
      if (!tracks[name]) {
        const a = new Audio(files[name]);
        a.preload = 'auto';
        a.playsInline = true;
        tracks[name] = a;
      }
      return tracks[name];
    }
    function crowdOn(){ return !state.muted && state.cfg.crowdEnabled !== false; }
    function musicOn(){ return !state.muted && state.cfg.musicEnabled !== false; }
    function crowdVolume(){ return Math.max(0, Math.min(1, Number(state.cfg.crowdVolume ?? .60))); }
    function musicVolume(){ return Math.max(0, Math.min(1, Number(state.cfg.musicVolume ?? .22))); }
    function play(name, volume, loop=false){
      try {
        const a = get(name);
        a.pause();
        a.currentTime = 0;
        a.loop = loop;
        a.volume = volume;
        const p = a.play();
        if (p && typeof p.catch === 'function') p.catch(()=>{});
        return true;
      } catch (_) { return false; }
    }
    function duckSuspense(){
      const a = tracks.suspense;
      if (a && !a.paused) a.volume = Math.min(.07, musicVolume());
    }
    function restoreSuspense(){
      const a = tracks.suspense;
      if (a && suspenseWanted && musicOn()) a.volume = musicVolume();
    }
    function playEffect(name, volume){
      duckSuspense();
      const a = get(name);
      a.onended = restoreSuspense;
      return play(name, volume, false);
    }
    function stop(name){
      const a = tracks[name];
      if (!a) return;
      try { a.pause(); a.currentTime = 0; } catch (_) {}
    }
    function syncMusicButton(){
      const b = document.getElementById('btn-music');
      if (!b) return;
      const on = state.cfg.musicEnabled !== false;
      b.textContent = on ? '🎵 Moment Music On' : '🎵 Moment Music Off';
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    }
    return {
      playCheer(){ return crowdOn() && playEffect('cheer', crowdVolume()); },
      playBoo(){ return crowdOn() && playEffect('boo', crowdVolume() * .72); },
      playVictory(){
        suspenseWanted = false;
        stop('suspense');
        return musicOn() && playEffect('victory', Math.min(1, musicVolume() * 1.35));
      },
      playSuspense(){
        suspenseWanted = true;
        if (!musicOn()) return false;
        const a = get('suspense');
        if (!a.paused) { a.volume = musicVolume(); return true; }
        return play('suspense', musicVolume(), true);
      },
      stopSuspense(){ suspenseWanted = false; stop('suspense'); },
      stopAll(){ suspenseWanted = false; Object.keys(tracks).forEach(stop); },
      onMasterChanged(){
        if (state.muted) Object.keys(tracks).forEach(stop);
        else if (suspenseWanted) this.playSuspense();
      },
      setMusicEnabled(on){
        state.cfg.musicEnabled = !!on;
        if (!on) this.stopSuspense();
        save();
        syncMusicButton();
      },
      syncMusicButton
    };
  })();
  const customAudio = (()=>{
    const files={tossupSolve:'toss_up_solve.mp3',tossupMusic:'toss_up_music.mp3',speedUp:'speed_up.mp3',rstlne:'RSTLNE.mp3',puzzleSolve:'puzzle_solve.mp3',ding:'ding.mp3',countdown:'countdown.mp3',buzzer:'buzzer.mp3',bankrupt:'bankrupt.mp3'};
    const tracks={};
    const get=k=>tracks[k]||(tracks[k]=new Audio('assets/audio/custom/'+files[k]));
    function play(k,loop=false,volume=1){if(state.muted)return false;try{const a=get(k);a.pause();a.currentTime=0;a.loop=loop;a.volume=Math.max(0,Math.min(1,volume));document.dispatchEvent(new CustomEvent('wheel-game-audio-start',{detail:{key:k,loop}}));a.onended=()=>document.dispatchEvent(new CustomEvent('wheel-game-audio-end',{detail:{key:k}}));const p=a.play();p?.catch?.(()=>document.dispatchEvent(new CustomEvent('wheel-game-audio-end',{detail:{key:k}})));return true}catch(_){return false}}
    function stop(k){const a=tracks[k];if(a)try{a.pause();a.currentTime=0;a.loop=false;document.dispatchEvent(new CustomEvent('wheel-game-audio-end',{detail:{key:k}}))}catch(_){}}
    function stopAll(){Object.keys(tracks).forEach(stop)}
    return{play,stop,stopAll};
  })();
  const SOUND_PACKS = {
    tv: {
      correct:[[523.25,.13],[659.25,.20]],
      wrong:[[330,.16,'sawtooth',.12],[247,.26,'sawtooth',.12]],
      vowel:[[988,.08,'square',.10],[1319,.12,'square',.10]],
      free:[[659,.10],[784,.10],[988,.20]],
      lose:[[440,.18,'triangle'],[330,.30,'triangle']],
      solve:[[523,.12],[659,.12],[784,.12],[1047,.45,'sine',.18]],
      cha:[[988,.05,'square',.10],[1319,.05,'square',.10],[1760,.18,'sine',.14]],
      chime:[[1175,.08,'sine',.12],[1568,.14,'sine',.12]],
      fanfare:[[523,.10],[659,.10],[784,.10],[1047,.10],[1319,.40,'sine',.18]]
    },
    casino: {
      correct:[[1175,.10,'sine',.14],[1568,.16,'sine',.14]],
      wrong:[[200,.16,'square',.10],[150,.30,'square',.10]],
      vowel:[[1568,.08,'sine',.12],[2093,.12,'sine',.12]],
      free:[[880,.10,'sine',.14],[1175,.10,'sine',.14],[1568,.22,'sine',.14]],
      lose:[[523,.18,'sine',.12],[392,.30,'sine',.12]],
      solve:[[988,.10],[1319,.10],[1568,.10],[2093,.45,'sine',.18]],
      cha:[[1568,.04,'sine',.12],[2093,.04,'sine',.12],[2637,.20,'sine',.16]],
      chime:[[1976,.10,'sine',.12],[2637,.18,'sine',.12]],
      fanfare:[[880,.10],[1175,.10],[1568,.10],[2093,.10],[2637,.45,'sine',.20]]
    },
    arcade: {
      correct:[[440,.08,'square',.12],[880,.12,'square',.12]],
      wrong:[[150,.18,'square',.14],[100,.28,'square',.14]],
      vowel:[[660,.06,'square',.12],[990,.10,'square',.12]],
      free:[[523,.08,'square',.12],[784,.08,'square',.12],[1047,.18,'square',.14]],
      lose:[[330,.18,'square',.12],[220,.30,'square',.12]],
      solve:[[392,.08,'square'],[523,.08,'square'],[659,.08,'square'],[988,.36,'square',.16]],
      cha:[[523,.05,'square',.12],[784,.05,'square',.12],[1047,.18,'square',.14]],
      chime:[[988,.08,'square',.12],[1319,.14,'square',.12]],
      fanfare:[[392,.10,'square'],[523,.10,'square'],[659,.10,'square'],[988,.40,'square',.18]]
    }
  };
  function pack(){ return SOUND_PACKS[state.cfg && state.cfg.soundPack] || SOUND_PACKS.tv; }
  const sfx = {
    correct: () => seq(pack().correct),
    wrong:   () => customAudio.play('buzzer'),
    vowel:   () => seq(pack().vowel),
    free:    () => seq(pack().free),
    lose:    () => seq(pack().lose),
    solve:   () => customAudio.play('puzzleSolve'),
    tossupSolve:() => customAudio.play('tossupSolve'),
    ding:    (count=1) => {if(state.muted)return;spotifyMoment(Math.max(900,count*260+500));for(let i=0;i<count;i++)setTimeout(()=>{try{const a=new Audio('assets/audio/custom/ding.mp3');a.volume=.9;a.play().catch(()=>{})}catch(_){}},i*260)},
    applause:() => applauseBurst(2.5),
    boo:     () => { if (!showAudio.playBoo()) seq(pack().lose); },
    buzzer:  () => customAudio.play('buzzer'),
    laugh:   () => seq([[330,.09,'sine',.12],[410,.08,'sine',.12],[350,.09,'sine',.11],[445,.08,'sine',.12],[370,.11,'sine',.1],[480,.14,'sine',.11]]),
    drumroll:() => { for (let i=0;i<16;i++) setTimeout(()=>noiseBurst(.08,.13 + (i/180)), i*75); setTimeout(()=>seq([[784,.08],[1047,.18]]),1240); },
    chime:   () => seq(pack().chime),
    cha:     () => seq(pack().cha),
    fanfare: () => seq(pack().fanfare),
    bankrupt:() => customAudio.play('bankrupt'),
    wahwah:  () => seq([[392,.28,'sawtooth',.16],[349,.28,'sawtooth',.15],[294,.52,'sawtooth',.14]])
  };
  function openSoundboard(){
    ensureAudio();
    const panel = document.getElementById('soundboard-panel');
    if (panel) { panel.classList.add('show'); panel.setAttribute('aria-hidden','false'); }
  }
  function closeSoundboard(){
    const panel = document.getElementById('soundboard-panel');
    if (panel) { panel.classList.remove('show'); panel.setAttribute('aria-hidden','true'); }
  }
  function setMuted(m){
    state.muted = !!m;
    storageSet('spinSolveMuted', m ? '1':'0');
    document.querySelectorAll('.btn-mute').forEach(b => {
      b.textContent = m ? 'Sound Off' : 'Sound On';
      b.setAttribute('aria-pressed', m ? 'true' : 'false');
    });
    showAudio.onMasterChanged();
  }

  // Forgiving answer match: ignore spacing, punctuation and case so guesses like
  // "FIREWORK OUT" or "FIRE WORKOUT" all match the puzzle "FIRE WORK OUT".
  function answerMatches(guess, text){
    const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    return !!norm(text) && norm(guess) === norm(text);
  }

  /* ---------- modal ---------- */
  function forceCloseModal(){
    const modal = document.getElementById('modal');
    if (modal) { modal.classList.remove('show'); modal.setAttribute('aria-hidden','true'); }
    if (modalResolve) { const r = modalResolve; modalResolve = null; r(null); }
    forceCloseSolveModal(null);
  }

  function forceCloseSolveModal(value = null){
    const modal = document.getElementById('solve-modal');
    if (modal) { modal.classList.remove('show'); modal.setAttribute('aria-hidden','true'); }
    if (solveModalResolve) { const resolve = solveModalResolve; solveModalResolve = null; resolve(value); }
  }

  function openModal(opts){
    const modal = document.getElementById('modal');
    const title = document.getElementById('modal-title');
    const copy = document.getElementById('modal-copy');
    const input = document.getElementById('modal-input');
    const error = document.getElementById('modal-error');
    const confirm = document.getElementById('modal-confirm');
    const cancel = document.getElementById('modal-cancel');

    title.textContent = opts.title || '';
    copy.textContent = opts.copy || '';
    input.value = opts.value || '';
    input.placeholder = opts.placeholder || '';
    input.style.display = opts.input === false ? 'none' : 'block';
    error.textContent = '';
    confirm.textContent = opts.confirmText || 'Confirm';
    cancel.textContent = opts.cancelText || 'Cancel';
    modal.classList.add('show');
    modal.setAttribute('aria-hidden','false');
    if (opts.input !== false) setTimeout(()=>input.focus(), 0);
    else setTimeout(()=>confirm.focus(), 0);

    return new Promise(resolve => {
      modalResolve = resolve;
      const close = val => {
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden','true');
        confirm.onclick = null;
        cancel.onclick = null;
        input.onkeydown = null;
        modalResolve = null;
        resolve(val);
      };
      confirm.onclick = () => {
        const value = input.value.trim();
        if (opts.validate) {
          const problem = opts.validate(value);
          if (problem) { error.textContent = problem; return; }
        }
        close(opts.input === false ? true : value);
      };
      cancel.onclick = () => close(null);
      input.onkeydown = e => {
        if (e.key === 'Enter') confirm.click();
        if (e.key === 'Escape') cancel.click();
      };
    });
  }

  /* ---------- cubic-bezier solver (matches CSS spin easing) ---------- */
  function makeBezier(p1x,p1y,p2x,p2y){
    const ax=1-3*p2x+3*p1x, bx=3*p2x-6*p1x, cx=3*p1x;
    const ay=1-3*p2y+3*p1y, by=3*p2y-6*p1y, cy=3*p1y;
    const sx=t=>((ax*t+bx)*t+cx)*t;
    const sy=t=>((ay*t+by)*t+cy)*t;
    const dx=t=>(3*ax*t+2*bx)*t+cx;
    return x=>{
      let t=x;
      for(let i=0;i<8;i++){
        const v=sx(t)-x, d=dx(t);
        if(Math.abs(d)<1e-6) break;
        t-=v/d;
      }
      return sy(Math.max(0,Math.min(1,t)));
    };
  }
  const spinEase = makeBezier(.18,.85,.25,1);

  /* ---------- screens ---------- */
  const screens = ['title','setup','classic','party','edit'];
  function show(id){
    // Leaving the gameplay screen: kill all its timers so none keep ticking in the
    // background (and corrupt the next game's countdown).
    if (id !== 'classic') stopAllGameTimers();
    screens.forEach(s => document.getElementById('screen-'+s).classList.toggle('active', s===id));
    document.body.classList.toggle('classic-live', id === 'classic');
    document.body.classList.toggle('party-live', id === 'party');
    if (id === 'classic') scheduleClassicFit();
    setTimeout(publishAudienceDisplay, 0);
  }

  /* ---------- WHEEL ---------- */
  const SVGNS = 'http://www.w3.org/2000/svg';
  function buildLedRing(){
    const ring = document.querySelector('.wheel-wrap .led-ring');
    const wrap = document.querySelector('.wheel-wrap');
    if (!ring || !wrap || ring.dataset.built === '1') return;
    const N = 36;
    const layout = () => {
      ring.innerHTML = '';
      const w = wrap.clientWidth;
      const radius = (w / 2) + 14; // px outside the wheel edge
      for (let i = 0; i < N; i++){
        const led = document.createElement('span');
        led.className = 'led';
        const angle = (i / N) * 2 * Math.PI - Math.PI/2;
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;
        led.style.setProperty('--lx', x.toFixed(1) + 'px');
        led.style.setProperty('--ly', y.toFixed(1) + 'px');
        led.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px)`;
        led.style.setProperty('--i', i);
        ring.appendChild(led);
      }
    };
    layout();
    if (!buildLedRing._resizeBound){
      buildLedRing._resizeBound = true;
      window.addEventListener('resize', () => {
        document.querySelectorAll('.wheel-wrap .led-ring').forEach(r => { r.dataset.built = ''; });
        buildLedRing();
      });
    }
    ring.dataset.built = '1';
  }

  function buildWheel(svg, slices, cls){
    buildLedRing();
    svg.innerHTML = '';
    svg.style.transform = 'rotate(0deg)';
    const n = slices.length;
    const r = 190;
    // Excludes purple-tones — those are reserved for MYSTERY/DOUBLE/WILD/big-money wedges.
    const colors = ['#ff2e2e','#ff8c00','#ffd60a','#39d353','#1fb8d4','#1463ff','#00b88a','#ff5e3a','#ffb800','#27d4e8','#7ed957','#3a9bdc'];

    // gradients & filters for glossy 3D look
    const defs = document.createElementNS(SVGNS,'defs');
    defs.innerHTML = `
      <radialGradient id="wheelGloss" cx="40%" cy="22%" r="80%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.50"/>
        <stop offset="28%" stop-color="#ffffff" stop-opacity="0.16"/>
        <stop offset="55%" stop-color="#ffffff" stop-opacity="0"/>
        <stop offset="100%" stop-color="#000000" stop-opacity="0.22"/>
      </radialGradient>
      <radialGradient id="hubGloss" cx="36%" cy="26%" r="70%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.85"/>
        <stop offset="55%" stop-color="#ffffff" stop-opacity="0"/>
      </radialGradient>
      <radialGradient id="innerShadow" cx="50%" cy="50%" r="50%">
        <stop offset="75%" stop-color="#000000" stop-opacity="0"/>
        <stop offset="100%" stop-color="#000000" stop-opacity="0.32"/>
      </radialGradient>
      <radialGradient id="hubShadow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#000000" stop-opacity="0.18"/>
        <stop offset="60%" stop-color="#000000" stop-opacity="0"/>
        <stop offset="100%" stop-color="#000000" stop-opacity="0"/>
      </radialGradient>
      <linearGradient id="rimGold" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#fff3a0"/>
        <stop offset="35%" stop-color="#ffd60a"/>
        <stop offset="100%" stop-color="#7a5300"/>
      </linearGradient>
      <linearGradient id="rimGoldRev" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#7a5300"/>
        <stop offset="60%" stop-color="#ffd60a"/>
        <stop offset="100%" stop-color="#fff3a0"/>
      </linearGradient>
      ${colors.map((c,i)=>`<linearGradient id="metal${i}" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="${c}"/><stop offset="22%" stop-color="#fff" stop-opacity=".72"/><stop offset="38%" stop-color="${c}"/><stop offset="67%" stop-color="#030712" stop-opacity=".5"/><stop offset="84%" stop-color="${c}"/><stop offset="100%" stop-color="#fff" stop-opacity=".42"/></linearGradient>`).join('')}
      <linearGradient id="metalBlack" x1="0%" y1="0%" x2="100%" y2="100%"><stop stop-color="#020202"/><stop offset="30%" stop-color="#777"/><stop offset="44%" stop-color="#090909"/><stop offset="75%" stop-color="#333"/><stop offset="100%" stop-color="#000"/></linearGradient>
      <linearGradient id="mysteryGold" x1="0%" y1="0%" x2="100%" y2="100%"><stop stop-color="#5f3b00"/><stop offset="18%" stop-color="#fff3a0"/><stop offset="35%" stop-color="#d99800"/><stop offset="55%" stop-color="#fffbd0"/><stop offset="72%" stop-color="#b66a00"/><stop offset="100%" stop-color="#ffe66d"/></linearGradient>
      <filter id="goldSparkle"><feTurbulence type="fractalNoise" baseFrequency=".8" numOctaves="2" seed="7" result="noise"/><feColorMatrix in="noise" values="1 0 0 0 1 0 1 0 0 .82 0 0 1 0 .2 0 0 0 .55 0" result="spark"/><feBlend in="SourceGraphic" in2="spark" mode="screen"/></filter>
      <filter id="sliceShadow" x="-10%" y="-10%" width="120%" height="120%">
        <feGaussianBlur in="SourceAlpha" stdDeviation="2"/>
        <feOffset dx="0" dy="2"/>
        <feComponentTransfer><feFuncA type="linear" slope="0.6"/></feComponentTransfer>
        <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
      </filter>
    `;
    svg.appendChild(defs);

    slices.forEach((label,i) => {
      const a0 = (i / n) * 2 * Math.PI - Math.PI/2 - (Math.PI/n);
      const a1 = ((i+1)/n) * 2 * Math.PI - Math.PI/2 - (Math.PI/n);
      const x0 = r*Math.cos(a0), y0 = r*Math.sin(a0);
      const x1 = r*Math.cos(a1), y1 = r*Math.sin(a1);
      const path = document.createElementNS(SVGNS,'path');
      let fill;
      if (cls === 'classic') {
        if (label === 'BANKRUPT' || label === 'LOSE') fill = 'url(#metalBlack)';
        else if (label === 'MYSTERY') fill = 'url(#mysteryGold)';
        else fill = `url(#metal${i % colors.length})`;
      } else {
        fill = `url(#metal${i % colors.length})`;
      }
      path.setAttribute('d', `M0 0 L${x0} ${y0} A${r} ${r} 0 0 1 ${x1} ${y1} Z`);
      path.setAttribute('fill', fill);
      path.setAttribute('stroke', 'rgba(0,0,0,.35)');
      path.setAttribute('stroke-width', '0.6');
      if(label==='MYSTERY')path.setAttribute('filter','url(#goldSparkle)');
      svg.appendChild(path);

      // radial label — reads from center outward
      const mid = (a0+a1)/2;
      const long = label.length > 7;
      const radial = long ? 0.62 : 0.66;
      const tx = (r*radial)*Math.cos(mid);
      const ty = (r*radial)*Math.sin(mid);
      const t = document.createElementNS(SVGNS,'text');
      t.setAttribute('x', tx); t.setAttribute('y', ty);
      t.setAttribute('fill', label==='BANKRUPT' ? '#ffd60a' : '#ffffff');
      t.setAttribute('text-anchor','middle');
      t.setAttribute('dominant-baseline','middle');
      t.setAttribute('font-family','Arial Black, Segoe UI, sans-serif');
      t.setAttribute('font-weight','900');
      t.setAttribute('font-size', long ? '11' : '15');
      t.setAttribute('letter-spacing','0.5');
      t.setAttribute('stroke','#07101d');
      t.setAttribute('stroke-width','1.4');
      t.setAttribute('paint-order','stroke');
      const flip = Math.cos(mid) < 0;
      const rotDeg = (mid * 180 / Math.PI) + (flip ? 180 : 0);
      t.setAttribute('transform',`rotate(${rotDeg} ${tx} ${ty})`);
      const display = (cls==='classic' && /^\d+$/.test(label)) ? '$'+label : label;
      t.textContent = display;
      svg.appendChild(t);
    });

    // hub-side darkening (gives slices "depth" near center)
    const hubShadow = document.createElementNS(SVGNS,'circle');
    hubShadow.setAttribute('r', 95);
    hubShadow.setAttribute('fill', 'url(#hubShadow)');
    hubShadow.setAttribute('pointer-events','none');
    svg.appendChild(hubShadow);

    // glossy specular overlay — radial light from top-left
    const gloss = document.createElementNS(SVGNS,'circle');
    gloss.setAttribute('r', r);
    gloss.setAttribute('fill', 'url(#wheelGloss)');
    gloss.setAttribute('pointer-events','none');
    svg.appendChild(gloss);

    // inner-shadow ring on outer edge (vignette inside the rim)
    const vign = document.createElementNS(SVGNS,'circle');
    vign.setAttribute('r', r);
    vign.setAttribute('fill', 'url(#innerShadow)');
    vign.setAttribute('pointer-events','none');
    svg.appendChild(vign);

    // gold pegs between slices on outer rim
    const pegR = r - 2;
    for (let i = 0; i < n; i++){
      const a = (i / n) * 2 * Math.PI - Math.PI/2 - (Math.PI/n);
      const px = pegR * Math.cos(a);
      const py = pegR * Math.sin(a);
      const peg = document.createElementNS(SVGNS,'circle');
      peg.setAttribute('cx', px);
      peg.setAttribute('cy', py);
      peg.setAttribute('r', 3);
      peg.setAttribute('fill','#fff8c8');
      peg.setAttribute('stroke','#7a5300');
      peg.setAttribute('stroke-width','0.6');
      svg.appendChild(peg);
    }

    // outer gold rim — double-band (outer light, inner dark) for chiseled look
    const ringOuter = document.createElementNS(SVGNS,'circle');
    ringOuter.setAttribute('r', r + 5); ringOuter.setAttribute('fill','none');
    ringOuter.setAttribute('stroke','url(#rimGold)'); ringOuter.setAttribute('stroke-width','7');
    svg.appendChild(ringOuter);
    const ringInner = document.createElementNS(SVGNS,'circle');
    ringInner.setAttribute('r', r - 2); ringInner.setAttribute('fill','none');
    ringInner.setAttribute('stroke','url(#rimGoldRev)'); ringInner.setAttribute('stroke-width','3');
    svg.appendChild(ringInner);
    const ring = document.createElementNS(SVGNS,'circle');
    ring.setAttribute('r', r); ring.setAttribute('fill','none');
    ring.setAttribute('stroke','#5a3e00'); ring.setAttribute('stroke-width','1');
    svg.appendChild(ring);

    // inner ring (around hub)
    const inner = document.createElementNS(SVGNS,'circle');
    inner.setAttribute('r', 60); inner.setAttribute('fill','none');
    inner.setAttribute('stroke','url(#rimGold)'); inner.setAttribute('stroke-width','5');
    svg.appendChild(inner);
    const innerHi = document.createElementNS(SVGNS,'circle');
    innerHi.setAttribute('r', 60); innerHi.setAttribute('fill','url(#hubGloss)');
    innerHi.setAttribute('pointer-events','none');
    svg.appendChild(innerHi);
  }

  let wheelAngle = 0;
  function spinWheel(svg, slices, onDone, profile = {}){
    if (state.spinning) return;
    state.spinning = true;
    syncRemoteControls();
    document.body.classList.add('is-spinning');
    svg.parentElement.classList.add('spinning');
    pauseTimer();
    ensureAudio();
    const n = slices.length;
    const idx = Math.floor(Math.random()*n);
    const sliceAngle = 360/n;
    const startRot = wheelAngle;
    const turns = Math.max(3, Math.min(10, Number(profile.turns) || 5));
    const target = startRot + (360*turns) + ((360 - idx*sliceAngle) - (startRot % 360));
    wheelAngle = target;
    const total = target - startRot;
    const dur = Math.max(2400, Math.min(8500, Number(profile.duration) || 5200));
    spotifyMoment(dur+900);
    svg.style.transition = `transform ${dur}ms cubic-bezier(.18,.85,.25,1)`;
    svg.style.transform = `rotate(${target}deg)`;
    if (svg.id === 'wheel-big') {
      const player = state.cfg.players[state.activePlayer] || {};
      publishAudienceSpin('audience-spin-start', {
        wheelHtml: svg.innerHTML, startRot, target, duration: dur,
        playerName: player.name || 'Player', playerColor: player.color || '#ffd60a'
      });
    }
    // schedule ticks via rAF synced to easing
    const t0 = performance.now();
    let crossed = 0;
    let done = false;
    const epoch = state.epoch;
    function finish(){
      if (done) return; done = true;
      if (epoch !== state.epoch) return;
      state.spinning = false;
      document.body.classList.remove('is-spinning');
      svg.parentElement.classList.remove('spinning');
      const ptr = svg.parentElement.querySelector('.pointer');
      if (ptr){ ptr.classList.remove('flick'); void ptr.offsetWidth; ptr.classList.add('flick'); }
      onDone(slices[idx], idx);
      if (svg.id === 'wheel-big') publishAudienceSpin('audience-spin-result', { label: slices[idx] });
    }
    function loop(now){
      if (done) return;
      const p = Math.min(1, (now - t0) / dur);
      const eased = spinEase(p);
      const cur = total * eased;
      const should = Math.floor(cur / sliceAngle);
      while (crossed < should){ tickSound(p); crossed++; }
      if (p < 1) requestAnimationFrame(loop);
      else finish();
    }
    requestAnimationFrame(loop);
    // Hard fallback: if rAF is throttled (hidden tab, low-power, etc.) finish anyway just past dur
    setTimeout(finish, dur + 200);
  }

  /* ---------- PUZZLE ---------- */
  const PUZZLE_WORD_IGNORE=new Set(['A','AN','AND','ARE','AT','FOR','FROM','IN','IS','IT','MY','OF','ON','OR','THE','TO','WITH','YOUR']);
  function puzzleWords(text){return String(text||'').toUpperCase().match(/[A-Z]+/g)?.filter(w=>w.length>2&&!PUZZLE_WORD_IGNORE.has(w))||[]}
  function isSensiblePuzzle(p){
    const cat=String(p?.cat||'').toUpperCase(),text=String(p?.text||'').trim().toUpperCase();
    if(!text||text.length>42||!/^[A-Z0-9 &'!?-]+$/.test(text))return false;
    if(cat==='SONG LYRICS'&&!p.verifiedLyrics)return false;
    if(/\b([A-Z]{3,})\s+\1\b/.test(text))return false;
    if(/^PLANNING (A|AN|THE)\b/.test(text))return false;
    if(cat.includes('PLACE')&&/^(BEYOND|FINDING|SING ABOUT|ENJOYING|PLANNING|TASTING|MEETING)\b/.test(text))return false;
    if(cat==="WHAT ARE YOU DOING?"&&!/\b[A-Z]+ING\b/.test(text))return false;
    return true;
  }
  function preferDistinctPuzzleWords(src){
    const used=new Set(),clean=[],deferred=[];
    src.forEach(p=>{const words=puzzleWords(p.text),overlap=words.some(w=>used.has(w));if(overlap)deferred.push(p);else{clean.push(p);words.forEach(w=>used.add(w));}});
    return clean.concat(deferred);
  }
  const PUZZLE_QUEUE_KEY='ugslPuzzleQueueV47';
  function puzzleId(p){
    if(p&&p.id)return String(p.id);
    const s=`${String(p?.cat||'').toUpperCase()}|${String(p?.text||'').toUpperCase()}`;let h=2166136261;
    for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
    return `custom-${(h>>>0).toString(36)}`;
  }
  function shuffled(values){const a=values.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
  function queueSignature(ids){let h=2166136261;ids.slice().sort().forEach(id=>{for(let i=0;i<id.length;i++){h^=id.charCodeAt(i);h=Math.imul(h,16777619)}});return `${ids.length}-${(h>>>0).toString(36)}`}
  function loadQueueBook(){try{const x=JSON.parse(storageGet(PUZZLE_QUEUE_KEY,'{}')||'{}');return x&&typeof x==='object'&&x.pools?x:{pools:{}}}catch(_){return{pools:{}}}}
  function saveQueueBook(book){const keys=Object.keys(book.pools||{}).sort((a,b)=>(book.pools[b].t||0)-(book.pools[a].t||0));keys.slice(12).forEach(k=>delete book.pools[k]);storageSet(PUZZLE_QUEUE_KEY,JSON.stringify(book))}
  function drawQueuedPuzzles(src,phases){
    if(!src.length)return[];
    const byId=new Map(src.map(p=>[puzzleId(p),p])),ids=[...byId.keys()],sig=queueSignature(ids),book=loadQueueBook();
    let q=book.pools[sig]||{queue:shuffled(ids),used:[],history:[],t:Date.now()};
    q.queue=(Array.isArray(q.queue)?q.queue:[]).filter(id=>byId.has(id));
    ids.filter(id=>!q.queue.includes(id)).forEach(id=>q.queue.push(id));
    let used=new Set((Array.isArray(q.used)?q.used:[]).filter(id=>byId.has(id))),history=Array.isArray(q.history)?q.history.filter(id=>byId.has(id)):[];
    const picked=[];
    (phases||[]).forEach(phase=>{
      let available=q.queue.filter(id=>!used.has(id));
      if(!available.length){used.clear();q.queue=shuffled(q.queue);available=q.queue.slice()}
      const tier=diffForPhase(phase),order={easy:['easy','med','hard'],med:['med','easy','hard'],hard:['hard','med','easy']}[tier];
      let chosen=null;
      if(phase?.type==='bonus')chosen=available.find(id=>{const p=byId.get(id),s=bonusRevealStats(p);return normDiff(p.diff)===tier&&s.ratio<=.45&&s.hidden>=9});
      if(!chosen)for(const d of order){chosen=available.find(id=>normDiff(byId.get(id).diff)===d);if(chosen)break}
      chosen=chosen||available[0];const p=byId.get(chosen);if(!p)return;
      picked.push(p);used.add(chosen);history.push(chosen);if(history.length>ids.length)history=history.slice(-ids.length);
      q.queue=q.queue.filter(id=>id!==chosen);q.queue.push(chosen);
    });
    q.used=[...used];q.history=history;q.t=Date.now();book.pools[sig]=q;saveQueueBook(book);
    return picked;
  }
  function buildActivePuzzles(){
    let src = (state.cfg.puzzles || []).filter(isSensiblePuzzle);
    const puzzleTheme=String(state.cfg.puzzleTheme||'all');
    if(puzzleTheme!=='all'){
      const themed=(window.UGSL_THEME_PACKS?.[puzzleTheme]||[]).filter(isSensiblePuzzle);
      if(themed.length)src=themed;
    }
    const enabled = state.cfg.enabledCategories;
    if (Array.isArray(enabled) && enabled.length > 0) {
      const set = new Set(enabled.map(c => String(c).toUpperCase()));
      const filtered = src.filter(p => set.has(String(p.cat).toUpperCase()));
      if (filtered.length) src = filtered;
    }
    // Audience cap: keep the night age-appropriate. 'kids' = easy only, 'family' = no hard.
    const md = state.cfg.maxDiff || 'all';
    if (md === 'kids' || md === 'family') {
      const allow = md === 'kids' ? new Set(['easy']) : new Set(['easy', 'med']);
      const capped = src.filter(p => allow.has(normDiff(p.diff)));
      if (capped.length) src = capped;
    }
    const requestedDiff=String(state.cfg.puzzleDifficulty||'random');
    if(['easy','med','hard'].includes(requestedDiff)){
      const exact=src.filter(p=>normDiff(p.diff)===requestedDiff);
      if(exact.length)src=exact;
    }
    src=preferDistinctPuzzleWords(src);
    // Full eligible pool (category/difficulty-filtered) - the bonus, qualifier and
    // tiebreaker draw fresh puzzles from THIS, not the tiny per-phase activePuzzles
    // list, so they never have to reuse a phrase the players already solved.
    state._fullPool = src.slice();
    state.phases = buildPhases();
    if (state.cfg.roundMode && state.phases && state.phases.length) {
      // Difficulty-tiered draw: each phase gets a puzzle matching its tier.
      // Deterministic when shuffle is off (so refresh-resume restores the same set);
      // randomized within the pool when shuffle is on (replayability).
      state.activePuzzles = drawQueuedPuzzles(src, state.phases);
    } else if (state.cfg.roundMode) {
      state.activePuzzles = drawQueuedPuzzles(src,buildPhases());
    } else {
      const limit = state.cfg.maxRounds | 0;
      const count=(limit>0&&limit<src.length)?limit:Math.min(20,src.length);
      state.activePuzzles = drawQueuedPuzzles(src,Array.from({length:count},(_,i)=>({type:'round',num:i+1})));
      state.phases = buildPhases();
    }
  }

  // Maps a phase to its intended difficulty tier.
  function diffForPhase(phase){
    if (!phase) return 'med';
    if (phase.type === 'tossup') return 'easy';
    if (phase.type === 'bonus')  return 'hard';
    if (phase.type === 'round') {
      const n = phase.num || 1;
      if (n <= 1) return 'easy';
      if (n === 2) return 'med';
      return 'hard';
    }
    return 'med';
  }

  // Single source of truth for difficulty normalization. Accepts any casing,
  // the e/h/m shorthand, or full words; anything unrecognized falls back to med.
  function normDiff(d){
    d = String(d || '').toLowerCase();
    if (d === 'easy' || d === 'e') return 'easy';
    if (d === 'hard' || d === 'h') return 'hard';
    return 'med';
  }

  function bonusRevealStats(puzzle){
    const base = new Set(['R','S','T','L','N','E']);
    const letters = [...String(puzzle?.text || '')].filter(ch => /[A-Z]/.test(ch));
    const revealed = letters.filter(ch => base.has(ch)).length;
    return {
      ratio: letters.length ? revealed / letters.length : 1,
      hidden: letters.length - revealed,
    };
  }

  // Returns one puzzle per phase, drawn from the matching difficulty pool with
  // graceful fallback to adjacent tiers. Avoids repeats until a pool is exhausted.
  function drawTieredPuzzles(src, phases){
    return drawQueuedPuzzles(src,phases);
  }

  // Continue a configured series (toss-up values / multipliers) past its given
  // length so any round count keeps escalating instead of plateauing on the last
  // value. Beyond the list it steps by the series' own increment, or defStep.
  function escalateSeries(arr, i, defStep){
    const n = arr.length;
    if (i < n) return Number(arr[i]);
    const last = Number(arr[n - 1]);
    const prev = n >= 2 ? Number(arr[n - 2]) : last;
    const step = (n >= 2 && (last - prev) > 0) ? (last - prev) : defStep;
    return last + step * (i - (n - 1));
  }

  function buildPhases(){
    if (!state.cfg.roundMode) {
      const list = state.activePuzzles || state.cfg.puzzles || [];
      return list.map((_, i) => ({ type: 'round', mult: 1, num: i + 1 }));
    }
    const tossupOn = state.cfg.tossupEnabled !== false;
    const bonusOn = state.cfg.bonusEnabled !== false;
    const tvs = (Array.isArray(state.cfg.tossupValues) && state.cfg.tossupValues.length
      ? state.cfg.tossupValues : [1000, 2000, 3000]).map(n => Number(n) || 1000);
    const mults = (Array.isArray(state.cfg.roundMultipliers) && state.cfg.roundMultipliers.length
      ? state.cfg.roundMultipliers : [1, 1.5, 2]).map(n => Number(n) || 1);
    const rc = Math.max(1, Math.min(20, state.cfg.roundCount | 0 || 4));
    const seq = [];
    // Broadcast-style cadence: two opening toss-ups, Rounds 1–3, a triple
    // toss-up, then Round 4 and any configured extra rounds.
    if (tossupOn) {
      seq.push({ type:'tossup', value:tvs[0] || 1000, num:1, label:'FIRST TOSS-UP' });
      seq.push({ type:'tossup', value:tvs[1] || 2000, num:2, label:'SECOND TOSS-UP' });
    }
    for (let i=0;i<Math.min(3,rc);i++) seq.push({type:'round',mult:escalateSeries(mults,i,.5),num:i+1});
    if (tossupOn && rc >= 4) {
      for (let i=1;i<=3;i++) seq.push({type:'tossup',value:2000,num:i+2,triple:i,label:`TRIPLE TOSS-UP ${i} OF 3`});
    }
    for (let i=3;i<rc;i++) seq.push({type:'round',mult:escalateSeries(mults,i,.5),num:i+1});
    if (bonusOn) seq.push({ type: 'bonus' });
    return seq;
  }

  function currentPhase(){
    if (!state.phases || !state.phases.length) state.phases = buildPhases();
    const i = Math.max(0, Math.min(state.puzzleIdx, state.phases.length - 1));
    return state.phases[i] || { type: 'round', mult: 1, num: 1 };
  }

  function currentRoundMultiplier(){
    const p = currentPhase();
    if (!p || p.type !== 'round') return 1;
    return Number(p.mult) > 0 ? Number(p.mult) : 1;
  }

  function currentWheelSlices(){
    const base = (state.cfg.slices || []).slice();
    const phase = currentPhase();
    if (!phase || phase.type !== 'round') return base;
    return base.map(label => {
      if (label !== 'MYSTERY') return label;
      if (phase.num === 1) return 'FREE';
      if (phase.num === 2) return 'MYSTERY';
      if (phase.num === 3) return 'EXPRESS';
      return 'FREE';
    });
  }

  function loadPuzzle(idx, completed = false){
    state.epoch = (state.epoch || 0) + 1;
    state.spinPending = false;
    state.spinning = false;
    state.turnTransition = false;
    document.getElementById('hostTurnTransition')?.remove();
    state.solveLocked = false;
    state.tossupStarted = false;
    state.tossupLockout = new Set();
    state.tossupQueue = [];
    state.pendingDouble = false;
    pendingBuzzPid = null;
    if (buzzerAvailable()) window.WheelBuzzer.reset();
    document.getElementById('wheel-overlay')?.classList.remove('show');
    document.body.classList.remove('is-spinning');
    forceCloseModal();
    state.scores = state.cfg.players.map(() => 0);
    if (!state.activePuzzles || !state.activePuzzles.length) buildActivePuzzles();
    const list = state.activePuzzles;
    state.puzzleIdx = ((idx % list.length) + list.length) % list.length;
    state.puzzle = list[state.puzzleIdx];
    state.revealed = new Set();
    state.used = new Set();
    state.hintsUsed = (state.cfg.players || []).map(() => false); // one hint per player, per round
    state.canGuess = false;
    state.spinValue = null;
    state.freePlay = false;
    state.expressMode = false;
    state.speedUpMode = false;
    state.speedUpAwaitingSpin = false;
    customAudio.stop('speedUp');customAudio.stop('countdown');customAudio.stop('rstlne');
    state.speedUpValue = 0;
    state.roundOver = false;
    state.bonusDuelActive = false;   // a normal puzzle load is never a bonus duel
    state.duelRecovery = null;
    if (state.advanceHandle) { clearInterval(state.advanceHandle); state.advanceHandle = null; }
    stopTossupReveal();
    stopBonusTimer();
    clearRoundFeedback();
    state.phase = currentPhase();
    const nextRoundBtn = document.getElementById('btn-next-round');
    if (nextRoundBtn) nextRoundBtn.style.display = 'none';
    const phaseSlices = currentWheelSlices();
    const mainWheel = document.getElementById('wheel');
    const overlayWheel = document.getElementById('wheel-big');
    if (mainWheel) buildWheel(mainWheel, phaseSlices, 'classic');
    if (overlayWheel) buildWheel(overlayWheel, phaseSlices, 'classic');
    document.getElementById('category').textContent = state.puzzle.cat;
    const totalEl = document.getElementById('round-total');
    const numEl = document.getElementById('round-num');
    const labelEl = document.getElementById('round-label');
    const sepEl = document.getElementById('round-sep');
    // Default the label/separator back (a prior bonus may have changed them).
    if (labelEl) labelEl.textContent = 'Round';
    if (sepEl) sepEl.style.display = '';
    if (totalEl) totalEl.style.display = '';
    if (state.cfg.roundMode && state.phase) {
      const totalRounds = Math.max(1, state.cfg.roundCount | 0 || 4);
      if (state.phase.type === 'round') {
        if (numEl) numEl.textContent = state.phase.num || (state.puzzleIdx + 1);
        if (totalEl) totalEl.textContent = totalRounds;
      } else if (state.phase.type === 'tossup') {
        if (numEl) numEl.textContent = 'T' + (state.phase.num || '');
        if (totalEl) totalEl.textContent = totalRounds;
      } else if (state.phase.type === 'bonus') {
        if (labelEl) labelEl.textContent = 'Final';
        if (numEl) numEl.textContent = 'BONUS';
        if (sepEl) sepEl.style.display = 'none';
        if (totalEl) { totalEl.textContent = ''; totalEl.style.display = 'none'; }
      } else {
        if (numEl) numEl.textContent = state.puzzleIdx + 1;
        if (totalEl) totalEl.textContent = list.length;
      }
    } else {
      if (totalEl) totalEl.textContent = list.length;
      if (numEl) numEl.textContent = state.puzzleIdx + 1;
    }
    const multPill = document.getElementById('mult-pill');
    const multNum = document.getElementById('mult-num');
    if (multPill && multNum) {
      const m = currentRoundMultiplier();
      // Always show during normal rounds (so the topbar layout is stable); value reflects current multiplier.
      const show = state.cfg.roundMode && state.phase.type === 'round';
      multPill.style.display = show ? '' : 'none';
      multNum.textContent = (m % 1 === 0 ? m : m.toFixed(1)) + 'x';
    }
    const vowelBtn = document.getElementById('btn-vowel');
    if (vowelBtn) vowelBtn.textContent = `Buy Vowel ($${state.cfg.vowelCost ?? 250})`;
    renderPuzzle();
    renderBank();
    applyPhaseUI(state.phase);
    if (completed) { state.roundOver = true; }
    else if (state.phase.type === 'tossup') {
      setupTossup(state.phase);
    } else if (state.phase.type === 'bonus') {
      const bonusPhase=state.phase;
      showPreBonusPodium(()=>{if(state.phase===bonusPhase&&!state.roundOver)setupBonus(bonusPhase)});
    } else {
      // Main round: toss-up winner of the previous phase starts this round.
      if (typeof state.tossupWinner === 'number' && state.tossupWinner >= 0 && state.tossupWinner < state.cfg.players.length) {
        state.activePlayer = state.tossupWinner;
        state.tossupWinner = null;
        renderScore(); // make the new active player visible immediately
      }
      msg('Spin the wheel to call a consonant.');
      stopTurnTimer();
      setTimeout(()=>showTurnTransition(state.activePlayer),250);
    }
    showPhaseAnnouncer(state.phase);
    // Re-fit the stage: phases change the content height (toss-up/bonus add a banner).
    scheduleClassicFit();
    // Replace any completed-round resume snapshot as soon as the next puzzle begins.
    saveGame();
  }

  function bumpStreak(playerIdx){
    if (!state.streaks) state.streaks = state.cfg.players.map(()=>0);
    state.streaks[playerIdx] = (state.streaks[playerIdx] || 0) + 1;
    return state.streaks[playerIdx];
  }
  function resetStreak(playerIdx){
    if (!state.streaks) state.streaks = state.cfg.players.map(()=>0);
    state.streaks[playerIdx] = 0;
  }
  function showStreakBadge(streak, bonusPct){
    const label = streak >= 5 ? '🔥 ON FIRE' : 'STREAK';
    const el = document.createElement('div');
    el.className = 'streak-badge';
    el.innerHTML = `<span class="sb-label">${label}</span><span class="sb-count">×${streak}</span><span class="sb-bonus">+${Math.round(bonusPct*100)}%</span>`;
    document.body.appendChild(el);
    requestAnimationFrame(()=>el.classList.add('show'));
    setTimeout(()=>el.classList.remove('show'), 1500);
    setTimeout(()=>el.remove(), 2000);
  }

  function showRoundSummary(winnerIdx, earned, roundBank, solveBonus, awardLabel){
    const winner = state.cfg.players[winnerIdx];
    if (!winner) return;
    const minimumApplied = earned > roundBank;
    const standings = state.cfg.players.map((p,i)=>({name:p.name,color:p.color,avatar:p.avatar,total:state.totals[i]||0,isWinner:i===winnerIdx}))
      .sort((a,b)=>b.total-a.total);
    const el = document.createElement('div');
    el.className = 'round-summary';
    el.innerHTML = `
      <div class="rs-card">
        <div class="rs-banner">ROUND ${ (state.phase && state.phase.num) || (state.puzzleIdx + 1) } RESULT</div>
        <div class="rs-winner" style="--p-color:${winner.color}">
          <div class="rs-avatar">${avatarHtml(winner.avatar)}</div>
          <div class="rs-name">${escapeHtml(winner.name)}</div>
          <div class="rs-earned">+$${earned.toLocaleString()}</div>
          <div class="rs-earned-label">${awardLabel || (minimumApplied
            ? `$${roundBank.toLocaleString()} round bank raised to the $${solveBonus.toLocaleString()} minimum solve award`
            : 'Banked to total winnings')}</div>
        </div>
        <div class="rs-leaderboard">
          ${standings.map((s,i)=>`<div class="rs-row ${s.isWinner?'is-winner':''}" style="--p-color:${s.color}">
            <span class="rs-rank">#${i+1}</span>
            <span class="rs-mini">${avatarHtml(s.avatar)}</span>
            <span class="rs-pname">${escapeHtml(s.name)}</span>
            <span class="rs-total">$${s.total.toLocaleString()}</span>
          </div>`).join('')}
        </div>
      </div>
    `;
    document.body.appendChild(el);
    requestAnimationFrame(()=>el.classList.add('show'));
    setTimeout(()=>el.classList.remove('show'), 2600);
    setTimeout(()=>el.remove(), 3100);
  }

  function showPhaseAnnouncer(phase){
    if (!phase || phase._announced) return;
    phase._announced = true;
    let title, sub;
    if (phase.type === 'tossup'){
      title = phase.label || ('TOSS-UP #' + (phase.num || ''));
      sub = '$' + (phase.value || 0).toLocaleString() + ' · FIRST SOLVE WINS';
    } else if (phase.type === 'round'){
      const totalRounds = Math.max(1, state.cfg.roundCount | 0 || 4);
      const isLast = phase.num === totalRounds;
      title = isLast ? 'FINAL ROUND!' : ('ROUND ' + (phase.num || ''));
      sub = (phase.mult && phase.mult !== 1) ? phase.mult + 'x MULTIPLIER' : 'CALL CONSONANTS · BUY VOWELS';
    } else if (phase.type === 'bonus'){
      title = 'BONUS ROUND';
      sub = 'PLAY FOR THE GRAND PRIZE';
    } else return;
    announce(title, sub);
  }

  function announce(title, sub){
    const el = document.createElement('div');
    el.className = 'phase-announcer';
    el.innerHTML = `<div class="pa-title">${title}</div><div class="pa-sub">${sub||''}</div>`;
    document.body.appendChild(el);
    requestAnimationFrame(()=>el.classList.add('show'));
    setTimeout(()=>el.classList.remove('show'), 1500);
    setTimeout(()=>el.remove(), 2200);
  }

  function applyPhaseUI(phase){
    const stage = document.querySelector('#screen-classic .stage');
    if (!stage) return;
    stage.classList.toggle('phase-tossup', phase.type === 'tossup');
    stage.classList.toggle('phase-bonus', phase.type === 'bonus');
    stage.classList.toggle('phase-round', phase.type === 'round');
    const btnVowel = document.getElementById('btn-vowel');
    const btnPick = document.getElementById('btn-bonus-pick');
    const btnTossupStart = document.getElementById('btn-tossup-start');
    const btnTossupMode = document.getElementById('btn-tossup-mode');
    const btnSolve = document.getElementById('btn-solve');
    const btnSkipBonus=document.getElementById('btn-skip-bonus');
    const btnHostBonus=document.getElementById('btn-host-bonus-card');
    stage.classList.toggle('phase-tiebreak', phase.type === 'tiebreak');
    const btnReveal = document.getElementById('btn-reveal');
    if (btnVowel) btnVowel.style.display = phase.type === 'round' ? '' : 'none';
    if (btnPick) btnPick.style.display = (phase.type === 'bonus' && !state.bonusDuelActive && !state.bonusTimerActive) ? '' : 'none';
    const showTossupStart = !state.tossupStarted && (phase.type === 'tossup' || phase.type === 'tiebreak' || (phase.type === 'bonus' && state.bonusDuelActive));
    if (btnTossupStart) btnTossupStart.style.display = showTossupStart ? '' : 'none';
    if (btnTossupMode) btnTossupMode.style.display = phase.type === 'tossup' && !state.tossupStarted ? '' : 'none';
    if (btnSolve) btnSolve.textContent = (phase.type === 'bonus' && state.bonusTimerActive) ? '✓ Judge Early Solve' : 'Solve';
    if(btnSkipBonus)btnSkipBonus.style.display=phase.type==='bonus'?'none':'';
    if(btnHostBonus)btnHostBonus.style.display=(phase.type==='bonus'&&!state.bonusEnvelopeReady&&!state.bonusDuelActive)?'':'none';
    // Reveal Answer would end with no winner mid-duel — hide it in tiebreak + bonus duel.
    if (btnReveal) btnReveal.style.display = (phase.type === 'tiebreak' || (phase.type === 'bonus' && state.bonusDuelActive)) ? 'none' : '';
    const banner = document.getElementById('phase-banner');
    const buzzerBtn = document.getElementById('btn-tossup-buzzers');
    if (banner) {
      if (phase.type === 'tossup') {
        banner.style.display = '';
        banner.className = 'phase-banner tossup';
        banner.innerHTML = `<span class="phase-icon">🔔</span> ${phase.label || ('TOSS-UP #' + phase.num)} · <strong>$${phase.value.toLocaleString()}</strong> · first solve wins`;
        if (buzzerBtn) buzzerBtn.style.display = '';
      } else if (phase.type === 'bonus') {
        banner.style.display = '';
        // During the duel, armDuel() owns the banner text (finalist names + prize) —
        // don't overwrite it here.
        if (!state.bonusDuelActive) {
          banner.className = 'phase-banner bonus';
          const finalist = state.cfg.players[state.activePlayer]?.name || 'Finalist';
          banner.innerHTML = `<span class="phase-icon">🏆</span> BONUS ROUND · <strong>${escapeHtml(finalist)}</strong> · RSTLNE + 3 consonants + 1 vowel`;
        }
        if (buzzerBtn) buzzerBtn.style.display = 'none';
      } else if (phase.type === 'tiebreak') {
        banner.style.display = '';
        banner.className = 'phase-banner tossup';
        const names = (state.tiebreakTied || []).map(i => state.cfg.players[i] && state.cfg.players[i].name).filter(Boolean);
        banner.innerHTML = `<span class="phase-icon">⚔️</span> SUDDEN-DEATH TIEBREAKER · <strong>${names.map(escapeHtml).join(' vs ')}</strong> · first solve wins`;
        if (buzzerBtn) buzzerBtn.style.display = '';
      } else {
        banner.style.display = 'none';
        if (buzzerBtn) buzzerBtn.style.display = 'none';
      }
    }
    updateStartRoundButton();
  }

  // One permanent bottom-dock control owns both starting a waiting toss-up and
  // advancing after a completed puzzle. It never disappears between phases.
  function updateStartRoundButton(){
    const btn=document.getElementById('btn-start-round');
    if(!btn)return;
    btn.style.display='';
    btn.disabled=false;
    if(!state.phase){btn.textContent='▶ Start Round';btn.disabled=true;return;}
    const duel=state.phase.type==='tiebreak'||(state.phase.type==='bonus'&&state.bonusDuelActive);
    if(state.roundOver){
      const list=state.activePuzzles&&state.activePuzzles.length?state.activePuzzles:state.cfg.puzzles;
      btn.textContent=(state.puzzleIdx+1>=list.length)?'🏁 Finish Game':'▶ Start Next Round';
      return;
    }
    if(!state.tossupStarted&&(state.phase.type==='tossup'||duel)){
      btn.textContent=duel?'▶ Start Challenge':'▶ Start Toss-Up';
      return;
    }
    btn.textContent='● Round In Progress';
    btn.disabled=true;
  }

  function bonusLeaderIdx(){
    let best = 0;
    state.cfg.players.forEach((_, i) => { if ((state.totals[i] || 0) > (state.totals[best] || 0)) best = i; });
    return best;
  }

  /* ---------- TOSS-UP ---------- */
  function setupTossup(phase){
    stopTurnTimer();
    state.tossupLockout = new Set();
    state.canGuess = false;
    state.spinValue = null;
    state.freePlay = false;
    state.tossupStarted = false;
    // Pre-reveal queue: shuffle every distinct letter in the puzzle
    const letters = [...new Set([...state.puzzle.text].filter(c => /[A-Z]/.test(c)))];
    for (let i = letters.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [letters[i], letters[j]] = [letters[j], letters[i]];
    }
    state.tossupQueue = letters;
    updateTossupModeButton();
    const usePhones = (state.cfg.tossupControlMode || 'phones') === 'phones';
    msg(usePhones
      ? `TOSS-UP READY. Connect phone buzzers, then click Start Toss-Up. Prize: $${phase.value.toLocaleString()}.`
      : `TOSS-UP READY in SHOUT-OUT mode. Click Start Toss-Up; click Solve only after someone calls an answer. Prize: $${phase.value.toLocaleString()}.`);
    wireBuzzer();
  }

  function startTossupReveal(){
    stopTossupReveal();
    state.tossupStarted = true;
    customAudio.play('tossupMusic',true,.72);
    saveGame();
    const startBtn = document.getElementById('btn-tossup-start');
    if (startBtn) startBtn.style.display = 'none';
    const modeBtn = document.getElementById('btn-tossup-mode');
    if (modeBtn) modeBtn.style.display = 'none';
    if ((state.cfg.tossupControlMode || 'phones') === 'phones') armTossupBuzzers();
    else if (buzzerAvailable()) window.WheelBuzzer.reset();
    msg((state.cfg.tossupControlMode || 'phones') === 'phones'
      ? 'TOSS-UP LIVE! Letters reveal one at a time. First phone buzz claims it.'
      : 'TOSS-UP LIVE — SHOUT-OUT MODE! Letters keep revealing until you click Solve and select who answered.');
    updateStartRoundButton();
    const interval = Math.max(300, state.cfg.tossupRevealMs | 0 || 1500);
    state.tossupRevealHandle = setInterval(() => {
      if (state.roundOver) { stopTossupReveal(); return; }
      const next = state.tossupQueue.shift();
      if (!next) { stopTossupReveal(); msg('All letters revealed — call Solve to award, or Reveal Answer to skip.'); return; }
      state.revealed.add(next);
      renderPuzzle();
      saveGame();
      try { tone(720 + Math.random()*80, 0.09, 'sine', 0.08); } catch(_){}
    }, interval);
  }

  function stopTossupReveal(){
    if (state.bonusDuelActive) saveGame();
    if (state.tossupRevealHandle) { clearInterval(state.tossupRevealHandle); state.tossupRevealHandle = null; }
    showAudio.stopSuspense();
    customAudio.stop('tossupMusic');
  }

  async function tossupSolveFlow(phase){
    if (!state.tossupStarted) {
      msg('Click Start Toss-Up when the players are ready.');
      return;
    }
    const eligible = state.cfg.players
      .map((p, i) => ({ p, i }))
      .filter(o => !state.tossupLockout.has(o.i));
    if (!eligible.length) {
      finishRound('Toss-up locked out — answer revealed.', false);
      sfx.lose();
      showReveal(state.puzzle.text, 'lose', 'no toss-up winner', 2400);
      return;
    }
    const rawMode = state.cfg.solveMode || 'tv';
    const mode = (rawMode === 'party' || rawMode === 'tv') ? 'tv' : 'hostless';
    if (mode === 'tv') {
      const pid = await pickSolverInline(
        `Toss-Up · $${phase.value.toLocaleString()}`,
        'Click the player who shouted the right answer first. Lock-out passes if nobody got it.',
        { lockedOut: state.tossupLockout }
      );
      stopTossupReveal();
      if (state.phase !== phase || state.roundOver) return;
      if (state.phase !== phase || state.roundOver) return;
      if (pid === -2) { startTossupReveal(); return; }
      if (pid < 0) {
        // Nobody → keep revealing if anyone's left
        if (state.tossupLockout.size >= state.cfg.players.length) {
          finishRound('No toss-up winner.', false);
          sfx.lose();
          showReveal(state.puzzle.text, 'lose', 'no toss-up winner', 2400);
        } else {
          startTossupReveal();
        }
        return;
      }
      state.totals[pid] = (state.totals[pid] || 0) + phase.value;
      state.tossupWinner = pid;
      finishRound(`${state.cfg.players[pid].name} wins the toss-up! +$${phase.value.toLocaleString()}`, true);
      confettiBurst();
      sfx.tossupSolve();
      sfx.applause();
      showReveal('TOSS-UP!', 'solve', state.cfg.players[pid].name + ' wins $' + phase.value.toLocaleString(), 2400);
      return;
    }

    // Tap the player who shouted first, then type just their phrase. Asking the
    // host to type "<player#> <phrase>" in one box was slow and error-prone.
    const pid = await pickSolverParty(
      `Toss-Up · $${phase.value.toLocaleString()}`,
      'Tap the player who shouted first — then type what they said to check it. Pass keeps revealing.',
      { lockedOut: state.tossupLockout }
    );
    if (state.phase !== phase || state.roundOver) return;
      if (pid < 0) {
      if (state.tossupLockout.size >= state.cfg.players.length) {
        finishRound('No toss-up winner.', false);
        sfx.lose();
        showReveal(state.puzzle.text, 'lose', 'no toss-up winner', 2400);
      } else {
        startTossupReveal();
      }
      return;
    }
    const typed = await openModal({
      title: `Toss-Up · ${state.cfg.players[pid].name}`,
      copy: `Type the phrase ${state.cfg.players[pid].name} said.`,
      placeholder: 'Type the answer',
      confirmText: 'Award',
      validate: v => v ? '' : 'Enter their answer.'
    });
    if (state.phase !== phase || state.roundOver) return;
    if (!typed) { startTossupReveal(); return; }
    const guess = typed.trim().toUpperCase().replace(/\s+/g, ' ');
    if (answerMatches(guess, state.puzzle.text)) {
      state.totals[pid] = (state.totals[pid] || 0) + phase.value;
      state.tossupWinner = pid;
      finishRound(`${state.cfg.players[pid].name} wins the toss-up! +$${phase.value.toLocaleString()}`, true);
      confettiBurst();
      sfx.tossupSolve();
      sfx.applause();
      showReveal('TOSS-UP!', 'solve', state.cfg.players[pid].name + ' wins $' + phase.value.toLocaleString(), 2400);
    } else {
      state.tossupLockout.add(pid); saveGame();
      sfx.wrong();
      msg(`${state.cfg.players[pid].name} is locked out. Reveal continues.`);
      if (state.tossupLockout.size >= state.cfg.players.length) {
        finishRound('All players locked out — answer revealed.', false);
        sfx.lose();
        showReveal(state.puzzle.text, 'lose', 'no toss-up winner', 2400);
      } else {
        startTossupReveal();
      }
    }
  }

  /* ---------- PHONE BUZZER INTEGRATION ---------- */
  let buzzerWired = false;
  let pendingBuzzPid = null;

  function buzzerAvailable(){ return typeof window.WheelBuzzer !== 'undefined'; }

  function openPhoneBuzzers(){
    if (!buzzerAvailable()) { msg('Phone buzzers need an internet connection.'); return; }
    wireBuzzer();
    state.cfg.tossupControlMode = 'phones';
    save();
    updateTossupModeButton();
    window.WheelBuzzer.configure({ players: state.cfg.players, toast: msg, sfx });
    window.WheelBuzzer.showQR();
  }

  function openContestantPool(){
    if (!buzzerAvailable()) { msg('Contestant sign-up needs an internet connection.'); return; }
    const setup = document.getElementById('screen-setup');
    if (setup && setup.classList.contains('active')) {
      const edited = collectPlayerEditor('setup-players-list');
      if (edited.length >= 2) { state.cfg.players = normalizePlayers(edited); save(); }
      const welcome = document.getElementById('setup-welcome-message');
      if (welcome) { state.cfg.welcomeMessage = welcome.value.trim(); save(); }
      const winner = document.getElementById('setup-winner-message');
      if (winner) state.cfg.winnerMessage = winner.value.trim();
      const visual = document.getElementById('setup-visual-theme');
      if (visual) state.cfg.visualTheme = visual.value || 'classic';
      applyVisualTheme();
      save();
    }
    wireBuzzer();
    window.WheelBuzzer.configure({players:state.cfg.players,toast:msg,sfx});
    window.WheelBuzzer.showPoolManager();
    publishAudienceDisplay();
  }

  function openPhoneTroubleshooter(){
    if(!buzzerAvailable()){msg('Phone tools require an internet connection.');return;}
    wireBuzzer();window.WheelBuzzer.configure({players:state.cfg.players,toast:msg,sfx});window.WheelBuzzer.showTroubleshooter();
  }

  async function refreshPuzzleChoices(){
    const ok=await openModal({title:'Refresh Current Puzzle?',copy:'This immediately draws a fresh set of puzzles and restarts the current round. Grand totals are preserved; the current round bank resets.',input:false,confirmText:'Refresh Puzzles'});
    if(!ok)return;buildActivePuzzles();loadPuzzle(state.puzzleIdx);msg('Fresh puzzle choices generated.');toast('Puzzle set refreshed','ok');
  }

  async function broadcastAudienceMessage(){
    const text=await openModal({title:'Audience Message',copy:'Enter a birthday, special, announcement, or other message for the audience screen.',placeholder:'Happy Birthday, Taylor!',confirmText:'Show Message',validate:value=>value.trim()?'':'Enter a message first.'});
    if(!text)return;
    showSpecialNotice(String(text).trim(),'','LIVE MESSAGE');
    setTimeout(clearSpecialNotice,10000);
  }

  function wireBuzzer(){
    if (buzzerWired || !buzzerAvailable()) return;
    buzzerWired = true;
    window.WheelBuzzer.onBuzz(pid => handleTossupBuzz(pid));
    window.WheelBuzzer.onAnswer(data => handleBuzzerAnswer(data));
    window.WheelBuzzer.onSpin((pid, profile) => {
      if (pid !== state.activePlayer || !remoteSpinAllowed()) { syncRemoteControls(); return; }
      openSpinOverlay(profile || {});
      syncRemoteControls();
    });
    window.WheelBuzzer.onPoolSelected(picks => {
      (picks || []).forEach(p => {
        if (state.cfg.players[p.slot]) { state.cfg.players[p.slot].name = p.name; if(p.avatar) state.cfg.players[p.slot].avatar=p.avatar; }
      });
      save();
      window.WheelBuzzer.configure({players:state.cfg.players,toast:msg,sfx});
      const setup = document.getElementById('screen-setup');
      if (setup && setup.classList.contains('active')) renderPlayerEditor(state.cfg.players,'setup-players-list');
      if (document.getElementById('scoreboard')) renderScore();
      publishAudienceDisplay();
      msg((picks||[]).map(p=>p.name).join(', ') + ' selected as contestant' + ((picks||[]).length===1?'':'s') + '!');
    });
    window.WheelBuzzer.onPoolDraw(draw => publishAudienceSpin('audience-pool-draw', draw || {}));
    window.WheelBuzzer.onBonusCardPick((pid,card) => {
      if(!state.phase||state.phase.type!=='bonus'||pid!==state.activePlayer||state.bonusEnvelopeReady)return;
      selectBonusCard(pid,card);
    });
    window.WheelBuzzer.onReconnect?.(pid=>{
      if(state.phase?.type==='bonus'&&!state.bonusDuelActive&&pid===state.activePlayer&&!state.bonusEnvelopeReady){
        const labels=(state.bonusCards||[]).map(x=>x.label);
        if(labels.length)setTimeout(()=>window.WheelBuzzer.sendToPlayer?.(pid,{type:'bonus-card-prompt',player:pid,labels}),180);
      }
      syncRemoteControls();
    });
    window.WheelBuzzer.onWild(pid=>{
      if(pid!==state.activePlayer||!((state.wildCards&&state.wildCards[pid])>0)||state.canGuess)return;
      state.wildArmedPlayer=pid;
      msg(`🃏 ${state.cfg.players[pid].name} armed their Wild Card. Call one consonant using the host keyboard.`);
      window.WheelBuzzer.sendToPlayer?.(pid,{type:'special-notice',kicker:'WILD CARD ARMED',title:'CALL A CONSONANT',copy:'Tell the host your consonant. Your Wild Card will be spent when it is entered.'});
      syncRemoteControls();
    });
    window.WheelBuzzer.onProfileUpdate?.((pid,profile)=>{
      const player=state.cfg.players[pid];if(!player)return;
      player.name=String(profile.name||player.name).slice(0,30);player.avatar=profile.avatar||player.avatar||'⭐';
      save();renderScore();renderBank();publishAudienceDisplay();
      window.WheelBuzzer.configure({players:state.cfg.players,toast:msg,sfx});
      toast(`${player.name}'s profile was updated.`,'ok');
    });
    window.WheelBuzzer.onPoolChange(() => publishAudienceDisplay());
    syncRemoteControls();
  }

  function armTossupBuzzers(){
    if (!buzzerAvailable() || !window.WheelBuzzer.connectedCount()) return;
    window.WheelBuzzer.configure({ players: state.cfg.players, toast: msg, sfx });
    window.WheelBuzzer.arm([...(state.tossupLockout || [])]);
    msg('📱 Phone buzzers ARMED — first to buzz claims the toss-up.');
  }

  async function handleTossupBuzz(pid){
    if (!state.phase || state.phase.type !== 'tossup' || state.roundOver) return;
    if (!state.tossupStarted) return;
    if (!Number.isInteger(pid) || !state.cfg.players[pid] || state.tossupLockout.has(pid) || pendingBuzzPid !== null || document.getElementById('modal')?.classList.contains('show')) return;
    stopTossupReveal();state.buzzedPlayer=pid;publishAudienceDisplay();
    const phase = state.phase;
    const name = state.cfg.players[pid]?.name || `Player ${pid + 1}`;
    const mode = (state.cfg.solveMode === 'party' || state.cfg.solveMode === 'tv') ? 'tv' : 'hostless';

    if (mode === 'hostless' && window.WheelBuzzer.isConnected(pid)) {
      pendingBuzzPid = pid;
      window.WheelBuzzer.sendAnswerPrompt(pid, { question: `Category: ${state.puzzle.cat || ''}` });
      msg(`${name} buzzed first — typing answer on their phone…`);
      return;
    }

    // The host can judge immediately. The contestant may keep speaking while the
    // dialog is open; there is no forced countdown blocking Correct/Wrong.
    msg(`${name} buzzed first — judge the answer when they finish speaking.`);
    const ok = await openModal({
      title: `${name} buzzed in!`,
      copy: `CORRECT ANSWER: ${state.puzzle.text}\n\nDid they call out the answer correctly?`,
      input: false,
      confirmText: '✓ Correct',
      cancelText: '✗ Wrong'
    });
    if (state.phase !== phase || state.roundOver) return;
    if (ok) awardTossup(pid, phase);
    else lockoutTossup(pid);
  }

  function handleBuzzerAnswer(data){
    if (pendingBuzzPid === null || data.player !== pendingBuzzPid) return;
    const phase = state.phase;
    const pid = pendingBuzzPid;
    pendingBuzzPid = null;
    if (buzzerAvailable()) window.WheelBuzzer.clearAnswerPrompt(pid);
    if (!phase || phase.type !== 'tossup' || state.roundOver) return;
    const guess = String(data.answer || '').trim().toUpperCase().replace(/\s+/g, ' ');
    if (answerMatches(guess, state.puzzle.text)) awardTossup(pid, phase);
    else lockoutTossup(pid);
  }

  function awardTossup(pid, phase){
    if (state.roundOver || state.phase !== phase || !Number.isInteger(pid) || !state.cfg.players[pid] || state.tossupLockout.has(pid)) return;
    captureUndo('toss-up award');state.buzzedPlayer=null;
    state.totals[pid] = (state.totals[pid] || 0) + phase.value;
    state.tossupWinner = pid;
    finishRound(`${state.cfg.players[pid].name} wins the toss-up! +$${phase.value.toLocaleString()}`, true);
    confettiBurst(); sfx.tossupSolve(); sfx.applause();
    showReveal('TOSS-UP!', 'solve', state.cfg.players[pid].name + ' wins $' + phase.value.toLocaleString(), 2400);
    if (buzzerAvailable()) window.WheelBuzzer.reset();
  }

  function lockoutTossup(pid){
    state.buzzedPlayer=null;state.tossupLockout.add(pid); saveGame();publishAudienceDisplay();
    sfx.wrong();
    msg(`${state.cfg.players[pid].name} is locked out. Reveal continues.`);
    if (state.tossupLockout.size >= state.cfg.players.length) {
      finishRound('All players locked out — answer revealed.', false);
      sfx.lose();
      showReveal(state.puzzle.text, 'lose', 'no toss-up winner', 2400);
      if (buzzerAvailable()) window.WheelBuzzer.reset();
    } else {
      startTossupReveal();
      if (buzzerAvailable() && window.WheelBuzzer.connectedCount()) window.WheelBuzzer.arm([...(state.tossupLockout || [])]);
    }
  }

  /* ---------- SUDDEN-DEATH TIEBREAKER ---------- */
  // Players tied for the top total settle it with a speed-solve puzzle (toss-up
  // style reveal). First tied player to solve is crowned champion.
  function topTiedPlayers(){
    const totals = state.cfg.players.map((_, i) => state.totals[i] || 0);
    const max = Math.max(...totals);
    return totals.map((t, i) => ({ t, i })).filter(o => o.t === max).map(o => o.i);
  }
  // Single game-end chokepoint: tiebreak if the lead is shared, else show results.
  function endOrTiebreak(){
    const tied = topTiedPlayers();
    if (tied.length <= 1) { showGameOver(); return; }
    startTiebreaker(tied);
  }
  function startTiebreaker(tied){
    state.epoch = (state.epoch || 0) + 1;
    // Safety cap so repeated no-solves can never loop forever.
    if ((state._tiebreakRounds || 0) >= 6) { state.forcedWinner = null; showGameOver(); return; }
    state._tiebreakRounds = (state._tiebreakRounds || 0) + 1;
    state.tiebreakTied = tied.slice();
    const all = (state._fullPool && state._fullPool.length ? state._fullPool
      : (state.activePuzzles && state.activePuzzles.length ? state.activePuzzles : state.cfg.puzzles)) || [];
    const pick = drawQueuedPuzzles(all,[{type:'tiebreak'}])[0] || { cat: 'PHRASE', diff: 'easy', text: 'GOOD GAME' };
    state.puzzle = pick;
    state.revealed = new Set();
    state.used = new Set();
    state.roundOver = false;
    state.canGuess = false;
    state.spinValue = null;
    state.freePlay = false;
    state.phase = { type: 'tiebreak' };
    state.tossupLockout = new Set();
    state.tossupStarted = false;
    stopTurnTimer();
    if (state.advanceHandle) { clearInterval(state.advanceHandle); state.advanceHandle = null; }
    const letters = [...new Set([...pick.text].filter(c => /[A-Z]/.test(c)))];
    for (let i = letters.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [letters[i], letters[j]] = [letters[j], letters[i]]; }
    state.tossupQueue = letters;
    document.getElementById('category').textContent = pick.cat;
    const labelEl = document.getElementById('round-label'), numEl = document.getElementById('round-num');
    const sepEl = document.getElementById('round-sep'), totalEl = document.getElementById('round-total');
    if (labelEl) labelEl.textContent = 'Final';
    if (numEl) numEl.textContent = 'TIE';
    if (sepEl) sepEl.style.display = 'none';
    if (totalEl) { totalEl.textContent = ''; totalEl.style.display = 'none'; }
    const multPill = document.getElementById('mult-pill'); if (multPill) multPill.style.display = 'none';
    renderPuzzle(); renderBank(); renderScore();
    applyPhaseUI(state.phase);
    const names = tied.map(i => state.cfg.players[i].name);
    announce('TIEBREAKER!', 'SUDDEN DEATH · ' + names.join(' vs '));
    msg(`Sudden-death tiebreaker — ${names.join(' & ')} are tied at $${(state.totals[tied[0]] || 0).toLocaleString()}. Click Start Toss-Up; first to solve wins the game!`);
    if (sfx.fanfare) sfx.fanfare();
    scheduleClassicFit();
    wireBuzzer();
  }
  async function tiebreakSolveFlow(){
    const phase = state.phase;
    if (!state.tossupStarted) { msg('Click Start Toss-Up to begin the tiebreaker.'); return; }
    stopTossupReveal();
    const tied = (state.tiebreakTied && state.tiebreakTied.length) ? state.tiebreakTied : topTiedPlayers();
    const stillIn = tied.filter(i => !state.tossupLockout.has(i));
    if (!stillIn.length) {
      msg('Nobody solved — fresh tiebreaker puzzle.');
      sfx.lose();
      setTimeout(() => { if (state.phase === phase) startTiebreaker(tied); }, 1200);
      return;
    }
    const lockedOut = new Set(state.cfg.players.map((_, i) => i).filter(i => !tied.includes(i)));
    state.tossupLockout.forEach(i => lockedOut.add(i));
    const rawMode = state.cfg.solveMode || 'tv';
    const mode = (rawMode === 'party' || rawMode === 'tv') ? 'tv' : 'hostless';
    if (mode === 'tv') {
      const pid = await pickSolverParty('Tiebreaker · Who solved?', 'Click the tied player who called it first. Pass keeps the letters revealing.', { lockedOut });
      if (state.phase !== phase || state.roundOver) return;
      if (pid < 0) { startTossupReveal(); return; }
      winTiebreak(pid);
    } else {
      // Tap the tied player, then type only what they said.
      const pid = await pickSolverParty(
        'Tiebreaker · Who solved?',
        'Tap the tied player who called it first — then type what they said. Pass keeps revealing.',
        { lockedOut });
      if (state.phase !== phase || state.roundOver) return;
      if (pid < 0) { startTossupReveal(); return; }
      const typed = await openModal({
        title: `Tiebreaker · ${state.cfg.players[pid].name}`,
        copy: `Type the phrase ${state.cfg.players[pid].name} said.`,
        placeholder: 'Type the answer',
        confirmText: 'Award',
        validate: v => v ? '' : 'Enter their answer.'
      });
      if (state.phase !== phase || state.roundOver) return;
    if (!typed) { startTossupReveal(); return; }
      if (answerMatches(typed, state.puzzle.text)) { winTiebreak(pid); return; }
      state.tossupLockout.add(pid); saveGame();
      sfx.wrong();
      msg(`${state.cfg.players[pid].name} is locked out.`);
      const left = tied.filter(i => !state.tossupLockout.has(i));
      if (!left.length) { msg('Nobody solved — fresh tiebreaker puzzle.'); sfx.lose(); setTimeout(() => { if (state.phase === phase) startTiebreaker(tied); }, 1200); }
      else startTossupReveal();
    }
  }
  function winTiebreak(pid){
    if (state.roundOver || !state.tiebreakTied?.includes(pid)) return;
    stopTossupReveal();
    state.roundOver = true;
    // Crown the tiebreaker winner without inflating the (equal) totals — the
    // game-over screen honours forcedWinner for the #1 slot.
    state.forcedWinner = pid;
    [...state.puzzle.text].forEach(c => { if (/[A-Z]/.test(c)) state.revealed.add(c); });
    renderPuzzle(); renderScore();
    const name = state.cfg.players[pid].name;
    msg(`${name} wins the tiebreaker — and the game!`);
    confettiBurst(); sfx.solve(); sfx.applause();
    showReveal('TIEBREAKER WON!', 'solve', name + ' takes the crown', 2600);
    state.tiebreakTied = null;
    const epoch = state.epoch;
    setTimeout(() => { if (epoch === state.epoch && state.roundOver) showGameOver(); }, 1600);
  }

  /* ---------- BONUS ROUND — 2-player head-to-head finale ----------
   * The two highest scorers play a speed-solve for the prize. A tie for a seat is
   * settled first by an extra qualifier speed-solve. Prize money only — the champion
   * is still whoever holds the highest total winnings afterwards. */
  function drawDuelPuzzle(preferHidden){
    const seen = state._tiebreakSeen || (state._tiebreakSeen = new Set());
    const all = (state._fullPool && state._fullPool.length ? state._fullPool
      : (state.activePuzzles && state.activePuzzles.length ? state.activePuzzles : state.cfg.puzzles)) || [];
    const pick = drawQueuedPuzzles(all,[{type:preferHidden?'bonus':'tiebreak'}])[0] || { cat:'PHRASE', diff:'easy', text:'GOOD GAME' };
    seen.add(pick.text);
    return pick;
  }
  function scoreTiersDesc(){
    const byScore = {};
    state.cfg.players.forEach((_, i) => { const t = state.totals[i] || 0; (byScore[t] = byScore[t] || []).push(i); });
    return Object.keys(byScore).map(Number).sort((a,b)=>b-a).map(s => byScore[s]);
  }
  // Decide the two finalists; any tie that overflows an open seat runs a qualifier duel.
  function resolveBonusFinalists(cb){
    const tiers = scoreTiersDesc();
    const finalists = [];
    (function fill(ti){
      if (finalists.length >= 2) { cb(finalists.slice(0,2)); return; }
      const tier = tiers[ti];
      if (!tier || !tier.length) { cb(finalists.slice(0,2)); return; }
      const need = 2 - finalists.length;
      if (tier.length <= need) { tier.forEach(i => finalists.push(i)); fill(ti + 1); return; }
      runQualifier(tier.slice(), need, [], (winners) => { winners.forEach(i => finalists.push(i)); cb(finalists.slice(0,2)); }, null, finalists.slice());
    })(0);
  }
  // Sequential speed-solve qualifiers among `group` until `need` players have advanced.
  function runQualifier(group, need, won, done, recovery = null, seated = []){
    if (won.length >= need) { done(won); return; }
    if (group.length <= (need - won.length)) { group.forEach(i => won.push(i)); done(won); return; }
    const puzzle = recovery ? recovery.puzzle : drawDuelPuzzle(false);
    const names = group.map(i => state.cfg.players[i].name).join(' vs ');
    armDuel(group.slice(), puzzle, {
      shortLabel: 'Qualifier', preRevealRSTLNE: false,
      recovery: {kind:'qualifier', group:group.slice(), need, won:won.slice(), seated:seated.slice()},
      banner: `<span class="phase-icon">⚔️</span> BONUS QUALIFIER · <strong>${escapeHtml(names)}</strong> · first solve advances`,
      msg: `Qualifier for a bonus seat — ${names}. Click Start Toss-Up; first to solve advances.`,
      onWinner: (pid) => {
        if (!state.bonusDuelActive || state.roundOver || !state.bonusParticipants.includes(pid)) return;
        state.bonusDuelActive = false; state.roundOver = true;
        won.push(pid);
        const rest = group.filter(i => i !== pid);
        state.duelRecovery = {kind:'qualifier', group:rest.slice(), need, won:won.slice(), seated:seated.slice(), advance:true};
        saveGame();
        [...state.puzzle.text].forEach(c => { if (/[A-Z]/.test(c)) state.revealed.add(c); });
        renderPuzzle();
        const nm = state.cfg.players[pid].name;
        msg(`${nm} qualifies for the bonus!`);
        confettiBurst(); sfx.solve();
        showReveal('QUALIFIED!', 'solve', nm + ' advances', 2000);
        const epoch = state.epoch;
        setTimeout(() => { if (epoch === state.epoch) runQualifier(rest, need, won, done, null, seated); }, 1900);
      }
    });
  }
  function startBonusDuel(finalists, recovery = null){
    const prize = state.cfg.bonusPrize ?? 50000;
    const puzzle = recovery ? recovery.puzzle : drawDuelPuzzle(true);
    const names = finalists.map(i => state.cfg.players[i].name).join(' vs ');
    armDuel(finalists.slice(), puzzle, {
      shortLabel: 'Bonus', preRevealRSTLNE: true,
      recovery: {kind:'bonus', finalists:finalists.slice()},
      banner: `<span class="phase-icon">🏆</span> BONUS ROUND · <strong>${escapeHtml(names)}</strong> · first solve wins $${prize.toLocaleString()}`,
      msg: `🏆 BONUS FINALE — ${names}. RSTLNE pre-revealed. Click Start Toss-Up; first to solve wins $${prize.toLocaleString()}!`,
      onWinner: (pid) => {
        if (!state.bonusDuelActive || state.roundOver || !state.bonusParticipants.includes(pid)) return;
        stopTossupReveal();
        state.bonusDuelActive = false; state.roundOver = true;
        state.totals[pid] = (state.totals[pid] || 0) + prize;
        [...state.puzzle.text].forEach(c => { if (/[A-Z]/.test(c)) state.revealed.add(c); });
        renderPuzzle(); renderScore();
        const nm = state.cfg.players[pid].name;
        msg(`${nm} wins the BONUS — +$${prize.toLocaleString()}!`);
        confettiBurst(); sfx.solve(); sfx.applause();
        showReveal('BONUS WON!', 'solve', nm + ' wins $' + prize.toLocaleString(), 2800);
        const epoch = state.epoch;
        setTimeout(() => { if (epoch === state.epoch && state.roundOver) endOrTiebreak(); }, 2000);
      }
    });
  }
  // Shared speed-solve setup used by both qualifier and bonus duels.
  function armDuel(participants, puzzle, opts){
    state.epoch = (state.epoch || 0) + 1;
    pendingBuzzPid = null;
    if (buzzerAvailable()) window.WheelBuzzer.reset();
    opts = opts || {};
    state._duelOpts = opts;
    state.duelRecovery = opts.recovery || null;
    stopTossupReveal(); stopTurnTimer(); stopBonusTimer();
    if (state.advanceHandle) { clearInterval(state.advanceHandle); state.advanceHandle = null; }
    state.phase = { type: 'bonus' };
    state.puzzle = puzzle;
    state.revealed = new Set();
    state.used = new Set();
    state.roundOver = false; state.canGuess = false; state.spinValue = null; state.freePlay = false;
    state.bonusParticipants = participants.slice();
    state.bonusOnWinner = opts.onWinner;
    state.bonusDuelActive = true;
    state.bonusDuelLabel = opts.shortLabel || 'Bonus';
    state.tossupStarted = false;
    state.tossupLockout = new Set(state.cfg.players.map((_, i) => i).filter(i => !participants.includes(i)));
    if (opts.preRevealRSTLNE) { ['R','S','T','L','N','E'].forEach(ch => { if (puzzle.text.includes(ch)) state.revealed.add(ch); }); }
    const letters = [...new Set([...puzzle.text].filter(c => /[A-Z]/.test(c) && !state.revealed.has(c)))];
    for (let i = letters.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [letters[i], letters[j]] = [letters[j], letters[i]]; }
    state.tossupQueue = letters;
    document.getElementById('category').textContent = puzzle.cat;
    const labelEl = document.getElementById('round-label'), numEl = document.getElementById('round-num'), sepEl = document.getElementById('round-sep'), totalEl = document.getElementById('round-total');
    if (labelEl) labelEl.textContent = (opts.shortLabel === 'Qualifier') ? 'Qualifier' : 'Bonus';
    if (numEl) numEl.textContent = '★';
    if (sepEl) sepEl.style.display = 'none';
    if (totalEl) { totalEl.textContent = ''; totalEl.style.display = 'none'; }
    const multPill = document.getElementById('mult-pill'); if (multPill) multPill.style.display = 'none';
    renderPuzzle(); renderBank(); renderScore();
    applyPhaseUI(state.phase);
    const banner = document.getElementById('phase-banner');
    if (banner) { banner.style.display = ''; banner.className = 'phase-banner bonus'; if (opts.banner) banner.innerHTML = opts.banner; }
    if (opts.msg) msg(opts.msg);
    announce(opts.shortLabel === 'Qualifier' ? 'QUALIFIER' : 'BONUS FINALE', participants.map(i => state.cfg.players[i].name).join(' vs '));
    if (sfx.fanfare) sfx.fanfare();
    scheduleClassicFit();
    wireBuzzer();
  }
  async function bonusDuelSolveFlow(){
    const phase = state.phase;
    if (!state.tossupStarted) { msg(`Click Start Toss-Up to begin the ${(state.bonusDuelLabel || 'bonus').toLowerCase()}.`); return; }
    stopTossupReveal();
    const parts = state.bonusParticipants || [];
    const lockedOut = new Set(state.cfg.players.map((_, i) => i).filter(i => !parts.includes(i)));
    state.tossupLockout.forEach(i => lockedOut.add(i));
    const stillIn = parts.filter(i => !state.tossupLockout.has(i));
    if (!stillIn.length) {
      msg('Nobody solved — fresh puzzle.'); sfx.lose();
      const opts = state._duelOpts; const ps = parts.slice();
      const epoch = state.epoch;
      setTimeout(() => { if (epoch === state.epoch) armDuel(ps, drawDuelPuzzle(opts && opts.preRevealRSTLNE), opts); }, 1200);
      return;
    }
    const rawMode = state.cfg.solveMode || 'tv';
    const mode = (rawMode === 'party' || rawMode === 'tv') ? 'tv' : 'hostless';
    if (mode === 'tv') {
      const pid = await pickSolverParty(`${state.bonusDuelLabel || 'Bonus'} · Who solved?`, 'Click the finalist who called it first. Pass keeps the letters revealing.', { lockedOut });
      if (state.phase !== phase || state.roundOver) return;
      if (pid < 0) { startTossupReveal(); return; }
      const cb = state.bonusOnWinner; if (cb) cb(pid);
    } else {
      // Tap the finalist, then type only what they said.
      const pid = await pickSolverParty(
        `${state.bonusDuelLabel || 'Bonus'} · Who solved?`,
        'Tap the finalist who called it first — then type what they said. Pass keeps revealing.',
        { lockedOut });
      if (state.phase !== phase || state.roundOver) return;
      if (pid < 0) { startTossupReveal(); return; }
      const typed = await openModal({
        title: `${state.bonusDuelLabel || 'Bonus'} · ${state.cfg.players[pid].name}`,
        copy: `Type the phrase ${state.cfg.players[pid].name} said.`,
        placeholder: 'Type the answer', confirmText: 'Award',
        validate: v => v ? '' : 'Enter their answer.'
      });
      if (state.phase !== phase || state.roundOver) return;
    if (!typed) { startTossupReveal(); return; }
      if (answerMatches(typed, state.puzzle.text)) { const cb = state.bonusOnWinner; if (cb) cb(pid); return; }
      state.tossupLockout.add(pid); saveGame(); sfx.wrong(); msg(`${state.cfg.players[pid].name} is locked out.`);
      const left = parts.filter(i => !state.tossupLockout.has(i));
      if (!left.length) { bonusDuelSolveFlow(); } else startTossupReveal();
    }
  }
  function beginBonusFinale(){
    if ((state.cfg.players || []).length < 2) { setTimeout(endOrTiebreak, 400); return; }
    resolveBonusFinalists((finalists) => startBonusDuel(finalists));
  }
  function setupBonus(phase){
    stopTurnTimer();
    state.canGuess = false; state.spinValue = null; state.freePlay = false; state.bonusPicking = false;
    state.bonusDuelActive = false;
    state.activePlayer = Number.isInteger(state.forcedWinner) ? state.forcedWinner : bonusLeaderIdx();
    state.bonusLetters = new Set();
    state.bonusEnvelopePrize = 0;
    state.bonusEnvelopeReady = false;
    const labels=['W','I','N','B','I','G','M','O','N','E','Y','LOGO'];
    const values=[10000,15000,20000,25000,30000,35000,40000,45000,50000,20000,30000,50000];
    for(let i=values.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[values[i],values[j]]=[values[j],values[i]]}
    state.bonusCards=labels.map((label,i)=>({label,value:values[i]}));
    state.bonusJudging = false;
    renderPuzzle(); renderBank(); renderScore(); applyPhaseUI(phase);
    const finalist = state.cfg.players[state.activePlayer];
    const btn=document.getElementById('btn-bonus-pick');if(btn){btn.disabled=true;btn.textContent='Waiting for Mystery Card';}
    if(buzzerAvailable()&&window.WheelBuzzer.isConnected(state.activePlayer)&&window.WheelBuzzer.sendToPlayer){
      window.WheelBuzzer.sendToPlayer(state.activePlayer,{type:'bonus-card-prompt',player:state.activePlayer,labels});
      msg(`🏆 ${finalist.name} is the finalist. They must pick one of 12 sealed bonus cards on their phone.`);
    }else{
      msg(`🏆 ${finalist.name} is the finalist. Their phone is offline; use Host Draw Mystery Card.`);
    }
    publishAudienceSpin('audience-bonus-cards',{labels,selected:null,playerName:finalist.name});
    showReveal('MYSTERY BONUS CARDS','solve','pick one sealed card',1900);
  }

  async function revealRSTLNESequential(){
    const sequence=['R','S','T','L','N','E'];
    // Bonus music begins here (never during card selection) and remains playing
    // through the contestant's additional letter choices.
    customAudio.play('rstlne',true,.75);
    for(const ch of sequence){
      if(state.phase?.type!=='bonus'||state.roundOver){customAudio.stop('rstlne');return;}
      state.bonusLetters.add(ch);
      if(state.puzzle.text.includes(ch))state.revealed.add(ch);
      state._lastRevealed=ch;state._flipIdx=0;
      renderPuzzle();
      sfx.ding(1);
      await new Promise(resolve=>setTimeout(resolve,1000));
    }
    state._lastRevealed=null;
  }

  function showPreBonusPodium(done){
    const standings=state.cfg.players.map((p,i)=>({name:p.name,color:p.color,avatar:p.avatar||'⭐',total:state.totals[i]||0})).sort((a,b)=>b.total-a.total);
    const winner=standings[0]||{name:'Finalist',color:'#ffd60a',avatar:'⭐',total:0};
    publishAudienceSpin('audience-podium',{winner,standings,duration:5600});
    document.getElementById('preBonusPodium')?.remove();
    const el=document.createElement('div');el.id='preBonusPodium';el.className='prebonus-podium';
    el.innerHTML=`<div class="prebonus-card"><div class="prebonus-kicker">🏆 BONUS ROUND FINALIST</div><div class="prebonus-avatar">${avatarHtml(winner.avatar)}</div><div class="prebonus-name">${escapeHtml(winner.name)}</div><div class="prebonus-total">$${Number(winner.total).toLocaleString()}</div><div class="prebonus-rows">${standings.map((p,i)=>`<div><b>#${i+1}</b><span>${avatarHtml(p.avatar)} ${escapeHtml(p.name)}</span><strong>$${Number(p.total).toLocaleString()}</strong></div>`).join('')}</div></div>`;
    document.body.appendChild(el);sfx.fanfare();setTimeout(()=>sfx.applause(),350);
    setTimeout(()=>{el.classList.add('out');setTimeout(()=>{el.remove();if(typeof done==='function')done()},400)},5600);
  }

  async function bonusPickLetters(){
    if (state.bonusPicking || !state.bonusEnvelopeReady) { msg('Choose and seal a mystery bonus card first.'); return; }
    state.bonusPicking = true;
    const btnPick = document.getElementById('btn-bonus-pick');
    const btnSolve = document.getElementById('btn-solve');
    if (btnPick) btnPick.disabled = true;
    if (btnSolve) btnSolve.disabled = true;
    try {
      if(buzzerAvailable()&&window.WheelBuzzer.sendToPlayer)window.WheelBuzzer.sendToPlayer(state.activePlayer,{type:'bonus-letter-prompt'});
      const consonantsAvail = [...ALPHA].filter(c => !VOWELS.includes(c) && !state.bonusLetters.has(c));
      const vowelsAvail = [...VOWELS].filter(c => !state.bonusLetters.has(c));
      const picked = await bonusLetterPickerModal(consonantsAvail, vowelsAvail);
      if (!picked) return;
      if(buzzerAvailable()&&window.WheelBuzzer.sendToPlayer)window.WheelBuzzer.sendToPlayer(state.activePlayer,{type:'special-clear'});
      await dramaticLetterReveal(picked);
      const pickedMatches=picked.reduce((sum,ch)=>sum+countLetter(ch),0);
      state.bonusCountdownDelay=pickedMatches===0?5000:3000;
      if(pickedMatches===0)sfx.buzzer();
      picked.forEach(ch => {
        state.bonusLetters.add(ch);
        if (state.puzzle.text.includes(ch)) state.revealed.add(ch);
      });
      state._lastRevealed = null;
      state._flipIdx = 0;
      // reveal letters one-by-one with sound
      for (const ch of picked) {
        state._lastRevealed = ch;
        state._flipIdx = 0;
        renderPuzzle();
        sfx.ding(Math.max(1,countLetter(ch)));
        await new Promise(r => setTimeout(r, 450));
      }
      state._lastRevealed = null;
      bonusStartSolve();
    } finally {
      if(buzzerAvailable()&&window.WheelBuzzer.sendToPlayer)window.WheelBuzzer.sendToPlayer(state.activePlayer,{type:'special-clear'});
      state.bonusPicking = false;
      if (btnPick) btnPick.disabled = false;
      if (btnSolve) btnSolve.disabled = false;
    }
  }

  function dramaticLetterReveal(letters){
    return new Promise(async resolve => {
      const overlay = document.createElement('div');
      overlay.className = 'bonus-reveal';
      letters.forEach(ch => {
        const slot = document.createElement('div');
        slot.className = 'bonus-slot';
        slot.textContent = ch;
        overlay.appendChild(slot);
      });
      document.body.appendChild(overlay);
      requestAnimationFrame(()=>overlay.classList.add('show'));
      const slots = overlay.querySelectorAll('.bonus-slot');
      for (let i=0;i<slots.length;i++){
        await new Promise(r=>setTimeout(r,550));
        slots[i].classList.add('reveal');
        if (sfx && sfx.chime) sfx.chime();
      }
      await new Promise(r=>setTimeout(r,900));
      overlay.classList.remove('show');
      setTimeout(()=>overlay.remove(), 400);
      resolve();
    });
  }

  function bonusLetterPickerModal(consonants, vowels){
    return new Promise(resolve => {
      const modal = document.getElementById('modal');
      const title = document.getElementById('modal-title');
      const copy = document.getElementById('modal-copy');
      const input = document.getElementById('modal-input');
      const err = document.getElementById('modal-error');
      const confirm = document.getElementById('modal-confirm');
      const cancel = document.getElementById('modal-cancel');
      title.textContent = 'Bonus Round — Pick Letters';
      copy.textContent = 'Choose 3 consonants and 1 vowel. They will be revealed in the puzzle.';
      input.style.display = 'none';
      err.textContent = '';
      const wrap = document.createElement('div');
      wrap.id = 'bonus-picker';
      wrap.style.cssText = 'display:flex;flex-direction:column;gap:8px;margin:10px 0';
      const buildRow = (letters, label, kind) => {
        const lab = document.createElement('div'); lab.textContent = label; lab.style.cssText = 'font-weight:700;font-size:13px;opacity:.8';
        const row = document.createElement('div'); row.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px';
        letters.forEach(ch => {
          const b = document.createElement('button');
          b.type = 'button';
          b.textContent = ch;
          b.dataset.kind = kind;
          b.style.cssText = 'min-width:38px;padding:8px 10px;border-radius:8px;border:2px solid #2c3550;background:#0e1424;color:#fff;font-weight:800;cursor:pointer';
          b.onclick = () => {
            const isPicked = b.classList.contains('picked');
            const cap = b.dataset.kind === 'c' ? 3 : 1;
            // Hard-cap: block selecting beyond the limit (deselect always allowed).
            if (!isPicked && getPicks()[b.dataset.kind].length >= cap) return;
            const active = b.classList.toggle('picked');
            b.style.borderColor = active ? '#ffd60a' : '#2c3550';
            b.style.background = active ? 'rgba(255,214,10,.25)' : '#0e1424';
            updateStatus();
          };
          row.appendChild(b);
        });
        wrap.append(lab, row);
      };
      buildRow(consonants, 'Consonants (pick 3)', 'c');
      buildRow(vowels, 'Vowel (pick 1)', 'v');
      copy.appendChild(wrap);
      function getPicks(){
        const c = [...wrap.querySelectorAll('button.picked[data-kind="c"]')].map(b => b.textContent);
        const v = [...wrap.querySelectorAll('button.picked[data-kind="v"]')].map(b => b.textContent);
        return { c, v };
      }
      function updateDisabled(){
        const picks = getPicks();
        wrap.querySelectorAll('button[data-kind]').forEach(b => {
          const cap = b.dataset.kind === 'c' ? 3 : 1;
          const atCap = picks[b.dataset.kind].length >= cap;
          const off = atCap && !b.classList.contains('picked');
          b.disabled = off;
          b.style.opacity = off ? '0.35' : '1';
          b.style.cursor = off ? 'not-allowed' : 'pointer';
        });
      }
      function updateStatus(){
        const { c, v } = getPicks();
        err.textContent = `Picked: ${c.length}/3 consonants · ${v.length}/1 vowel`;
        const ready = c.length === 3 && v.length === 1;
        confirm.disabled = !ready;
        confirm.style.opacity = ready ? '1' : '0.5';
        updateDisabled();
      }
      updateStatus();
      const keyboardPick=e=>{
        if(!modal.classList.contains('show')||!/^Key[A-Z]$/.test(e.code))return;
        const ch=e.code.slice(3);
        const target=[...wrap.querySelectorAll('button[data-kind]')].find(b=>b.textContent===ch);
        if(target&&!target.disabled){e.preventDefault();target.click();}
      };
      document.addEventListener('keydown',keyboardPick);
      modal.classList.add('show');
      modal.setAttribute('aria-hidden', 'false');
      confirm.textContent = 'Confirm';
      cancel.textContent = 'Cancel';
      const close = val => {
        document.removeEventListener('keydown',keyboardPick);
        wrap.remove();
        copy.textContent = '';
        input.style.display = '';
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
        confirm.onclick = null;
        cancel.onclick = null;
        confirm.disabled = false;       // restore for other modals
        confirm.style.opacity = '1';
        resolve(val);
      };
      confirm.onclick = () => {
        const { c, v } = getPicks();
        if (c.length !== 3 || v.length !== 1) { err.textContent = `Need exactly 3 consonants + 1 vowel. Picked: ${c.length}c / ${v.length}v.`; return; }
        close([...c, ...v]);
      };
      cancel.onclick = () => close(null);
    });
  }

  function bonusStartSolve(){
    const rawMode = state.cfg.solveMode || 'tv';
    const isHostless = !(rawMode === 'party' || rawMode === 'tv');
    const configuredSec = Math.max(3, state.cfg.bonusTimerSeconds | 0 || 20);
    // Typing a full phrase needs more breathing room than shouting it to a host.
    const sec = isHostless ? Math.max(20, configuredSec) : configuredSec;
    state.timeLeft = sec;
    state.timerLimit = sec;
    state.timerActive = true;   // show the number during get-ready (not "--") so the clock reads as armed
    state.bonusTimerActive = true;
    state.bonusExpired = false;
    renderTimer();
    applyPhaseUI(state.phase);
    msg(`Bonus round - get ready! ${sec} seconds to solve.`);
    showReveal('GET READY!', 'solve', `${sec} seconds`, 1400);
    showAudio.stopSuspense();
    if (state.bonusReadyHandle) clearTimeout(state.bonusReadyHandle);
    state.bonusReadyHandle = setTimeout(() => {
      state.bonusReadyHandle = null;
      if (state.roundOver || !state.bonusTimerActive) return;
      state.timerActive = true;
      renderTimer();
      startBonusCountdown(isHostless);
      if(isHostless) bonusSolveModal();
      customAudio.play('countdown',false,.88);
    }, state.bonusCountdownDelay||3000);
  }

  function startBonusCountdown(isHostless){
    if (state.bonusTimerHandle) clearInterval(state.bonusTimerHandle);
    // Use the same deadline clock as normal turns so stale or duplicate callbacks
    // cannot drain the bonus round faster than real time.
    const gen = ++state.timerGen;
    state.timerDeadline = Date.now() + Math.max(0, state.timeLeft) * 1000;
    const h = setInterval(() => {
      if (gen !== state.timerGen) { clearInterval(h); return; }
      syncTimeFromDeadline();
      renderTimer();
      if (state.timeLeft <= 0) {
        stopBonusTimer();
        sfx.buzzer();
        if (isHostless) {
          // Hostless: no referee, so the player races the clock — time-up = a miss,
          // and the typing prompt closes so it doesn't linger.
          state.bonusExpired = true;
          forceCloseModal();
        }
        else bonusSolveModal();
      }
    }, 100);
    state.bonusTimerHandle = h;
  }

  function stopBonusTimer(){
    state.timerGen = (state.timerGen | 0) + 1;   // invalidate any running bonus/turn tick
    if (state.bonusReadyHandle) { clearTimeout(state.bonusReadyHandle); state.bonusReadyHandle = null; }
    if (state.bonusTimerHandle) { clearInterval(state.bonusTimerHandle); state.bonusTimerHandle = null; }
    state.timerDeadline = 0;
    state.timerActive = false;
    state.bonusTimerActive = false;
    showAudio.stopSuspense();
    customAudio.stop('countdown');
    renderTimer();
  }

  async function bonusSolveModal(){
    if (state.roundOver || state.bonusJudging) return;
    state.bonusJudging = true;
    const rawMode = state.cfg.solveMode || 'tv';
    const mode = (rawMode === 'party' || rawMode === 'tv') ? 'tv' : 'hostless';
    const leader = state.activePlayer;
    let solved;
    if (mode === 'tv') {
      // Host-arbitrated: did the player call the right answer?
      const result = await openModal({
        title: 'Bonus Round — Did they solve it?',
        copy: `${state.cfg.players[leader].name} just shouted the answer.\n\nCORRECT ANSWER: ${state.puzzle.text}\n\nDid they call out the puzzle correctly?`,
        input: false,
        confirmText: '✓ Yes — they got it',
        cancelText: '✗ No — they missed'
      });
      if (state.roundOver) return;
      stopBonusTimer();
      customAudio.stop('rstlne');
      solved = !!result;
    } else {
      const guess = await openModal({
        title: 'Bonus Round — Solve!',
        copy: `${state.cfg.players[leader].name}, type the full phrase before the timer expires.`,
        placeholder: 'Type the answer',
        confirmText: 'Solve'
      });
      if (state.roundOver) return;
      stopBonusTimer();
      customAudio.stop('rstlne');
      solved = !state.bonusExpired && !!guess && answerMatches(guess, state.puzzle.text);
    }
    if (solved) {
      const prize = state.bonusEnvelopePrize || state.cfg.bonusPrize || 50000;
      revealBonusEnvelope(leader, prize);
      state.totals[leader] = (state.totals[leader] || 0) + prize;
      finishRound(`${state.cfg.players[leader].name} wins the BONUS ROUND! +$${prize.toLocaleString()}`, true);
      confettiBurst();
      sfx.solve();
      sfx.applause();
      showReveal('BONUS WIN!', 'solve', '+$' + prize.toLocaleString(), 2800);
    } else {
      bonusFailSolve(state.bonusExpired ? 'Time expired!' : 'No bonus this time.');
    }
  }

  function revealBonusEnvelope(pid, prize, options={}){
    publishAudienceSpin('audience-bonus-prize',{prize:Number(prize||0),label:state.bonusCardLabel||'LOGO',loss:!!options.loss});
    showSpecialNotice('$'+Number(prize||0).toLocaleString(),'THE MYSTERY ENVELOPE IS REVEALED','BONUS PRIZE');
    setTimeout(clearSpecialNotice,4200);
    if(buzzerAvailable()&&window.WheelBuzzer.sendToPlayer)window.WheelBuzzer.sendToPlayer(pid,{type:'bonus-prize-result',prize});
  }

  function bonusFailSolve(reason){
    if (state.roundOver) return;
    const prize=state.bonusEnvelopePrize||state.cfg.bonusPrize||50000;
    customAudio.stop('rstlne');
    revealBonusEnvelope(state.activePlayer,prize,{loss:true});
    finishRound(`Bonus — ${reason} Answer: ${state.puzzle.text}. The hidden $${Number(prize).toLocaleString()} prize was not won.`, false);
    sfx.wahwah();
    showReveal(state.puzzle.text, 'lose', `$${Number(prize).toLocaleString()} was not won`, 4200);
  }

  function renderCategoryGuide(){
    const el = document.getElementById('category-guide');
    if (!el) return;
    const cat = (state.puzzle?.cat || '').toUpperCase();
    el.textContent = cat === 'SAME LETTER'
      ? 'Main words start with the same letter; connecting words such as AND or OF may differ.'
      : cat === 'BEFORE & AFTER'
      ? 'Two expressions share a word or word part. Example: BOOK CLUB + CLUB SANDWICH → BOOK CLUB SANDWICH. Some compound words are split.'
      : '';
    el.hidden = !el.textContent;
  }
  function renderPuzzle(){
    renderCategoryGuide();
    const hostAnswer = document.getElementById('host-answer');
    if (hostAnswer) hostAnswer.textContent = state.puzzle?.text || '—';
    const board = document.getElementById('puzzle-board');
    // Slide-in on first render of a new puzzle (no revealed letters yet)
    if (state.revealed && state.revealed.size === 0 && !state._lastRevealed) {
      board.classList.remove('puzzle-enter');
      void board.offsetWidth;
      board.classList.add('puzzle-enter');
      const bank = document.getElementById('letter-bank');
      if (bank) {
        bank.classList.remove('bank-enter');
        void bank.offsetWidth;
        bank.classList.add('bank-enter');
      }
    }
    board.innerHTML = '';
    const lines = fitPuzzleLines(state.puzzle.text, 14, 4);
    const topPad = Math.max(0, Math.floor((4 - lines.length) / 2));
    for (let r=0;r<4;r++){
      const row = document.createElement('div');
      row.className = 'puzzle-row';
      const lineIdx = r - topPad;
      const line = (lineIdx >= 0 && lineIdx < lines.length) ? lines[lineIdx] : '';
      const leftPad = Math.max(0, Math.floor((14 - line.length) / 2));
      for (let c=0;c<14;c++){
        const idx = c - leftPad;
        const ch = idx >= 0 && idx < line.length ? line[idx] : '';
        const t = document.createElement('div');
        t.className = 'tile';
        if (!ch || ch === ' ') {
          t.classList.add('inactive');
        } else if (!/[A-Z]/.test(ch)) {
          t.classList.add('punct');
          t.textContent = ch;
        } else if (state.revealed.has(ch)) {
          t.textContent = ch;
          t.classList.add('tile-revealed');
          if (state._lastRevealed && ch === state._lastRevealed) {
            t.classList.add('tile-new');
            t.style.setProperty('--flip-delay', (state._flipIdx = (state._flipIdx||0) + 1) * 120 + 'ms');
            setTimeout(()=>{ if (sfx && sfx.chime) sfx.chime(); }, state._flipIdx * 120);
          }
        } else {
          // Do NOT put the letter in the DOM. color:transparent alone left the
          // answer selectable, findable with Ctrl+F, and readable by screen
          // readers - which spoils the puzzle in Hostless mode.
          t.classList.add('empty');
        }
        row.appendChild(t);
      }
      board.appendChild(row);
    }
    publishAudienceDisplay();
    syncRemoteControls();
  }

  function fitPuzzleLines(text, maxCols, maxRows){
    const words = text.split(' ').flatMap(word => word.match(new RegExp('.{1,' + maxCols + '}', 'g')) || []);
    const lines = [];
    let line = '';
    words.forEach(word => {
      if (!line) line = word;
      else if ((line + ' ' + word).length <= maxCols) line += ' ' + word;
      else {
        lines.push(line);
        line = word;
      }
    });
    if (line) lines.push(line);
    return lines.slice(0, maxRows);
  }

  function renderBank(){
    const bank = document.getElementById('letter-bank');
    bank.innerHTML = '';
    const consonants = [...ALPHA].filter(c => !VOWELS.includes(c));
    const makeBtn = (ch) => {
      const b = document.createElement('button');
      b.textContent = ch;
      if (VOWELS.includes(ch)) b.classList.add('vowel');
      if (state.used.has(ch)) { b.classList.add('used'); b.disabled = true; }
      b.onclick = () => onLetter(ch);
      return b;
    };
    const consRow = document.createElement('div');
    consRow.className = 'bank-row consonants';
    consonants.forEach(ch => consRow.appendChild(makeBtn(ch)));
    bank.appendChild(consRow);
    const vowelRow = document.createElement('div');
    vowelRow.className = 'bank-row vowels-row';
    const vlabel = document.createElement('span');
    vlabel.className = 'bank-row-label';
    vlabel.textContent = `Vowels · $${state.cfg.vowelCost ?? 250} each`;
    vowelRow.appendChild(vlabel);
    [...VOWELS].forEach(ch => vowelRow.appendChild(makeBtn(ch)));
    bank.appendChild(vowelRow);
    updateHintButton();
  }

  /* ---------- TURN LOGIC ---------- */
  function isFinalMissingLetter(ch){
    const remaining = new Set([...state.puzzle.text].filter(c => /[A-Z]/.test(c) && !state.revealed.has(c)));
    return remaining.size === 1 && remaining.has(ch);
  }

  function highlightFinalLetterChoice(){
    const remaining = new Set([...state.puzzle.text].filter(c => /[A-Z]/.test(c) && !state.revealed.has(c)));
    if (remaining.size !== 1 || state.roundOver) return;
    msg('ONE LETTER LEFT - Solve now for full points, or call it correctly for an automatic half-value finish.');
    toast('One letter left: solve for full value or risk the final call for half.', 'info', 4200);
    const solveBtn = document.getElementById('btn-solve');
    if (!solveBtn) return;
    solveBtn.classList.remove('final-choice');
    void solveBtn.offsetWidth;
    solveBtn.classList.add('final-choice');
    setTimeout(() => solveBtn.classList.remove('final-choice'), 4400);
  }

  function finishFinalLetterRound(playerIdx){
    const player = state.cfg.players[playerIdx];
    const roundBank = state.scores[playerIdx] || 0;
    const solveBonus = state.cfg.solveBonus ?? 1000;
    const fullValue = Math.max(roundBank, solveBonus);
    const won = Math.round(fullValue / 2);
    state.totals[playerIdx] += won;
    state.activePlayer = playerIdx;
    finishRound(`${player.name} completes the final letter! $${won.toLocaleString()} half-value finish banked to total.`, true);
    crownWinner(playerIdx);
    confettiBurst();
    sfx.solve();
    sfx.applause();
    showReveal('FINAL LETTER!', 'solve', `half-value finish +$${won.toLocaleString()}`, 2600);
    showRoundSummary(playerIdx, won, roundBank, solveBonus, `Final-letter finish: 50% of the $${fullValue.toLocaleString()} full solve value`);
  }

  async function selectBonusCard(pid,card){
    if(state.bonusEnvelopeReady||pid!==state.activePlayer)return;
    const idx=Number.isInteger(card)&&card>=0&&card<(state.bonusCards||[]).length?card:Math.floor(Math.random()*12);
    const chosen=(state.bonusCards||[])[idx]||{label:'LOGO',value:10000};
    state.bonusEnvelopePrize=chosen.value;state.bonusEnvelopeReady=true;state.bonusCardIndex=idx;state.bonusCardLabel=chosen.label;
    publishAudienceSpin('audience-bonus-cards',{labels:(state.bonusCards||[]).map(x=>x.label),selected:idx,playerName:state.cfg.players[pid]?.name||'Finalist'});
    showSpecialNotice('MYSTERY CARD SEALED',`Card ${chosen.label==='LOGO'?'★ COMPANY LOGO':chosen.label} stays secret until the puzzle is judged.`,'BONUS ROUND');
    setTimeout(clearSpecialNotice,2200);
    if(buzzerAvailable()&&window.WheelBuzzer.sendToPlayer)setTimeout(()=>window.WheelBuzzer.sendToPlayer(pid,{type:'bonus-prize-sealed'}),1800);
    const btn=document.getElementById('btn-bonus-pick');if(btn){btn.disabled=true;btn.textContent='Sealing Mystery Card…';}
    applyPhaseUI(state.phase);
    msg(`${state.cfg.players[pid].name} selected a mystery card. Sealing it before the puzzle reveal.`);
    saveGame();
    await new Promise(resolve=>setTimeout(resolve,2300));
    publishAudienceSpin('audience-bonus-cards-clear');
    await new Promise(resolve=>setTimeout(resolve,650));
    if(btn){btn.disabled=true;btn.textContent='Revealing RSTLNE…';}
    await revealRSTLNESequential();
    if(btn){btn.disabled=true;btn.textContent='Opening Letter Selection…';}
    msg('RSTLNE is revealed. Opening the 3 consonants and 1 vowel selection now.');
    await new Promise(resolve=>setTimeout(resolve,500));
    bonusPickLetters();
  }
  function spinBonusPrize(pid){selectBonusCard(pid,Math.floor(Math.random()*12))}

  function startSpeedUpSolveTimer(){
    stopTurnTimer();
    state.timeLeft = 3;
    state.timerLimit = 3;
    state.turnTimerToken = (state.turnTimerToken | 0) + 1;
    state.timerActive = true;
    renderTimer();
    _armTimerInterval();
  }

  function onLetter(ch){
    if (state.roundOver) return;
    if (state.spinning || state.spinPending) { msg('Wait for the wheel to stop.'); return; }
    if (state.solveLocked) return;
    if (document.getElementById('modal')?.classList.contains('show')) return;
    if (state.phase && (state.phase.type === 'tossup' || state.phase.type === 'bonus' || state.phase.type === 'tiebreak')) return;
    if (state.used.has(ch)) return;
    if (!/^[A-Z]$/.test(ch)) return;
    const isVowel = VOWELS.includes(ch);
    if (state.expressMode && isVowel) {
      msg('EXPRESS is active — call another consonant or solve.'); return;
    }
    if (state.speedUpMode && isVowel) {
      captureUndo(`speed-up vowel ${ch}`);
      stopTurnTimer();
      state.used.add(ch);
      const hits = countLetter(ch);
      if (hits > 0) {
        revealLetter(ch);
        msg(`${ch} appears ${hits} time${hits===1?'':'s'} — 3 seconds to solve!`);
        sfx.ding(hits);
        startSpeedUpSolveTimer();
      } else {
        msg(`No ${ch}. Next player.`); sfx.wrong(); nextPlayer();
      }
      renderBank(); renderScore();
      return;
    }
    if (!state.freePlay && isVowel && (state.scores[state.activePlayer] || 0) < (state.cfg.vowelCost ?? 250)) {
      msg(`Need $${state.cfg.vowelCost ?? 250} to buy a vowel.`); return;
    }
    if (!state.freePlay && !isVowel && !state.canGuess && state.spinValue == null && state.wildArmedPlayer !== state.activePlayer) {
      msg('Spin first to call a consonant.'); return;
    }
    captureUndo(`call ${ch}`);
    // A click queued on the final timer beat wins a short grace window instead
    // of being discarded by the timeout callback immediately before it runs.
    stopTurnTimer();
    if (state.freePlay) {
      const completesPuzzle = isFinalMissingLetter(ch);
      state.used.add(ch);
      const hits = countLetter(ch);
      if (hits > 0) {
        revealLetter(ch);
        if (isVowel) {
          msg(`${ch}! Free Play vowel revealed.`);
        } else {
          const earned = hits * (state.spinValue||500);
          state.scores[state.activePlayer] += earned;
          msg(`${hits} x ${ch} -> +$${earned}. Spin again, buy a vowel, or solve.`);
        }
        sfx.ding(hits);
      } else {
        msg(`No ${ch}, but Free Play keeps your turn.`);
        sfx.wrong();
      }
      state.freePlay = false;
      state.canGuess = false;
      state.spinValue = null;
      renderBank(); renderScore();
      if (hits > 0 && completesPuzzle) finishFinalLetterRound(state.activePlayer);
      else if (hits > 0) highlightFinalLetterChoice();
      return;
    }
    if (isVowel){
      const completesPuzzle = isFinalMissingLetter(ch);
      const cost = state.cfg.vowelCost ?? 250;
      const player = state.scores[state.activePlayer];
      if (player < cost){ msg(`Need $${cost} to buy a vowel.`); sfx.wrong(); return; }
      state.scores[state.activePlayer] -= cost;
      state.used.add(ch);
      const hits = countLetter(ch);
      if (hits>0){ revealLetter(ch); msg(`${ch}! Keep going.`); sfx.ding(hits); }
      else { msg(`No ${ch}. Turn passes.`); sfx.wrong(); nextPlayer(); }
      // Buying a vowel is a complete action. It must not leave a prior money spin armed.
      state.canGuess = false;
      state.spinValue = null;
      renderBank(); renderScore();
      if (hits > 0 && completesPuzzle) finishFinalLetterRound(state.activePlayer);
      else if (hits > 0) highlightFinalLetterChoice();
      return;
    }
    // WILD card: if the player holds one, let them call a consonant without spinning.
    const wildsHeld = (state.wildCards && state.wildCards[state.activePlayer]) || 0;
    if (!state.canGuess && wildsHeld > 0 && state.wildArmedPlayer === state.activePlayer) {
      const completesPuzzle = isFinalMissingLetter(ch);
      // Use wild as free consonant — payout uses base $500 (no spin)
      state.wildCards[state.activePlayer]--;state.wildArmedPlayer=null;
      if(buzzerAvailable())window.WheelBuzzer.sendToPlayer?.(state.activePlayer,{type:'special-clear'});
      state.used.add(ch);
      const hits = countLetter(ch);
      if (hits === 0){
        msg(`🃏 WILD used on ${ch}: not in puzzle. Your turn is safe — spin again.`);
        sfx.wrong();
        resetStreak(state.activePlayer);
        renderBank(); renderScore();
        return;
      } else {
        revealLetter(ch);
        const earned = hits * 500;
        state.scores[state.activePlayer] += earned;
        msg(`🃏 WILD ${ch} → +$${earned}. Spin again, buy a vowel, or solve.`);
        sfx.ding(hits);
        renderBank(); renderScore();
        if (completesPuzzle) finishFinalLetterRound(state.activePlayer);
        else highlightFinalLetterChoice();
        return;
      }
    }
    // spinValue is the authoritative proof that a money spin is still armed.
    // This keeps a valid call fair if a stale callback desynchronizes canGuess.
    if (!state.canGuess && state.spinValue == null){ msg('Spin first to call a consonant.'); sfx.wrong(); return; }
    state.used.add(ch);
    const hits = countLetter(ch);
    const completesPuzzle = hits > 0 && isFinalMissingLetter(ch);
    if (hits === 0){
      if (state.expressMode) {
        state.scores[state.activePlayer] = 0;
        msg(`No ${ch}. EXPRESS crash — round bank lost and turn passes.`);
        showReveal('EXPRESS CRASH','bankrupt','round bank cleared',1900);
      } else {
        msg(`No ${ch}. Turn passes.`);
      }
      sfx.wrong();
      resetStreak(state.activePlayer);
      state.canGuess = false; state.spinValue = null;
      state.pendingDouble = false;
      nextPlayer();
    } else {
      revealLetter(ch);
      const streak = bumpStreak(state.activePlayer);
      const streakBonus = streak >= 5 ? 0.2 : (streak >= 3 ? 0.1 : 0);
      const doubleMult = state.pendingDouble ? 2 : 1;
      const baseEarned = hits * (state.spinValue||0) * doubleMult;
      const bonusEarned = Math.round(baseEarned * streakBonus);
      const earned = baseEarned + bonusEarned;
      if (state.pendingDouble) state.pendingDouble = false;
      state.scores[state.activePlayer] += earned;
      let extra = '';
      if (streakBonus > 0) {
        extra = ` 🔥 STREAK x${streak} (+${Math.round(streakBonus*100)}% = +$${bonusEarned})`;
        showStreakBadge(streak, streakBonus);
      }
      msg(state.speedUpMode
        ? `${hits} x ${ch} -> +$${earned}. Three seconds to solve!`
        : state.expressMode
          ? `${hits} x ${ch} -> +$${earned}.${extra} EXPRESS continues — call another consonant or solve.`
          : `${hits} x ${ch} -> +$${earned}.${extra} Spin again, buy a vowel, or solve.`);
      sfx.ding(hits);
      if (state.speedUpMode) { state.canGuess = true; state.spinValue = state.speedUpValue; startSpeedUpSolveTimer(); }
      else if (state.expressMode) { state.canGuess = true; state.spinValue = 1000; startTurnTimer(); }
      else { state.canGuess = false; state.spinValue = null; }
    }
    renderBank(); renderScore();
    if (completesPuzzle) finishFinalLetterRound(state.activePlayer);
    else if (hits > 0) highlightFinalLetterChoice();
  }

  function countLetter(ch){
    let n=0;
    [...state.puzzle.text].forEach(c => { if (c===ch) n++; });
    return n;
  }

  function revealLetter(ch){
    state.revealed.add(ch);
    state._lastRevealed = ch;
    state._flipIdx = 0;
    renderPuzzle();
    state._lastRevealed = null;
  }

  function nextPlayer(){
    state.pendingDouble = false;
    state.expressMode = false;
    state.activePlayer = (state.activePlayer + 1) % state.cfg.players.length;
    if (state.speedUpMode) { state.canGuess = true; state.spinValue = state.speedUpValue; }
    else { state.canGuess = false; state.spinValue = null; }
    state.freePlay = false;
    stopTurnTimer();
    renderScore();
    publishAudienceDisplay();
    showTurnTransition(state.activePlayer);
  }

  function showTurnTransition(idx){
    const phase=state.phase||currentPhase();if(!phase||phase.type!=='round'||state.roundOver)return;
    const p=state.cfg.players[idx]||{};state.turnTransition=true;syncRemoteControls();
    publishAudienceSpin('audience-turn',{player:idx,playerName:p.name||`Player ${idx+1}`,playerColor:p.color||'#ffd60a',avatar:p.avatar||'⭐',duration:3000});
    document.getElementById('hostTurnTransition')?.remove();
    const el=document.createElement('div');el.id='hostTurnTransition';el.className='host-turn-transition';el.style.setProperty('--turn-color',p.color||'#ffd60a');el.innerHTML=`<div class="host-turn-card"><div class="host-turn-avatar">${avatarHtml(p.avatar||'⭐')}</div><div><small>GET READY</small><strong>${escapeHtml(p.name||`Player ${idx+1}`)}’S TURN</strong></div></div>`;document.body.appendChild(el);
    setTimeout(()=>{el.classList.add('out');setTimeout(()=>el.remove(),350);state.turnTransition=false;syncRemoteControls()},3000);
  }

  function skipActivePlayer(){
    const phase = state.phase || currentPhase();
    if (!phase || phase.type !== 'round' || state.roundOver || state.spinning || state.spinPending) {
      msg('Skip Player is available during regular rounds.'); return;
    }
    const old = state.cfg.players[state.activePlayer]?.name || 'Player';
    captureUndo('skip player');
    nextPlayer();
    msg(`${old} skipped. ${state.cfg.players[state.activePlayer]?.name || 'Next player'} now has control.`);
  }

  async function solveAttempt(){
    if (state.roundOver) { msg('This round is complete. Continue to the next round first.'); return; }
    if (state.spinning || state.spinPending) { msg('Wait for the wheel result, then solve.'); return; }
    if (document.getElementById('modal')?.classList.contains('show')) { msg('Finish the open host prompt first.'); return; }
    if (document.getElementById('solve-modal')?.classList.contains('show')) { msg('Finish the solve decision already on screen.'); return; }
    // Recover safely from a stale lock left by a closed/replaced async prompt.
    if (state.solveLocked) state.solveLocked = false;
    const epoch = state.epoch;
    const phase = state.phase || currentPhase();
    if (phase && phase.type === 'tossup') { tossupSolveFlow(phase); return; }
    if (phase && phase.type === 'tiebreak') { tiebreakSolveFlow(); return; }
    if (phase && phase.type === 'bonus') {
      if (state.bonusDuelActive) { bonusDuelSolveFlow(); }
      else if (state.bonusTimerActive) { bonusSolveModal(); }
      else { msg('Pick the bonus letters first. The Solve button becomes active during the final countdown.'); }
      return;
    }
    const rawMode = state.cfg.solveMode || 'tv';
    // accept legacy keys
    const mode = (rawMode === 'party' || rawMode === 'tv') ? 'tv' : 'hostless';
    pauseTimer();
    state.solveLocked = true;

    if (mode === 'tv') {
      let idx = -1;
      try {
        idx = await pickSolverParty('Solve · Who got it?', 'Click the player who shouted the right answer, or Pass if nobody solved.');
      } finally {
        state.solveLocked = false;
      }
      if (epoch !== state.epoch) return;
      if (state.roundOver) return;
      if (idx === -2) { resumeTimer(); return; }
      if (idx < 0) {
        msg('Nobody solved — turn passes.');
        sfx.wrong();
        nextPlayer();
        return;
      }
      captureUndo('solve award');
      const bonus = state.cfg.solveBonus ?? 1000;
      const snapScore = state.scores[idx] || 0;
      const won = Math.max(snapScore, bonus);
      if (won > snapScore) toast(`Minimum solve award applied: $${bonus.toLocaleString()}`, 'info', 3400);
      state.totals[idx] += won;
      state.activePlayer = idx;
      finishRound(`${state.cfg.players[idx].name} solves it! $${won.toLocaleString()} banked to total. ${state.cfg.players[idx].name} keeps control.`, true);
      crownWinner(idx);
      confettiBurst();
      sfx.solve();
      sfx.applause();
      showReveal('SOLVED!','solve',state.cfg.players[idx].name+' wins the round',2400);
      showRoundSummary(idx, won, snapScore, bonus);
      return;
    }

    // Quiz mode — original typing flow.
    const initiatingPlayer = state.activePlayer;
    const snapScore = state.scores[initiatingPlayer] || 0;
    let guess;
    try {
      guess = await openModal({
        title: 'Solve Puzzle · ' + (state.cfg.players[initiatingPlayer]?.name || 'Player'),
        copy: 'Enter the full phrase exactly as the team says it.',
        placeholder: 'Type the full answer',
        confirmText: 'Solve',
        validate: value => value ? '' : 'Enter a guess first.'
      });
    } finally {
      state.solveLocked = false;
    }
    if (epoch !== state.epoch) return;
    if (!guess) { resumeTimer(); return; }
    if (state.roundOver) return;
    if (answerMatches(guess, state.puzzle.text)){
      captureUndo('solve award');
      const bonus = state.cfg.solveBonus ?? 1000;
      const won = Math.max(snapScore, bonus);
      if (won > snapScore) toast(`Minimum solve award applied: $${bonus.toLocaleString()}`, 'info', 3400);
      state.totals[initiatingPlayer] += won;
      state.activePlayer = initiatingPlayer;
      finishRound(`${state.cfg.players[initiatingPlayer].name} solves it! $${won.toLocaleString()} banked to total. ${state.cfg.players[initiatingPlayer].name} keeps control.`, true);
      crownWinner(initiatingPlayer);
      confettiBurst();
      sfx.solve();
      sfx.applause();
      showReveal('SOLVED!','solve',state.cfg.players[initiatingPlayer].name+' wins the round',2400);
      showRoundSummary(initiatingPlayer, won, snapScore, bonus);
    } else {
      msg('Not quite - turn passes.');
      sfx.wrong();
      if (state.activePlayer === initiatingPlayer) nextPlayer();
    }
  }

  async function revealAnswer(){
    if (state.roundOver) return;
    pauseTimer();
    const ok = await openModal({
      title: 'Reveal Answer?',
      copy: 'This will show the full puzzle and end the round with no winner.',
      input: false,
      confirmText: 'Reveal'
    });
    if (!ok) { resumeTimer(); return; }
    finishRound('Answer revealed — no points awarded.', false);
    sfx.lose();
    showReveal(state.puzzle.text,'lose','answer revealed',2400);
  }

  function finishRound(message, allowAutoAdvance){
    const epoch = state.epoch;
    state.pendingDouble = false;
    pendingBuzzPid = null;
    stopTossupReveal();
    forceCloseModal();
    state.roundOver = true;
    state.canGuess = false;
    state.spinValue = null;
    state.freePlay = false;
    state.expressMode = false;
    state.speedUpMode = false;
    state.speedUpAwaitingSpin = false;
    stopTurnTimer();
    [...state.puzzle.text].forEach(c => { if (/[A-Z]/.test(c)) state.revealed.add(c); });
    renderPuzzle();
    state.scores = state.cfg.players.map(()=>0);
    renderScore();
    updateStartRoundButton();
    const list = state.activePuzzles && state.activePuzzles.length ? state.activePuzzles : state.cfg.puzzles;
    const isLast = (state.puzzleIdx + 1) >= list.length;
    // TV Mode always waits for the host. This prevents a result animation or
    // audience reaction from being cut off by an automatic phase change.
    const auto = allowAutoAdvance && state.cfg.autoAdvance !== false && state.cfg.solveMode !== 'tv' && !isLast;
    if (auto){
      let s = 4;
      msg(`${message} Next puzzle in ${s}…`);
      if (state.advanceHandle) clearInterval(state.advanceHandle);
      state.advanceHandle = setInterval(() => {
        s -= 1;
        if (s <= 0){
          clearInterval(state.advanceHandle); state.advanceHandle = null;
          loadPuzzle(state.puzzleIdx + 1);
        } else {
          msg(`${message} Next puzzle in ${s}…`);
        }
      }, 1000);
    } else if (isLast){
      msg(`${message} Game complete!`);
      setTimeout(() => { if (epoch === state.epoch && state.roundOver) endOrTiebreak(); }, 1400);
    } else {
      const nextBtn = document.getElementById('btn-next-round');
      if (nextBtn) {
        const nextPhase = state.phases && state.phases[state.puzzleIdx + 1];
        nextBtn.textContent = nextPhase && nextPhase.type === 'bonus' ? '▶ Continue to Bonus Round'
          : nextPhase && nextPhase.type === 'tossup' ? '▶ Continue to Next Toss-Up'
          : '▶ Continue to Next Round';
        nextBtn.style.display = '';
      }
      msg(`${message} Click the large Continue button when you are ready.`);
    }
  }

  /* ---------- SCORE ---------- */
  function rollNumber(el, from, to, duration=800){
    from = Number(from)||0; to = Number(to)||0;
    // Always write final value immediately so a throttled / paused rAF still leaves the right number on screen.
    const finalText = '$' + to.toLocaleString();
    el.textContent = finalText;
    if (from === to) return;
    // Cancel any in-flight roll on this element so the most recent value wins.
    if (el._rollToken) el._rollToken.cancelled = true;
    const token = el._rollToken = { cancelled: false };
    const t0 = performance.now();
    const ease = t => 1 - Math.pow(1-t, 3);
    function step(now){
      if (token.cancelled) return;
      const p = Math.min(1, (now - t0)/duration);
      const v = Math.round(from + (to - from) * ease(p));
      el.textContent = '$' + v.toLocaleString();
      if (p < 1) requestAnimationFrame(step);
      else el.textContent = finalText;
    }
    // Reset visible text to "from" then animate to "to". Final guard sets to finalText.
    el.textContent = '$' + from.toLocaleString();
    requestAnimationFrame(step);
    setTimeout(() => { if (!token.cancelled) el.textContent = finalText; }, duration + 200);
  }

  function renderScore(){
    const el = document.getElementById('scoreboard');
    const prev = state._prevScores || [];
    el.innerHTML = '';
    state.cfg.players.forEach((p,i) => {
      const card = document.createElement('div');
      const isActive = i === state.activePlayer;
      card.className = 'player' + (isActive ? ' active':'');
      card.dataset.player = String((i % 4) + 1);
      card.style.setProperty('--p-color', p.color || '#ff2f7f');
      const avatar = document.createElement('div');
      const name = document.createElement('div');
      const round = document.createElement('div');
      const total = document.createElement('div');
      const actions = document.createElement('div');
      avatar.className = 'avatar';
      name.className = 'name';
      round.className = 'round';
      total.className = 'total';
      actions.className = 'player-actions';
      avatar.innerHTML = avatarHtml(p.avatar || String(i + 1));
      name.textContent = p.name;
      const prevScore = prev[i] || 0;
      const curScore = state.scores[i] || 0;
      if (prevScore !== curScore) {
        round.textContent = '$' + prevScore.toLocaleString();
        rollNumber(round, prevScore, curScore, 700);
        if (curScore > prevScore) card.classList.add('pop-score');
      } else {
        round.textContent = '$' + curScore.toLocaleString();
      }
      total.textContent = `Total winnings: $${(state.totals[i]||0).toLocaleString()}`;
      const streak = state.streaks && state.streaks[i] || 0;
      if (streak >= 3) {
        const chip = document.createElement('div');
        chip.className = 'streak-chip' + (streak >= 5 ? ' hot' : '');
        chip.innerHTML = `<span class="sc-icon">🔥</span><span class="sc-x">×${streak}</span>`;
        card.appendChild(chip);
      }
      const wilds = (state.wildCards && state.wildCards[i]) || 0;
      if (wilds > 0) {
        const wchip = document.createElement('div');
        wchip.className = 'wild-chip';
        wchip.title = `Holds ${wilds} Wild Card${wilds>1?'s':''} — before spinning, click a consonant to play it free`;
        wchip.innerHTML = `<span class="sc-icon">🃏</span><span class="sc-x">Wild${wilds>1?' ×'+wilds:''}</span>`;
        card.appendChild(wchip);
      }

      const btnReset = document.createElement('button');
      btnReset.className = 'btn ghost p-act';
      btnReset.type = 'button';
      btnReset.textContent = 'Reset';
      btnReset.title = `Clear ${p.name}'s round bank`;
      btnReset.onclick = (e) => { e.stopPropagation(); resetPlayerBank(i); };

      const btnVowel = document.createElement('button');
      btnVowel.className = 'btn p-act vowel';
      btnVowel.type = 'button';
      btnVowel.textContent = 'Buy Vowel';
      btnVowel.title = `${p.name} buys a vowel ($${state.cfg.vowelCost ?? 250})`;
      btnVowel.disabled = !isActive || state.roundOver;
      btnVowel.onclick = (e) => { e.stopPropagation(); requestVowelBuy(i); };

      const btnAdj = document.createElement('button');
      btnAdj.className = 'btn ghost p-act';
      btnAdj.type = 'button';
      btnAdj.textContent = '± Adjust';
      btnAdj.title = `Host correction: set ${p.name}'s round bank`;
      btnAdj.onclick = (e) => { e.stopPropagation(); adjustPlayerBank(i); };

      actions.append(btnReset, btnAdj, btnVowel);
      card.append(avatar, name, round, total, actions);
      el.appendChild(card);
    });
    state._prevScores = state.cfg.players.map((_,i)=>state.scores[i]||0);
    renderActivePlayerCard();
    updateHintButton();
    saveGame();
    syncRemoteControls();
    publishAudienceDisplay();
  }

  function updateTossupModeButton(){
    const btn = document.getElementById('btn-tossup-mode');
    if (!btn) return;
    const phones = (state.cfg.tossupControlMode || 'phones') === 'phones';
    btn.textContent = phones ? 'Mode: 📱 Phones' : 'Mode: 📣 Shout-Out';
    btn.title = phones ? 'Click to use shout-out play without phones' : 'Click to use phone buzzers';
  }

  function toggleTossupControlMode(){
    const phones = (state.cfg.tossupControlMode || 'phones') === 'phones';
    state.cfg.tossupControlMode = phones ? 'shout' : 'phones';
    save();
    if (buzzerAvailable()) window.WheelBuzzer.reset();
    updateTossupModeButton();
    msg(phones ? '📣 SHOUT-OUT MODE selected — no phones required.' : '📱 PHONE BUZZER MODE selected.');
  }

  function renderActivePlayerCard(){
    const el = document.getElementById('active-player-card');
    if (!el) return;
    const i = state.activePlayer;
    const p = state.cfg.players[i];
    if (!p) { el.innerHTML = ''; return; }
    const score = state.scores[i] || 0;
    const total = state.totals[i] || 0;
    // Animate color shift when active player changes
    if (el._lastIdx !== undefined && el._lastIdx !== i) {
      el.classList.remove('switch-pulse'); void el.offsetWidth; el.classList.add('switch-pulse');
      // pulse the new active player's scoreboard chip too
      const newChip = document.querySelectorAll('#scoreboard .player')[i];
      if (newChip) { newChip.classList.remove('active-pulse'); void newChip.offsetWidth; newChip.classList.add('active-pulse'); setTimeout(()=>newChip.classList.remove('active-pulse'), 700); }
    }
    el._lastIdx = i;
    el.style.setProperty('--p-color', p.color || '#ff2f7f');
    const streak = state.streaks && state.streaks[i] || 0;
    const wilds = (state.wildCards && state.wildCards[i]) || 0;
    const isDouble = state.pendingDouble && state.activePlayer === i;
    const streakChip = streak >= 3
      ? `<div class="apc-streak ${streak>=5?'hot':''}"><span>🔥</span> Streak ×${streak} (+${streak>=5?20:10}%)</div>`
      : '';
    const wildChip = wilds > 0
      ? `<div class="apc-wild">🃏 Wild ×${wilds} <span class="apc-wild-hint">— call a consonant free</span></div>`
      : '';
    const doubleChip = isDouble
      ? `<div class="apc-double">×2 next consonant pays double</div>`
      : '';
    el.innerHTML = `
      <div class="apc-label">On Turn</div>
      <div class="apc-row">
        <div class="apc-avatar">${avatarHtml(p.avatar || (i+1))}</div>
        <div class="apc-body">
          <div class="apc-name">${escapeHtml(p.name || 'Player')}</div>
          <div class="apc-score-label">Round bank</div>
          <div class="apc-score">$${score.toLocaleString()}</div>
          <div class="apc-total">Total winnings $${total.toLocaleString()}</div>
        </div>
      </div>
      ${streakChip}
      ${wildChip}
      ${doubleChip}
    `;
  }

  function resetPlayerBank(i){
    state.scores[i] = 0;
    renderScore();
    msg(`${state.cfg.players[i].name}'s round bank reset to $0.`);
  }

  // Isolated P0 solve picker. It never borrows controls from the generic prompt,
  // so stale modal handlers cannot lock the game in a "being judged" state.
  function pickSolverParty(title, copy, opts){
    opts = opts || {};
    forceCloseSolveModal(null);
    return new Promise(resolve => {
      const modal = document.getElementById('solve-modal');
      const titleEl = document.getElementById('solve-modal-title');
      const copyEl = document.getElementById('solve-modal-copy');
      const answerEl = document.getElementById('solve-modal-answer');
      const playersEl = document.getElementById('solve-modal-players');
      const incorrect = document.getElementById('solve-modal-incorrect');
      const cancel = document.getElementById('solve-modal-cancel');
      titleEl.textContent = title;
      copyEl.textContent = copy || 'Select the contestant who solved it.';
      answerEl.textContent = state.puzzle?.text || '—';
      playersEl.innerHTML = '';
      const eligible = state.cfg.players
        .map((p, i) => ({ p, i }))
        .filter(o => !(opts.lockedOut && opts.lockedOut.has(o.i)));
      eligible.forEach(o => {
        const btn = document.createElement('button');
        btn.className = 'solve-player';
        btn.type = 'button';
        btn.style.setProperty('--p-color', o.p.color);
        btn.innerHTML = `
          <div class="sp-avatar">${avatarHtml(o.p.avatar)}</div>
          <div class="sp-name">${escapeHtml(o.p.name)}</div>
          <div class="sp-action">✓ SOLVED</div>
        `;
        btn.onclick = () => done(o.i);
        playersEl.appendChild(btn);
      });
      let settled = false;
      function done(idx){
        if (settled) return;
        settled = true;
        solveModalResolve = null;
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden','true');
        incorrect.onclick = null;
        cancel.onclick = null;
        resolve(idx);
      }
      solveModalResolve = value => done(value == null ? -2 : value);
      incorrect.onclick = () => done(-1);
      cancel.onclick = () => done(-2);
      modal.classList.add('show');
      modal.setAttribute('aria-hidden','false');
      setTimeout(() => playersEl.querySelector('button')?.focus(), 0);
    });
  }

  // Toss-up fallback picker: lives in the host control rail and never covers or
  // pauses the puzzle while the host decides who called the answer first.
  function pickSolverInline(title, copy, opts){
    return pickSolverParty(title, copy, opts);
  }

  // Hint cost climbs as more letters are already on the board: cheap early,
  // expensive once the puzzle is filling in.
  const HINT_BASE = 300, HINT_STEP = 150;
  function hintCostNow(){ return HINT_BASE + (state.revealed ? state.revealed.size : 0) * HINT_STEP; }

  function requestHint(){
    if (state.roundOver || state.spinning || state.solveLocked || state.spinPending || document.getElementById('modal')?.classList.contains('show')) return;
    if (state.phase && (state.phase.type === 'tossup' || state.phase.type === 'bonus')) { msg("Hint isn't available this phase."); sfx.wrong(); return; }
    const i = state.activePlayer;
    // One hint per player, per round.
    if (state.hintsUsed && state.hintsUsed[i]) { msg(`${state.cfg.players[i].name} already used their hint this round.`); sfx.wrong(); return; }
    // pool of consonants in puzzle not yet revealed
    const remaining = [...new Set([...state.puzzle.text].filter(ch => /[A-Z]/.test(ch) && !VOWELS.includes(ch) && !state.revealed.has(ch)))];
    if (!remaining.length) { msg('No consonants left to hint.'); sfx.wrong(); return; }
    // Can't hint your way to the solve — block when the board is down to its last letter.
    const unrevealedPositions = new Set([...state.puzzle.text].filter(c => /[A-Z]/.test(c) && !state.revealed.has(c))).size;
    if (unrevealedPositions <= 1) { msg('Too close to solve — no hint with one letter left.'); sfx.wrong(); return; }
    const cost = hintCostNow();
    if ((state.scores[i] || 0) < cost) { msg(`Need $${cost.toLocaleString()} in your round bank for a hint now.`); sfx.wrong(); return; }
    captureUndo('hint');
    const ch = remaining[Math.floor(Math.random() * remaining.length)];
    state.scores[i] -= cost;
    state.used.add(ch);
    if (!state.hintsUsed) state.hintsUsed = state.cfg.players.map(() => false);
    state.hintsUsed[i] = true;
    revealLetter(ch);
    // A hint replaces the player's letter call, so any pending spin is spent.
    state.canGuess = false;
    state.spinValue = null;
    state.freePlay = false;
    stopTurnTimer();
    msg(`Hint: revealed ${ch} (−$${cost.toLocaleString()}). One hint each per round.`);
    sfx.chime();
    renderBank(); renderScore();
  }

  // Keep the Hint button label/state in sync with the live cost and per-round use.
  function updateHintButton(){
    const btn = document.getElementById('btn-hint');
    if (!btn) return;
    const inPhase = state.phase && (state.phase.type === 'tossup' || state.phase.type === 'bonus' || state.phase.type === 'tiebreak');
    const note = document.getElementById('hint-note');
    if (note) note.hidden = !!inPhase;
    if (inPhase) { btn.style.display = 'none'; return; }
    btn.style.display = '';
    const i = state.activePlayer;
    const used = state.hintsUsed && state.hintsUsed[i];
    if (used) {
      btn.textContent = '💡 Hint used';
      btn.disabled = true;
      btn.style.opacity = '0.5';
      btn.style.cursor = 'not-allowed';
    } else {
      btn.textContent = `💡 Hint ($${hintCostNow().toLocaleString()})`;
      btn.disabled = false;
      btn.style.opacity = '';
      btn.style.cursor = '';
    }
  }

  function requestVowelBuy(i){
    if (state.roundOver) return;
    const cost = state.cfg.vowelCost ?? 250;
    if (i !== state.activePlayer){ msg(`${state.cfg.players[i].name} isn't on turn yet.`); sfx.wrong(); return; }
    if ((state.scores[i]||0) < cost){ msg(`Need $${cost} to buy a vowel.`); sfx.wrong(); return; }
    msg('Click a vowel in the bank to buy it.');
    // visual hint: pulse vowel buttons briefly
    document.querySelectorAll('.letter-bank button.vowel:not(.used)').forEach(b => {
      b.classList.remove('hint'); void b.offsetWidth; b.classList.add('hint');
    });
  }

  function msg(t){ document.getElementById('msg').textContent = t; }

  function setSpinResult(label, kind){
    const el = document.getElementById('last-result');
    if (!el) return;
    const display = /^\d+$/.test(label) ? '$' + label : label;
    el.textContent = display;
    el.className = 'last-result show kind-' + kind;
    clearTimeout(setSpinResult.timer);
    setSpinResult.timer = setTimeout(()=>el.className='last-result', 2600);
  }

  function clearRoundFeedback(){
    const result = document.getElementById('last-result');
    clearTimeout(setSpinResult.timer);
    if (result) {
      result.textContent = '';
      result.className = 'last-result';
    }
    const reveal = document.getElementById('reveal');
    clearTimeout(revealTimer);
    revealDone = null;
    if (reveal) reveal.className = 'reveal';
  }

  /* ---------- REVEAL OVERLAY ---------- */
  let revealTimer = 0;
  let revealDone = null;
  function hideReveal(){
    const el = document.getElementById('reveal');
    if (el) el.className = 'reveal';
    const done = revealDone;
    revealDone = null;
    if (done) done();
  }
  function showReveal(label, kind, sub, ms=1700, onHidden=null){
    const el = document.getElementById('reveal');
    if (!el) return;
    revealDone = null;
    el.querySelector('.reveal-label').textContent = label;
    el.querySelector('.reveal-sub').textContent = sub || '';
    el.className = 'reveal'; void el.offsetWidth;
    el.className = 'reveal show k-'+kind;
    clearTimeout(revealTimer);
    revealDone = typeof onHidden === 'function' ? onHidden : null;
    revealTimer = setTimeout(hideReveal, ms);
  }
  function shakeScreen(){
    document.body.classList.remove('shake'); void document.body.offsetWidth;
    document.body.classList.add('shake');
    setTimeout(()=>document.body.classList.remove('shake'), 650);
    const f = document.querySelector('.bankrupt-flash');
    if (f){ f.classList.remove('go'); void f.offsetWidth; f.classList.add('go'); }
  }

  /* ---------- CROWN WINNER ---------- */
  function crownWinner(idx){
    const cards = document.querySelectorAll('#scoreboard .player');
    const card = cards[idx];
    if (!card) return;
    card.classList.remove('winner-pop'); void card.offsetWidth;
    card.classList.add('winner-pop');
    let crown = card.querySelector('.crown-overlay');
    if (!crown) {
      crown = document.createElement('div');
      crown.className = 'crown-overlay';
      crown.textContent = '👑';
      card.appendChild(crown);
    }
    crown.classList.remove('go'); void crown.offsetWidth; crown.classList.add('go');
    setTimeout(()=>{ if (crown) crown.classList.remove('go'); }, 3200);
    setTimeout(()=>card.classList.remove('winner-pop'), 3200);
  }

  /* ---------- MONEY BURST ---------- */
  function moneyBurst(originEl){
    const rect = (originEl || document.querySelector('.wheel-wrap'))?.getBoundingClientRect();
    if (!rect) return;
    const cx = rect.left + rect.width/2;
    const cy = rect.top + rect.height/2;
    const glyphs = ['$','¢','$','★','$'];
    for (let i = 0; i < 22; i++){
      const c = document.createElement('div');
      c.className = 'coin';
      c.textContent = glyphs[i % glyphs.length];
      c.style.left = cx + 'px';
      c.style.top = cy + 'px';
      document.body.appendChild(c);
      const ang = (Math.PI*2) * (i / 22) + (Math.random()*.4 - .2);
      const dist = 180 + Math.random()*180;
      const dx = Math.cos(ang) * dist;
      const dy = Math.sin(ang) * dist - 60;
      const rot = (Math.random()*720 - 360);
      const dur = 900 + Math.random()*600;
      c.animate([
        {transform:'translate(-50%,-50%) scale(.5) rotate(0deg)',opacity:1},
        {transform:`translate(calc(-50% + ${dx*.5}px),calc(-50% + ${dy*.5 - 30}px)) scale(1.1) rotate(${rot*.5}deg)`,opacity:1,offset:.45},
        {transform:`translate(calc(-50% + ${dx}px),calc(-50% + ${dy+120}px)) scale(.9) rotate(${rot}deg)`,opacity:0}
      ],{duration:dur,easing:'cubic-bezier(.2,.7,.4,1)'}).onfinish = ()=>c.remove();
    }
  }

  /* ---------- WHEEL LANDING PULSE ---------- */
  function wheelLandingPulse(kind){
    const wrap = document.querySelector('.wheel-wrap');
    if (!wrap) return;
    wrap.classList.remove('land-money','land-bad','land-free');
    void wrap.offsetWidth;
    wrap.classList.add('land-' + (kind === 'money' ? 'money' : (kind === 'free' ? 'free' : 'bad')));
    setTimeout(()=>wrap.classList.remove('land-money','land-bad','land-free'), 900);
  }

  /* ---------- CONFETTI ---------- */
  function confettiBurst(){
    const colors = ['#f4c430','#e63a8c','#2ec4b6','#fff8ec'];
    for(let i=0;i<60;i++){
      const c = document.createElement('div');
      c.className = 'confetti';
      c.style.left = (Math.random()*100)+'vw';
      c.style.background = colors[i%colors.length];
      c.style.transform = `rotate(${Math.random()*360}deg)`;
      document.body.appendChild(c);
      const dur = 1500 + Math.random()*1500;
      c.animate([
        {transform:`translateY(0) rotate(0deg)`,opacity:1},
        {transform:`translateY(110vh) rotate(${720+Math.random()*360}deg)`,opacity:.9}
      ],{duration:dur,easing:'cubic-bezier(.2,.7,.4,1)'}).onfinish = ()=>c.remove();
    }
  }

  /* ---------- INIT ---------- */
  function startClassic(opts){
    opts = opts || {};
    stopAllGameTimers();   // clear any leftover timers before a fresh game arms its own
    show('classic');
    applyBackground();
    const isFresh = !(opts.restoredIdx === 0 || opts.restoredIdx > 0);
    if (isFresh) {
      state.scores = state.cfg.players.map(()=>0);
      state.totals = state.cfg.players.map(()=>0);
      state.activePlayer = 0;
      state.streaks = state.cfg.players.map(()=>0);
      state.wildCards = state.cfg.players.map(()=>0);
      state.pendingDouble = false;
      state.forcedWinner = null;
      state._tiebreakRounds = 0;
      state._tiebreakSeen = null;
      state.tiebreakTied = null;
      state.bonusDuelActive = false;
      state.bonusParticipants = null;
      state.leaderboardRecorded = false;
      publishAudienceSpin('audience-leaderboard-clear');
      _undoSnap = null;
    }
    if (typeof updateUndoButton === 'function') updateUndoButton();
    state.freePlay = false;
    state.tossupStarted = false;
    state.tossupLockout = new Set();
    state.tossupQueue = [];
    state.phase = null;
    state.phases = null;
    // On resume, reuse the exact puzzle set that was saved (shuffle makes a fresh
    // build non-deterministic, so we must not regenerate it here).
    if (Array.isArray(opts.restoredPuzzles) && opts.restoredPuzzles.length) {
      state.activePuzzles = opts.restoredPuzzles;
      state.phases = buildPhases();
    } else {
      buildActivePuzzles();
    }
    document.getElementById('round-num').textContent = 1;
    buildWheel(document.getElementById('wheel'), currentWheelSlices(), 'classic');
    const bigWheel = document.getElementById('wheel-big');
    if (bigWheel) buildWheel(bigWheel, currentWheelSlices(), 'classic');   // full-screen spin overlay wheel
    const startIdx = (opts.restoredIdx !== undefined) ? opts.restoredIdx : 0;
    // For a fresh game with 2+ players, run the picker FIRST so the phase announcer fires after it.
    // BUT skip it when the game opens on a toss-up (the toss-up itself decides who starts the
    // first round) or bonus — so TV Mode waits on the blank board for players to connect phone
    // buzzers and click Start Toss-Up, instead of auto-spinning a random first player.
    const firstPhase = state.phases && state.phases[Math.max(0, Math.min(startIdx, state.phases.length - 1))];
    const needsPicker = isFresh && (state.cfg.players || []).length >= 2 && (!firstPhase || firstPhase.type === 'round');
    const finishStart = () => {
      loadPuzzle(startIdx, !!opts.restoredRoundOver || !!opts.restoredDuel);
      if (opts.restoredScores) state.scores = opts.restoredScores.slice();
      if (opts.restoredRevealed && state.puzzle && (state.phase.type === 'round' || opts.restoredRoundOver)){
        opts.restoredRevealed.forEach(ch => state.revealed.add(ch));
        renderPuzzle();
      }
      if (opts.restoredUsed && (state.phase.type === 'round' || opts.restoredRoundOver)){
        opts.restoredUsed.forEach(ch => state.used.add(ch));
        renderBank();
      }
      // Restore mid-turn advantages (loadPuzzle/startClassic reset these to defaults).
      if (opts.restoredWilds) state.wildCards = opts.restoredWilds.slice();
      if (opts.restoredHints) state.hintsUsed = opts.restoredHints.slice();
      if (opts.restoredDouble) state.pendingDouble = true;
      if (opts.restoredFreePlay) state.freePlay = true;
      if (opts.restoredSpinValue != null) {
        state.spinValue = opts.restoredSpinValue;
        state.canGuess = !!opts.restoredCanGuess;
        if (state.canGuess) {
          renderBank();
          setSpinResult(String(state.spinValue), 'money');
          msg(`$${state.spinValue} per consonant. Pick a letter.`);
          startTurnTimer();
        }
      }
      if (opts.restoredRoundOver) {
        state.roundOver = true;
        state.canGuess = false;
        state.spinValue = null;
        state.freePlay = false;
        stopTurnTimer();
        stopTossupReveal();
        stopBonusTimer();
        const list = state.activePuzzles && state.activePuzzles.length ? state.activePuzzles : state.cfg.puzzles;
        msg(state.puzzleIdx + 1 >= list.length
          ? 'Game complete!'
          : 'Round complete. Press the → arrow (top bar) for the next puzzle.');
      }
      if (opts.restoredDuel) restoreDuel(opts.restoredDuel, opts);
      renderScore();
      renderActivePlayerCard();
    };
    if (needsPicker) {
      // Pre-render bare scoreboard + wheel so the picker has something behind it
      renderScore();
      spinFirstPlayerPicker(finishStart);
    } else {
      finishStart();
    }
  }

  /* ---------- FIRST PLAYER PICKER (scoreboard spotlight cycle) ---------- */
  function spinFirstPlayerPicker(done){
    const players = state.cfg.players || [];
    if (players.length < 2) { if (typeof done === 'function') done(); return; }
    const n = players.length;
    const targetIdx = Math.floor(Math.random() * n);

    // Find rendered scoreboard cards. If they aren't ready, fall back to immediate pick.
    const cards = document.querySelectorAll('#scoreboard .player');
    if (cards.length !== n) {
      state.activePlayer = targetIdx;
      state.tossupWinner = null;
      renderScore();
      if (typeof done === 'function') done();
      return;
    }

    // Plan a deceleration schedule of card-highlight steps. Total ~2.4s.
    // Cycle through cards rapidly (start at ~70ms/step), slow down (end ~360ms/step), land on targetIdx.
    const steps = [];
    let interval = 45;
    let acc = 0;
    let cur = (state.activePlayer || 0); // begin from current active
    // A short, snappy spin (~12 steps) that decelerates and lands.
    const stepCount = 12;
    for (let i = 0; i < stepCount; i++) {
      cur = (cur + 1) % n;
      steps.push({ idx: cur, delay: interval });
      acc += interval;
      // ramp interval up so the last few steps feel like the spotlight is settling
      const t = i / (stepCount - 1);
      // ease-out cubic
      const eased = 1 - Math.pow(1 - t, 3);
      interval = 45 + eased * 190; // 45ms → 235ms
    }
    // Force the last step to land on targetIdx by adjusting the final pointer.
    const lastPlanned = steps[steps.length - 1].idx;
    if (lastPlanned !== targetIdx) {
      // walk forward until we hit target (since cycling is +1 / mod n)
      let extra = (targetIdx - lastPlanned + n) % n;
      // add extra slow steps to reach the target
      for (let i = 0; i < extra; i++) {
        steps.push({ idx: (lastPlanned + i + 1) % n, delay: 200 + i * 35 });
      }
    }

    // Light up the active spotlight, then walk through.
    cards.forEach(c => c.classList.remove('spotlight','spotlight-landed'));
    let t = 0;
    steps.forEach((step, i) => {
      t += step.delay;
      setTimeout(() => {
        cards.forEach(c => c.classList.remove('spotlight'));
        const c = cards[step.idx];
        if (c) c.classList.add('spotlight');
        if (i < steps.length - 1) {
          if (sfx && sfx.chime) sfx.chime();
        }
      }, t);
    });

    // Final landing: bigger emphasis + state update + announcement.
    const totalMs = t;
    setTimeout(() => {
      cards.forEach(c => c.classList.remove('spotlight'));
      const c = cards[targetIdx];
      if (c) c.classList.add('spotlight','spotlight-landed');
      state.activePlayer = targetIdx;
      state.tossupWinner = null;
      renderScore();
      // renderScore re-creates the cards — re-find and re-apply the landed class
      const newCards = document.querySelectorAll('#scoreboard .player');
      if (newCards[targetIdx]) newCards[targetIdx].classList.add('spotlight-landed');
      announce(`${players[targetIdx].name.toUpperCase()} STARTS!`, 'Take the first turn');
      if (sfx && sfx.cha) sfx.cha();
      confettiBurst();
    }, totalMs + 60);

    setTimeout(() => {
      document.querySelectorAll('#scoreboard .player').forEach(c => c.classList.remove('spotlight','spotlight-landed'));
      if (typeof done === 'function') done();
    }, totalMs + 850);
  }

  async function resetClassic(){
    const ok = await openModal({
      title: 'Reset Game?',
      copy: 'This clears round banks, totals, used letters, and returns to round 1.',
      input: false,
      confirmText: 'Reset Game'
    });
    if (ok) startClassic();
  }

  function startParty(){
    show('party');
    applyBackground();
    buildWheel(document.getElementById('wheel-party'), state.cfg.party, 'party');
    document.getElementById('party-result').textContent = 'Spin to begin!';
  }

  async function customizePartySlices(){
    const result = await openModal({
      title: 'Customize Party Wheel',
      copy: 'Enter action labels separated by commas. These slices are used only by Party Wheel.',
      placeholder: 'Sing a song, Tell a joke, Truth, Dare',
      value: state.cfg.party.join(', '),
      confirmText: 'Save Slices',
      validate: value => {
        const slices = value.split(',').map(s => s.trim()).filter(Boolean);
        if (slices.length < 2) return 'Add at least 2 party wheel slices.';
        const tooLong = slices.find(s => s.length > 24);
        return tooLong ? `Keep "${tooLong}" under 24 characters.` : '';
      }
    });
    if (!result) return;
    state.cfg.party = result.split(',').map(s => s.trim()).filter(Boolean);
    save();
    buildWheel(document.getElementById('wheel-party'), state.cfg.party, 'party');
    document.getElementById('party-result').textContent = 'Slices updated. Spin to begin!';
    toast('Party Wheel slices updated', 'ok');
  }

  function playIntroVideo(done){
    const oldOverlay = document.getElementById('introOverlay');
    if (oldOverlay) oldOverlay.remove();
    // V4.4 routes the static intro picture and soundtrack to the audience output.
    // The host keeps only a lightweight status/skip overlay so two computers do
    // not play the same soundtrack out of sync.
    if(buzzerAvailable()&&window.WheelBuzzer.startGameIntro)window.WheelBuzzer.startGameIntro();
    spotifyMoment(20000);
    const staticBranding = state.cfg.skipIntro === true;
    const ov = document.createElement('div');
    ov.id = 'introOverlay';
    ov.className = 'intro-host-fallback';
    ov.style.cssText = 'position:fixed;inset:0;z-index:9999;overflow:hidden;background:radial-gradient(circle,#263f82,#02030d 72%);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:opacity .6s ease';
    ov.title = 'Click to skip intro';
    ov.innerHTML = `<div class="intro-host-marquee"></div><div style="text-align:center;color:#fff"><img src="assets/branding/ultimate-game-show-logo.png" alt="" style="width:min(520px,62vw);max-height:50vh;object-fit:contain;filter:drop-shadow(0 15px 35px #000)"><div style="font:900 clamp(22px,2.5vw,42px)/1.2 Inter,Segoe UI,sans-serif;color:#ffd60a;letter-spacing:3px">${staticBranding?'WELCOME TO THE SHOW':'INTRO PICTURE & MUSIC PLAYING ON AUDIENCE SCREEN'}</div></div><div style="position:absolute;bottom:22px;right:28px;color:#fff;font:900 11px/1 Inter,Segoe UI,sans-serif;letter-spacing:2px;padding:9px 15px;background:#0009;border:1px solid #fff4;border-radius:999px">CLICK TO SKIP INTRO</div>`;
    document.body.appendChild(ov);
    let finished = false;
    const finish = () => {
      if (finished) return; finished = true;
      introAudienceFinished = null;
      publishAudienceSpin('audience-intro-end');
      ov.style.pointerEvents = 'none';
      ov.remove();
      requestAnimationFrame(()=>{ if (typeof done === 'function') done(); });
    };
    introAudienceFinished = finish;
    publishAudienceSpin('audience-intro-start',{staticBranding:true,duration:16000});
    ov.addEventListener('click', finish);
    setTimeout(finish, 17000);
  }

  function closeMoreMenu(){
    const m = document.getElementById('more-menu');
    const b = document.getElementById('btn-more');
    if (m) { m.classList.remove('open'); m.setAttribute('aria-hidden','true'); }
    if (b) b.setAttribute('aria-expanded','false');
  }

  function getTop25(){try{const rows=JSON.parse(storageGet('wheelTop25V41','[]')||'[]');return Array.isArray(rows)?rows:[]}catch(_){return[]}}
  function recordLeaderboard(){if(state.leaderboardRecorded)return;const rows=getTop25();state.cfg.players.forEach((p,i)=>rows.push({name:p.name,avatar:p.avatar||'⭐',score:state.totals[i]||0,ts:Date.now()}));rows.sort((a,b)=>b.score-a.score||b.ts-a.ts);storageSet('wheelTop25V41',JSON.stringify(rows.slice(0,25)));state.leaderboardRecorded=true}
  function showLeaderboard(){state.leaderboardShowing=!state.leaderboardShowing;syncLeaderboardButtons();if(!state.leaderboardShowing){publishAudienceSpin('audience-leaderboard-clear');setTimeout(publishAudienceDisplay,60);msg('Leaderboard hidden. The normal audience screen and join QR are restored.');return}const rows=getTop25(),joinUrl=buzzerAvailable()?window.WheelBuzzer.getPoolState().url:'';publishAudienceSpin('audience-leaderboard',{rows,joinUrl});msg(rows.length?'All-time Top 25 is showing on the audience display. Click Close Top 25 to hide it.':'No completed-game scores are saved yet.');}
  function syncLeaderboardButtons(){
    const label=state.leaderboardShowing?'Close Top 25':'Open Top 25';
    ['btn-show-leaderboard','btn-show-leaderboard-title','btn-tv-top25'].forEach(id=>{const b=document.getElementById(id);if(b)b.textContent=(id==='btn-tv-top25'?'🏆 ':'')+label});
  }
  async function exportLeaderboardJpeg(){
    const rows=getTop25().slice(0,25);if(!rows.length){toast('No leaderboard scores to export yet.','warn');return}
    const c=document.createElement('canvas');c.width=1600;c.height=1200;const x=c.getContext('2d');
    const g=x.createLinearGradient(0,0,0,c.height);g.addColorStop(0,'#183767');g.addColorStop(1,'#02040d');x.fillStyle=g;x.fillRect(0,0,c.width,c.height);x.strokeStyle='#ffd60a';x.lineWidth=10;x.strokeRect(28,28,1544,1144);
    x.textAlign='center';x.fillStyle='#ffd60a';x.font='900 78px Georgia';x.fillText('ALL-TIME TOP 25',800,105);x.textAlign='left';
    async function photo(src){return new Promise(resolve=>{if(!/^data:image/.test(src||'')){resolve(null);return}const i=new Image();i.onload=()=>resolve(i);i.onerror=()=>resolve(null);i.src=src})}
    for(let i=0;i<rows.length;i++){const p=rows[i],col=i<13?0:1,row=i<13?i:i-13,left=95+col*770,y=175+row*72;x.fillStyle=i<3?'#ffd60a':'#9db0df';x.font='900 29px Arial';x.fillText('#'+(i+1),left,y);const img=await photo(p.avatar);if(img){x.save();x.beginPath();x.arc(left+88,y-11,25,0,Math.PI*2);x.clip();x.drawImage(img,left+63,y-36,50,50);x.restore()}else{x.font='32px Arial';x.fillText(p.avatar||'⭐',left+64,y+2)}x.fillStyle='#fff';x.font='900 27px Arial';x.fillText(String(p.name||'PLAYER').slice(0,22),left+128,y-5);x.fillStyle='#6fffa0';x.font='900 25px Arial';x.fillText('$'+Number(p.score||0).toLocaleString(),left+530,y-5);x.fillStyle='#8195c7';x.font='18px Arial';x.fillText(p.ts?new Date(p.ts).toLocaleDateString():'',left+128,y+22)}
    c.toBlob(blob=>{const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='ultimate-game-show-top-25.jpg';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)},'image/jpeg',.92);
  }
  async function clearLeaderboard(){const typed=await openModal({title:'Clear All-Time Top 25?',copy:'This permanently removes every saved leaderboard score. Type CLEAR to continue.',placeholder:'Type CLEAR',confirmText:'Clear Leaderboard',validate:v=>String(v||'').trim().toUpperCase()==='CLEAR'?'':'Type CLEAR exactly.'});if(!typed)return;storageSet('wheelTop25V41','[]');state.leaderboardShowing=false;syncLeaderboardButtons();publishAudienceSpin('audience-leaderboard-clear');setTimeout(publishAudienceDisplay,60);toast('Leaderboard cleared','ok')}
  function closeManageOverlay(){document.querySelector('.manage-overlay')?.remove()}
  function avatarPreview(el,value){el.innerHTML='';if(/^data:image/.test(value||'')){const img=document.createElement('img');img.src=value;el.appendChild(img)}else el.textContent=value||'⭐'}
  function cropAvatarFile(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onerror=reject;r.onload=()=>{const img=new Image();img.onerror=reject;img.onload=()=>{const size=256,c=document.createElement('canvas');c.width=c.height=size;const x=c.getContext('2d'),scale=Math.max(size/img.width,size/img.height),w=img.width*scale,h=img.height*scale;x.drawImage(img,(size-w)/2,(size-h)/2,w,h);resolve(c.toDataURL('image/jpeg',.72))};img.src=r.result};r.readAsDataURL(file)})}
  function syncModeratedPlayer(pid){save();renderScore();renderBank();publishAudienceDisplay();if(buzzerAvailable()){window.WheelBuzzer.configure({players:state.cfg.players,toast:msg,sfx});window.WheelBuzzer.sendToPlayer?.(pid,{type:'profile-sync',player:pid,name:state.cfg.players[pid].name,avatar:state.cfg.players[pid].avatar||'⭐'})}}
  function openPlayerModeration(){
    closeManageOverlay();const wrap=document.createElement('div');wrap.className='manage-overlay';wrap.innerHTML=`<section class="manage-card"><div class="manage-head"><h2>Player Name &amp; Photo Moderation</h2><button class="manage-close" aria-label="Close">×</button></div><p class="manage-note">Changes appear immediately on the host, audience display, and connected phone.</p><div class="manage-rows"></div></section>`;document.body.appendChild(wrap);wrap.querySelector('.manage-close').onclick=closeManageOverlay;wrap.onclick=e=>{if(e.target===wrap)closeManageOverlay()};
    const rows=wrap.querySelector('.manage-rows');state.cfg.players.forEach((p,i)=>{const row=document.createElement('div');row.className='manage-row';row.innerHTML=`<div class="manage-avatar"></div><input type="text" maxlength="30" value="${escapeHtml(p.name)}" aria-label="Player ${i+1} name"><button class="manage-save">Save</button><label>New Photo<input type="file" accept="image/*" hidden></label><button class="manage-delete">Wipe Photo</button>`;avatarPreview(row.querySelector('.manage-avatar'),p.avatar);row.querySelector('.manage-save').onclick=()=>{const next=row.querySelector('input[type=text]').value.trim();p.name=next||`Player ${i+1}`;syncModeratedPlayer(i);toast(`Player ${i+1} updated.`,'ok')};row.querySelector('input[type=file]').onchange=async e=>{try{p.avatar=await cropAvatarFile(e.target.files[0]);avatarPreview(row.querySelector('.manage-avatar'),p.avatar);syncModeratedPlayer(i)}catch(_){toast('That image could not be loaded.','warn')}};row.querySelector('.manage-delete').onclick=()=>{p.avatar='⭐';avatarPreview(row.querySelector('.manage-avatar'),p.avatar);syncModeratedPlayer(i)};rows.appendChild(row)});
  }
  function manageLeaderboard(){
    closeManageOverlay();const wrap=document.createElement('div');wrap.className='manage-overlay';const rows=getTop25();wrap.innerHTML=`<section class="manage-card"><div class="manage-head"><h2>Manage All-Time Top 25</h2><button class="manage-close" aria-label="Close">×</button></div><p class="manage-note">Delete one result or use Clear Top 25 for a complete reset.</p><div class="manage-rows"></div></section>`;document.body.appendChild(wrap);wrap.querySelector('.manage-close').onclick=closeManageOverlay;wrap.onclick=e=>{if(e.target===wrap)closeManageOverlay()};const list=wrap.querySelector('.manage-rows');
    const paint=()=>{list.innerHTML='';const current=getTop25();if(!current.length){list.textContent='No saved leaderboard entries.';return}current.forEach((p,i)=>{const row=document.createElement('div');row.className='manage-row leader-manage-row';row.innerHTML=`<b class="leader-manage-rank">#${i+1}</b><strong>${escapeHtml(p.name)} · $${Number(p.score||0).toLocaleString()}</strong><span class="leader-date">${p.ts?new Date(p.ts).toLocaleDateString():''}</span><button class="manage-delete">Delete</button>`;row.querySelector('button').onclick=()=>{current.splice(i,1);storageSet('wheelTop25V41',JSON.stringify(current));if(state.leaderboardShowing){publishAudienceSpin('audience-leaderboard',{rows:current,joinUrl:buzzerAvailable()?window.WheelBuzzer.getPoolState().url:''})}paint()};list.appendChild(row)})};paint();
  }
  function skipDirectlyToBonus(){const idx=(state.phases||[]).findIndex(p=>p.type==='bonus');if(idx<0){msg('No Bonus Round exists in this game flow.');return}stopAllGameTimers();state.puzzleIdx=idx;loadPuzzle(idx)}

  function bind(){
    document.querySelectorAll('[data-mode]').forEach(b => b.onclick = () => {
      state.mode = b.dataset.mode;
      // Mode-cards also carry data-solve-mode — apply if present
      if (b.dataset.solveMode) {
        state.cfg.solveMode = b.dataset.solveMode;
        if (b.dataset.solveMode === 'hostless') {
          state.cfg.autoAdvance = true;      // seamless flow
          // Toss-ups need someone to type a player number on the shared screen,
          // which isn't truly hostless — skip them in Hostless mode. (Still
          // available in TV Mode, or re-enable in the editor for phone buzzers.)
          state.cfg.tossupEnabled = false;
        } else {
          state.cfg.tossupEnabled = true;    // TV Mode keeps the toss-up rounds
        }
        save();
      }
      openSetup();
    });
    const btnResume = document.getElementById('btn-resume');
    if (btnResume) {
      const snap = loadGame();
      if (snap) {
        btnResume.style.display = '';
        const mins = Math.round((Date.now() - snap.ts) / 60000);
        btnResume.textContent = `↻ Resume Previous Game (${mins}m ago)`;
        btnResume.onclick = () => offerResumeIfAny();
      }
    }
    // Both mode-cards on the title screen flow through the [data-mode] handler above.
    // We just apply the quick-start defaults (5 puzzles, shuffle) before their handler runs.
    document.querySelectorAll('.mode-card').forEach(card => {
      card.addEventListener('click', () => {
        // Quick-start defaults apply ONLY on a pristine first run (no saved config).
        // Once the player has saved any settings we respect their choices — never
        // silently override a deliberate shuffle/round-count/roster again.
        const firstRun = storageGet('spinSolveCfg') === null;
        if (firstRun) {
          if (!state.cfg.maxRounds) state.cfg.maxRounds = 5;
          state.cfg.shuffle = true;
        }
        // A game needs at least 2 players; only backfill an unplayable roster.
        if (!state.cfg.players || state.cfg.players.length < 2){
          state.cfg.players = normalizePlayers(defaults.players.slice(0, 3));
        }
      }, { capture: true });
    });
    document.querySelectorAll('[data-back]').forEach(b => b.onclick = () => show('title'));
    const setupStartBtn = document.getElementById('setup-start');
    if (setupStartBtn) setupStartBtn.onclick = setupStartGame;
    const setupAddBtn = document.getElementById('setup-add-player');
    if (setupAddBtn) setupAddBtn.onclick = setupAddPlayer;
    const setupCount = document.getElementById('setup-player-count');
    if (setupCount) setupCount.onchange = () => setSetupPlayerCount(parseInt(setupCount.value, 10));
    const setupHelpBtn = document.getElementById('setup-help');
    if (setupHelpBtn) setupHelpBtn.onclick = () => openHelp();
    ['btn-audience-prep-title','btn-audience-prep-setup'].forEach(id => {
      const b = document.getElementById(id); if (b) b.onclick = openAudienceDisplay;
    });
    ['btn-contestant-pool-title','btn-contestant-pool-setup'].forEach(id => {
      const b = document.getElementById(id); if (b) b.onclick = openContestantPool;
    });
    ['title-visual-theme','setup-visual-theme'].forEach(id=>{const el=document.getElementById(id);if(el)el.onchange=()=>{state.cfg.visualTheme=el.value||'classic';const other=document.getElementById(id==='title-visual-theme'?'setup-visual-theme':'title-visual-theme');if(other)other.value=state.cfg.visualTheme;save();applyVisualTheme()}});
    const sponsorFiles=document.getElementById('setup-sponsor-files');if(sponsorFiles)sponsorFiles.onchange=e=>{loadSponsorFiles(e.target.files);e.target.value=''};
    const sponsorClear=document.getElementById('setup-sponsor-clear');if(sponsorClear)sponsorClear.onclick=()=>{state.cfg.sponsorSlides=[];state.cfg.sponsorEnabled=false;save();updateSponsorStatus();const cb=document.getElementById('setup-sponsor-enabled');if(cb)cb.checked=false;publishAudienceDisplay()};
    const sponsorEnabled=document.getElementById('setup-sponsor-enabled');if(sponsorEnabled)sponsorEnabled.onchange=()=>{state.cfg.sponsorEnabled=!!sponsorEnabled.checked&&!!(state.cfg.sponsorSlides||[]).length;save();publishAudienceDisplay()};
    document.querySelectorAll('.btn-mute').forEach(b => {
      b.textContent = state.muted ? 'Sound Off' : 'Sound On';
      b.setAttribute('aria-pressed', state.muted ? 'true' : 'false');
      b.onclick = () => setMuted(!state.muted);
    });
    document.getElementById('btn-reset-game').onclick = () => { closeMoreMenu(); resetClassic(); };
    { const u = document.getElementById('btn-undo'); if (u) u.onclick = () => { closeMoreMenu(); undoLast(); }; }
    { const k = document.getElementById('btn-skip'); if (k) k.onclick = () => { closeMoreMenu(); skipPuzzle(); }; }
    const toggleHostFullscreen = () => {
      closeMoreMenu();
      const root = document.documentElement;
      const active = document.fullscreenElement || document.webkitFullscreenElement;
      if (!active) {
        const enter = root.requestFullscreen || root.webkitRequestFullscreen;
        if (enter) enter.call(root);
      } else {
        const exit = document.exitFullscreen || document.webkitExitFullscreen;
        if (exit) exit.call(document);
      }
    };
    ['btn-fullscreen','btn-fullscreen-title','btn-fullscreen-live'].forEach(id => {
      const button = document.getElementById(id);
      if (button) button.onclick = toggleHostFullscreen;
    });
    const btnCapture = document.getElementById('btn-capture');
    if (btnCapture) btnCapture.onclick = () => captureMomentPng();
    const btnHelp = document.getElementById('btn-help');
    if (btnHelp) btnHelp.onclick = () => openHelp();
    const btnMore = document.getElementById('btn-more');
    const moreMenu = document.getElementById('more-menu');
    if (btnMore && moreMenu) {
      btnMore.onclick = (e) => {
        e.stopPropagation();
        const open = moreMenu.classList.toggle('open');
        btnMore.setAttribute('aria-expanded', open ? 'true' : 'false');
        moreMenu.setAttribute('aria-hidden', open ? 'false' : 'true');
      };
      document.addEventListener('click', (e) => {
        if (!moreMenu.contains(e.target) && e.target !== btnMore) closeMoreMenu();
      });
      moreMenu.querySelectorAll('.more-item').forEach(b => b.addEventListener('click', closeMoreMenu));
    }
    document.getElementById('btn-editor-reset').onclick = resetEditorDefaults;
    document.getElementById('reveal').onclick = () => {
      clearTimeout(revealTimer);
      hideReveal();
    };
    document.getElementById('btn-edit').onclick = openEditor;
    const btnPartyHelp = document.getElementById('btn-party-help');
    if (btnPartyHelp) btnPartyHelp.onclick = () => openHelp();
    const btnPartyCustomize = document.getElementById('btn-party-customize');
    if (btnPartyCustomize) btnPartyCustomize.onclick = customizePartySlices;
    document.getElementById('btn-save').onclick = saveEditor;
    const btnExport = document.getElementById('btn-export');
    const btnImport = document.getElementById('btn-import');
    const importFile = document.getElementById('import-file');
    if (btnExport) btnExport.onclick = exportConfig;
    if (btnImport) btnImport.onclick = () => importFile && importFile.click();
    if (importFile) importFile.onchange = e => {
      const f = e.target.files && e.target.files[0];
      importConfig(f);
      importFile.value = '';
    };
    const btnHint = document.getElementById('btn-hint');
    if (btnHint) btnHint.onclick = () => requestHint();
    const btnPrev = document.getElementById('btn-prev-puzzle');
    if (btnPrev) btnPrev.onclick = () => { if (state.puzzleIdx > 0) loadPuzzle(state.puzzleIdx - 1); };
    const btnTheme = document.getElementById('btn-theme');
    if (btnTheme) btnTheme.onclick = cycleTheme;
    const btnApplause = document.getElementById('btn-applause');
    if (btnApplause) btnApplause.onclick = () => { ensureAudio(); sfx.applause(); confettiBurst(); };
    ['btn-soundboard','btn-soundboard-quick'].forEach(id => {
      const b = document.getElementById(id); if (b) b.onclick = openSoundboard;
    });
    const sbPanel = document.getElementById('soundboard-panel');
    const sbClose = document.getElementById('soundboard-close');
    if (sbClose) sbClose.onclick = closeSoundboard;
    if (sbPanel) {
      sbPanel.onclick = e => { if (e.target === sbPanel) closeSoundboard(); };
      sbPanel.querySelectorAll('[data-sound]').forEach(b => b.onclick = () => {
        ensureAudio(); const fn = sfx[b.dataset.sound]; if (typeof fn === 'function') fn();
      });
    }
    const btnMusic = document.getElementById('btn-music');
    if (btnMusic) btnMusic.onclick = () => {
      const enable = state.cfg.musicEnabled === false;
      showAudio.setMusicEnabled(enable);
      toast(enable ? 'Moment music on' : 'Moment music off', 'ok');
    };
    showAudio.syncMusicButton();
    ['crowd','music'].forEach(kind => {
      const slider = document.getElementById(`ed-${kind}-volume`);
      const output = document.getElementById(`ed-${kind}-volume-out`);
      if (slider && output) slider.addEventListener('input', () => { output.textContent = `${slider.value}%`; });
    });
    const btnBuzzer = document.getElementById('btn-buzzer');
    if (btnBuzzer) btnBuzzer.onclick = () => { ensureAudio(); openPhoneBuzzers(); };
    const btnBuzzerQuick = document.getElementById('btn-buzzer-quick');
    if (btnBuzzerQuick) btnBuzzerQuick.onclick = () => { ensureAudio(); openPhoneBuzzers(); };
    const btnTossupBuzzers = document.getElementById('btn-tossup-buzzers');
    if (btnTossupBuzzers) btnTossupBuzzers.onclick = () => { ensureAudio(); openPhoneBuzzers(); };
    const btnTossupMode = document.getElementById('btn-tossup-mode');
    if (btnTossupMode) btnTossupMode.onclick = toggleTossupControlMode;
    const btnTossupStart = document.getElementById('btn-tossup-start');
    if (btnTossupStart) btnTossupStart.onclick = () => {
      if (!state.phase) return;
      const t = state.phase.type;
      const ok = (t === 'tossup' || t === 'tiebreak' || (t === 'bonus' && state.bonusDuelActive));
      if (!ok || state.roundOver || state.tossupStarted) return;
      ensureAudio();
      startTossupReveal();
      if (t === 'bonus') msg(`🏆 ${state.bonusDuelLabel || 'Bonus'} LIVE! Letters reveal one at a time — first to solve wins.`);
    };
    const btnStartRound=document.getElementById('btn-start-round');if(btnStartRound)btnStartRound.onclick=()=>{
      if(!state.phase)return;
      if(state.roundOver){
        const list=state.activePuzzles&&state.activePuzzles.length?state.activePuzzles:state.cfg.puzzles;
        if(state.puzzleIdx+1>=list.length)endOrTiebreak();else loadPuzzle(state.puzzleIdx+1);
        return;
      }
      btnTossupStart?.click();
    };
    const btnAudience = document.getElementById('btn-audience-display');
    if (btnAudience) btnAudience.onclick = openAudienceDisplay;
    const btnAudienceRelaunch=document.getElementById('btn-audience-relaunch');if(btnAudienceRelaunch)btnAudienceRelaunch.onclick=openAudienceDisplay;
    const btnReconnectPhones=document.getElementById('btn-reconnect-phones');if(btnReconnectPhones)btnReconnectPhones.onclick=openPhoneTroubleshooter;
    const hostDock=document.getElementById('host-command-dock'),hostDockToggle=document.getElementById('host-dock-toggle');
    if(hostDock&&hostDockToggle)hostDockToggle.onclick=()=>{const compact=hostDock.classList.toggle('compact');hostDockToggle.setAttribute('aria-expanded',compact?'false':'true')};
    const playRailToggle=document.getElementById('play-rail-toggle');if(playRailToggle)playRailToggle.onclick=()=>{const collapsed=document.body.classList.toggle('host-tools-collapsed');playRailToggle.setAttribute('aria-expanded',collapsed?'false':'true');playRailToggle.textContent=collapsed?'Host Tools ◂':'Host Tools ▸'};
    document.addEventListener('wheel-audience-message',e=>{const value=String(e.detail?.message||'').trim();if(value)publishAudienceSpin('audience-live-message',{message:value});else publishAudienceSpin('audience-live-message-clear')});
    const btnPhoneTools=document.getElementById('btn-phone-tools');if(btnPhoneTools)btnPhoneTools.onclick=openPhoneTroubleshooter;
    const btnPlayerModeration=document.getElementById('btn-player-moderation');if(btnPlayerModeration)btnPlayerModeration.onclick=openPlayerModeration;
    const btnBroadcast=document.getElementById('btn-broadcast-message');if(btnBroadcast)btnBroadcast.onclick=broadcastAudienceMessage;
    const btnRefreshPuzzles=document.getElementById('btn-refresh-puzzles');if(btnRefreshPuzzles)btnRefreshPuzzles.onclick=refreshPuzzleChoices;
    const btnShowLeaderboard=document.getElementById('btn-show-leaderboard');if(btnShowLeaderboard)btnShowLeaderboard.onclick=showLeaderboard;
    const btnShowLeaderboardTitle=document.getElementById('btn-show-leaderboard-title');if(btnShowLeaderboardTitle)btnShowLeaderboardTitle.onclick=showLeaderboard;
    const btnExportLeaderboard=document.getElementById('btn-export-leaderboard');if(btnExportLeaderboard)btnExportLeaderboard.onclick=exportLeaderboardJpeg;
    const btnClearLeaderboard=document.getElementById('btn-clear-leaderboard');if(btnClearLeaderboard)btnClearLeaderboard.onclick=clearLeaderboard;
    const btnClearLeaderboardTitle=document.getElementById('btn-clear-leaderboard-title');if(btnClearLeaderboardTitle)btnClearLeaderboardTitle.onclick=clearLeaderboard;
    const btnManageLeaderboard=document.getElementById('btn-manage-leaderboard');if(btnManageLeaderboard)btnManageLeaderboard.onclick=manageLeaderboard;
    const btnTvSettings=document.getElementById('btn-tv-settings'),tvSettingsPanel=document.getElementById('tv-settings-panel'),btnTvSettingsClose=document.getElementById('tv-settings-close');
    if(btnTvSettings&&tvSettingsPanel)btnTvSettings.onclick=()=>{tvSettingsPanel.classList.add('show');tvSettingsPanel.setAttribute('aria-hidden','false');syncLeaderboardButtons()};
    if(btnTvSettingsClose&&tvSettingsPanel)btnTvSettingsClose.onclick=()=>{tvSettingsPanel.classList.remove('show');tvSettingsPanel.setAttribute('aria-hidden','true')};
    if(tvSettingsPanel)tvSettingsPanel.onclick=e=>{if(e.target===tvSettingsPanel){tvSettingsPanel.classList.remove('show');tvSettingsPanel.setAttribute('aria-hidden','true')}};
    const btnTvTop25=document.getElementById('btn-tv-top25');if(btnTvTop25)btnTvTop25.onclick=showLeaderboard;
    const btnSkipBonus=document.getElementById('btn-skip-bonus');if(btnSkipBonus)btnSkipBonus.onclick=skipDirectlyToBonus;
    const btnHostBonus=document.getElementById('btn-host-bonus-card');if(btnHostBonus)btnHostBonus.onclick=()=>{if(state.phase?.type!=='bonus'||state.bonusEnvelopeReady){msg('Host bonus draw is available while the mystery cards are waiting.');return}selectBonusCard(state.activePlayer,Math.floor(Math.random()*12))};

    // background uploader
    const bgFile = document.getElementById('ed-bg-file');
    const tileFile = document.getElementById('ed-tile-file');
    document.getElementById('btn-bg-pick').onclick = () => bgFile.click();
    document.getElementById('btn-bg-clear').onclick = () => {
      pendingBgImage = '';
      renderBgPreview('');
      setEditorStatus('Background will reset to default on Save.');
    };
    document.getElementById('btn-tile-pick').onclick=()=>tileFile.click();
    document.getElementById('btn-tile-clear').onclick=()=>{pendingTileImage='';renderTilePreview('');setEditorStatus('Unused spaces will use the selected theme pattern after Save.')};
    // timer editor controls
    const timerOnEl = document.getElementById('ed-timer-on');
    const timerInpEl = document.getElementById('ed-timer');
    const timerDecEl = document.getElementById('btn-timer-dec');
    const timerIncEl = document.getElementById('btn-timer-inc');
    if (timerOnEl) timerOnEl.onchange = syncTimerEnabled;
    const rmEl = document.getElementById('ed-round-mode');
    if (rmEl) rmEl.onchange = syncRoundModeEnabled;
    if (timerDecEl) timerDecEl.onclick = () => {
      const cur = clampTimer(parseInt(timerInpEl.value,10) || 20);
      timerInpEl.value = clampTimer(cur - 5);
    };
    if (timerIncEl) timerIncEl.onclick = () => {
      const cur = clampTimer(parseInt(timerInpEl.value,10) || 20);
      timerInpEl.value = clampTimer(cur + 5);
    };

    // vowel cost / solve bonus stepper helpers
    const stepInput = (inputId, step, min, max) => (delta) => {
      const inp = document.getElementById(inputId);
      const cur = parseInt(inp.value,10) || 0;
      inp.value = Math.max(min, Math.min(max, cur + delta * step));
    };
    const vDec = document.getElementById('btn-vowel-dec');
    const vInc = document.getElementById('btn-vowel-inc');
    if (vDec) vDec.onclick = () => stepInput('ed-vowel-cost', 50, 0, 2000)(-1);
    if (vInc) vInc.onclick = () => stepInput('ed-vowel-cost', 50, 0, 2000)(1);
    const bDec = document.getElementById('btn-bonus-dec');
    const bInc = document.getElementById('btn-bonus-inc');
    if (bDec) bDec.onclick = () => stepInput('ed-solve-bonus', 100, 0, 20000)(-1);
    if (bInc) bInc.onclick = () => stepInput('ed-solve-bonus', 100, 0, 20000)(1);
    const mDec = document.getElementById('btn-max-dec');
    const mInc = document.getElementById('btn-max-inc');
    const mAll = document.getElementById('btn-max-all');
    const maxCap = () => (state.cfg.puzzles || []).length || 500;
    if (mDec) mDec.onclick = () => stepInput('ed-max-rounds', 5, 0, maxCap())(-1);
    if (mInc) mInc.onclick = () => stepInput('ed-max-rounds', 5, 0, maxCap())(1);
    if (mAll) mAll.onclick = () => { document.getElementById('ed-max-rounds').value = '0'; };
    const btnAddPlayer = document.getElementById('btn-add-player');
    if (btnAddPlayer) btnAddPlayer.onclick = () => {
      const cur = collectPlayerEditor();
      if (cur.length >= 6) { setEditorStatus('Max 6 players.'); return; }
      const i = cur.length;
      cur.push({
        name: `Player ${i+1}`,
        color: COLOR_PRESETS[i % COLOR_PRESETS.length],
        avatar: AVATAR_OPTIONS[i % AVATAR_OPTIONS.length]
      });
      renderPlayerEditor(cur);
    };

    const btnAddPuz = document.getElementById('btn-add-puzzle');
    if (btnAddPuz) btnAddPuz.onclick = addPuzzleRow;
    const btnThemeAdd = document.getElementById('btn-theme-add');
    if (btnThemeAdd) btnThemeAdd.onclick = () => loadThemeNight(false);
    const btnThemeOnly = document.getElementById('btn-theme-only');
    if (btnThemeOnly) btnThemeOnly.onclick = () => loadThemeNight(true);
    const btnThemeAi = document.getElementById('btn-theme-ai');
    if (btnThemeAi) btnThemeAi.onclick = copyAiThemePrompt;
    const btnAddPack = document.getElementById('btn-add-pack');
    const packFile = document.getElementById('pack-file');
    if (btnAddPack && packFile) {
      btnAddPack.onclick = () => packFile.click();
      packFile.onchange = async (e) => {
        const f = e.target.files && e.target.files[0];
        packFile.value = '';
        if (!f) return;
        try {
          const added = appendPuzzlesFromText(await f.text());
          if (added > 0) {
            setEditorStatus(`Added ${added} puzzles from "${f.name}". Click Save to keep them.`);
            toast(`Added ${added} puzzles from "${f.name}"`, 'ok');
          } else {
            toast('No valid "CATEGORY | PHRASE" lines found.', 'warn', 3500);
          }
        } catch (_) { toast('Could not read that file.', 'err'); }
      };
    }
    const puzSearch = document.getElementById('ed-puzzle-search');
    if (puzSearch) puzSearch.addEventListener('input', () => filterPuzzleRows(puzSearch.value));

    const catList = document.getElementById('ed-categories-list');
    if (catList) catList.addEventListener('change', updateCategoryHint);
    const btnCatAll = document.getElementById('btn-cat-all');
    const btnCatNone = document.getElementById('btn-cat-none');
    if (btnCatAll) btnCatAll.onclick = () => {
      document.querySelectorAll('#ed-categories-list input[type="checkbox"]').forEach(cb => cb.checked = true);
      updateCategoryHint();
    };
    if (btnCatNone) btnCatNone.onclick = () => {
      document.querySelectorAll('#ed-categories-list input[type="checkbox"]').forEach(cb => cb.checked = false);
      updateCategoryHint();
    };
    const presetBalanced = document.getElementById('btn-preset-balanced');
    if (presetBalanced) presetBalanced.onclick = () => applyPacingPreset('balanced');
    const presetParty = document.getElementById('btn-preset-party');
    if (presetParty) presetParty.onclick = () => applyPacingPreset('party');

    bgFile.onchange = e => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      if (!/^image\//.test(f.type)) { setEditorStatus('Please choose an image file.'); return; }
      if (f.size > 6 * 1024 * 1024) { setEditorStatus('Image is over 6MB — pick a smaller file.'); return; }
      const reader = new FileReader();
      reader.onload = () => {
        pendingBgImage = reader.result;
        renderBgPreview(pendingBgImage);
        setEditorStatus('Background ready — click Save to apply.');
      };
      reader.onerror = () => setEditorStatus('Could not read that file.');
      reader.readAsDataURL(f);
      bgFile.value = '';
    };
    tileFile.onchange=e=>{const f=e.target.files&&e.target.files[0];if(!f)return;if(!/^image\//.test(f.type)||f.size>4*1024*1024){setEditorStatus('Choose a tile image under 4MB.');return}const r=new FileReader();r.onload=()=>{pendingTileImage=r.result;renderTilePreview(pendingTileImage);setEditorStatus('Unused-tile art ready — click Save to apply.')};r.readAsDataURL(f);tileFile.value=''};
    document.getElementById('btn-next-puzzle').onclick = () => {
      const list = state.activePuzzles && state.activePuzzles.length ? state.activePuzzles : state.cfg.puzzles;
      if (state.puzzleIdx + 1 >= list.length) {
        endOrTiebreak();
      } else {
        loadPuzzle(state.puzzleIdx + 1);
      }
    };
    const nextRoundBtn = document.getElementById('btn-next-round');
    if (nextRoundBtn) nextRoundBtn.onclick = () => document.getElementById('btn-next-puzzle').click();
    const btnVowel = document.getElementById('btn-vowel');
    if (btnVowel) btnVowel.onclick = () => msg('Click a vowel in the bank.');
    document.getElementById('btn-solve').onclick = solveAttempt;
    const btnSkipPlayer = document.getElementById('btn-skip-player');
    if (btnSkipPlayer) btnSkipPlayer.onclick = skipActivePlayer;
    const btnSkipRound = document.getElementById('btn-skip-round');
    if (btnSkipRound) btnSkipRound.onclick = skipPuzzle;
    const btnSpeedUp = document.getElementById('btn-speedup');
    if (btnSpeedUp) btnSpeedUp.onclick = async () => {
      if (!state.phase || state.phase.type !== 'round' || state.roundOver) { msg('Speed-Up is available during a regular round.'); return; }
      const ok = await openModal({title:'Begin Final Spin / Speed-Up?',copy:'The host spins once. Consonants will be worth the landed amount plus $1,000. Players then call letters without spinning and get three seconds to solve.',input:false,confirmText:'Begin Speed-Up'});
      if (!ok) return;
      captureUndo('start speed-up');
      state.speedUpAwaitingSpin = true;
      state.speedUpMode = false;
      state.expressMode = false;
      state.canGuess = false; state.spinValue = null;
      msg('🔔 FINAL SPIN — host, spin the wheel now.');
      showReveal('FINAL SPIN','money','host spins · value + $1,000',1800);
      document.getElementById('hub').click();
    };
    const btnReveal = document.getElementById('btn-reveal');
    if (btnReveal) btnReveal.onclick = revealAnswer;
    const btnBonusPick = document.getElementById('btn-bonus-pick');
    if (btnBonusPick) btnBonusPick.onclick = () => bonusPickLetters();
    const goRestart = document.getElementById('btn-gameover-restart');
    if (goRestart) goRestart.onclick = () => { hideGameOver(); startClassic(); };
    const goMenu = document.getElementById('btn-gameover-menu');
    if (goMenu) goMenu.onclick = () => { hideGameOver(); show('title'); };
    const goShare = document.getElementById('btn-gameover-share');
    if (goShare) goShare.onclick = () => downloadTrophyCard();

    // Apply a spin's result — extracted verbatim from the old inline handler so the
    // full-screen overlay and the (fallback) inline wheel share identical scoring.
    function applySpinResult(label){
        state.spinPending = false;
        captureUndo('wheel spin');
        if (state.speedUpAwaitingSpin) {
          if (!/^\d+$/.test(label)) {
            setSpinResult(label,'bad');
            msg('Final Spin must land on a dollar value — host, spin again.');
            showReveal('SPIN AGAIN','lose','final spin needs a dollar value',1600);
            syncRemoteControls();
            return;
          }
          state.speedUpAwaitingSpin = false;
          state.speedUpMode = true;
          state.speedUpValue = Number(label) + 1000;
          customAudio.play('speedUp',true,.72);
          state.spinValue = state.speedUpValue;
          state.canGuess = true;
          setSpinResult(String(state.speedUpValue),'money');
          publishAudienceSpin('audience-spin-result',{label:String(state.speedUpValue)});
          msg(`🔔 SPEED-UP: consonants are worth $${state.speedUpValue.toLocaleString()}. ${state.cfg.players[state.activePlayer].name} calls a letter.`);
          showReveal('$'+state.speedUpValue.toLocaleString(),'money','speed-up consonant value',2200);
          renderScore(); syncRemoteControls(); saveGame();
          return;
        }
        const handleBankrupt = () => {
          setSpinResult('BANKRUPT', 'bad');
          state.scores[state.activePlayer] = 0;
          resetStreak(state.activePlayer);
          state.pendingDouble = false;
          msg('BANKRUPT! Round bank cleared.');
          sfx.bankrupt();
          wheelLandingPulse('bad');
          showReveal('BANKRUPT','bankrupt','round bank cleared',2000);
          shakeScreen();
          renderScore(); nextPlayer();
        };
        const handleMoney = (cents, banner) => {
          const mult = currentRoundMultiplier();
          const scaled = Math.round(cents * mult);
          setSpinResult(String(cents), 'money');
          state.spinValue = scaled;
          state.canGuess = true;
          const phase = currentPhase();
          const roundNo = (phase && phase.type === 'round' && phase.num) ? phase.num : (state.puzzleIdx + 1);
          const multTxt = mult !== 1 ? `Round ${roundNo}: $${cents} × ${mult} = $${scaled} per consonant` : '';
          msg(`${multTxt || banner || '$'+scaled+' per consonant'}. Pick a letter.`);
          sfx.cha();
          wheelLandingPulse('money');
          moneyBurst();
          showReveal('$'+cents,'money', mult !== 1 ? `ROUND ${roundNo} × ${mult} = $${scaled} PER CONSONANT` : 'per consonant',1500, startTurnTimer);
          saveGame();
        };
        if (label === 'BANKRUPT'){
          handleBankrupt();
        } else if (label === 'LOSE'){
          setSpinResult(label, 'bad');
          resetStreak(state.activePlayer);
          state.pendingDouble = false;
          msg('Lose a turn.');
          sfx.buzzer();
          wheelLandingPulse('bad');
          showReveal('LOSE A TURN','lose','',1600);
          nextPlayer();
        } else if (label === 'FREE'){
          setSpinResult(label, 'free');
          state.spinValue = 500; state.canGuess = true; state.freePlay = true;
          msg('FREE PLAY - guess any letter with no cost and no turn penalty.');
          sfx.free();
          wheelLandingPulse('free');
          showReveal('FREE PLAY','free','no penalty',1800, startTurnTimer);
          showSpecialNotice('FREE PLAY','Guess any letter with no cost and no turn penalty.');setTimeout(clearSpecialNotice,4200);
          saveGame();
        } else if (label === 'MYSTERY'){
          const epoch = state.epoch;
          state.spinPending = true;
          setSpinResult('MYSTERY','money');
          showSpecialNotice('MYSTERY WEDGE','Risk the current round bank for a hidden $10,000—or take the safe $1,000 consonant value.');
          openModal({title:'Mystery Wedge',copy:`Risk ${state.cfg.players[state.activePlayer].name}'s current $${(state.scores[state.activePlayer]||0).toLocaleString()} round bank for the hidden $10,000—or choose the safe $1,000 consonant value.`,input:false,confirmText:'Risk It for $10,000',cancelText:'Take Safe $1,000'}).then(risk => {
            clearSpecialNotice();
            if (epoch !== state.epoch || state.roundOver) return;
            state.spinPending = false;
            if (!risk) { handleMoney(1000,'Safe Mystery value: $1,000 per consonant'); return; }
            const isJackpot = Math.random() < 0.5;
            showReveal('MYSTERY','solve','revealing…',1000);
            setTimeout(() => {
              if (epoch !== state.epoch || state.roundOver) return;
              if (isJackpot) {
                state.scores[state.activePlayer] += 10000;
                state.canGuess = false; state.spinValue = null;
                msg('MYSTERY WIN! $10,000 added to the round bank. Spin again.');
                showReveal('$10,000','money','mystery prize!',2200);
                if (sfx.fanfare) sfx.fanfare();
                renderScore(); saveGame();
              } else handleBankrupt();
            },1050);
          });
        } else if (label === 'DOUBLE'){
          setSpinResult('DOUBLE', 'free');
          state.pendingDouble = true;
          state.canGuess = false; state.spinValue = null;
          msg('🔥 DOUBLE! Spin again — your next correct consonant pays 2×.');
          sfx.free();
          wheelLandingPulse('free');
          showReveal('×2 DOUBLE','solve','next consonant pays 2×',1800);
          showSpecialNotice('2× DOUBLE','Spin again. The next correct consonant pays double.');setTimeout(clearSpecialNotice,4200);
          saveGame();
        } else if (label === 'WILD'){
          setSpinResult('WILD', 'free');
          state.wildCards = state.wildCards || state.cfg.players.map(()=>0);
          state.wildCards[state.activePlayer] = (state.wildCards[state.activePlayer]||0) + 1;
          state.canGuess = false; state.spinValue = null;
          msg('🃏 WILD! You hold a free consonant guess. Spin again to use the wheel.');
          sfx.free();
          wheelLandingPulse('free');
          showReveal('WILD CARD','solve','+1 free consonant',1800);
          publishAudienceSpin('audience-notice',{title:'WILD CARD',copy:`${state.cfg.players[state.activePlayer].name} now holds a free consonant guess.`,kicker:'SPECIAL WEDGE'});
          window.WheelBuzzer?.sendToPlayer?.(state.activePlayer,{type:'special-notice',title:'WILD CARD WON',copy:'Use the Wild Card button on your phone when you want a free consonant guess.',kicker:'THIS CARD BELONGS TO YOU'});
          setTimeout(()=>publishAudienceSpin('audience-notice-clear'),4600);
          renderScore();
        } else if (label === 'GIFT'){
          setSpinResult('GIFT', 'free');
          state.scores[state.activePlayer] += 1000;
          state.canGuess = false; state.spinValue = null;
          msg('🎁 GIFT TAG! +$1,000 added to the round bank. Spin again.');
          sfx.free(); wheelLandingPulse('free');
          showReveal('GIFT TAG','solve','+$1,000 prize',1800);
          showSpecialNotice('GIFT TAG','A $1,000 prize has been added to the current round bank.');setTimeout(clearSpecialNotice,4200);
          renderScore();
        } else if (label === 'EXPRESS'){
          setSpinResult('EXPRESS', 'money');
          state.expressMode = true;
          state.spinValue = 1000; state.canGuess = true;
          msg('🚂 EXPRESS! Call consonants for $1,000 each without spinning. A miss loses the round bank.');
          if (sfx.fanfare) sfx.fanfare(); wheelLandingPulse('money');
          showReveal('EXPRESS','money','$1,000 per consonant · miss = bankrupt',2200,startTurnTimer);
          showSpecialNotice('EXPRESS','Call consonants for $1,000 each without spinning. A miss loses the round bank.');setTimeout(clearSpecialNotice,5200);
          saveGame();
        } else {
          // Money
          handleMoney(Number(label));
        }
        syncRemoteControls();
    }

    // Full-screen spin: show the overlay, auto-spin the big wheel, then return to the
    // board and apply the result. Reuses spinWheel + applySpinResult (no logic change).
    function openSpinOverlay(profile = {}){
      const epoch = state.epoch;
      const ov = document.getElementById('wheel-overlay');
      const svg = document.getElementById('wheel-big');
      if (!ov || !svg){ // markup missing → fall back to the inline wheel so play never breaks
        spinWheel(document.getElementById('wheel'), currentWheelSlices(), applySpinResult, profile);
        return;
      }
      if (ov.classList.contains('show')) return;           // already spinning
      syncRemoteControls();
      if (!svg.childNodes.length) buildWheel(svg, currentWheelSlices(), 'classic');
      const pe = document.getElementById('wheel-overlay-player');
      if (pe){ const p = state.cfg.players[state.activePlayer]; pe.innerHTML = p ? `${avatarHtml(p.avatar)}<span>${escapeHtml(p.name)}</span>` : ''; }
      const re = document.getElementById('wheel-overlay-result'); if (re) re.textContent = '';
      ov.classList.add('show'); ov.setAttribute('aria-hidden','false');
      spinWheel(svg, currentWheelSlices(), (label) => {
        if (re) re.textContent = /^\d+$/.test(label) ? '$' + label : label;
        if (epoch !== state.epoch || state.roundOver) return;
        state.spinPending = true;
        // hold on the landed slice briefly (full-screen), then return to the board
        setTimeout(() => {
          if (epoch !== state.epoch || state.roundOver) return;
          ov.classList.remove('show'); ov.setAttribute('aria-hidden','true');
          publishAudienceSpin('audience-spin-end');
          applySpinResult(label);
        }, 900);
      }, profile);
    }

    document.getElementById('hub').onclick = () => {
      if (state.spinning || state.spinPending || state.roundOver || state.solveLocked) return;
      if (document.getElementById('modal')?.classList.contains('show')) return;
      if (document.getElementById('wheel-overlay')?.classList.contains('show')) return;
      if (state.phase && (state.phase.type === 'tossup' || state.phase.type === 'bonus' || state.phase.type === 'tiebreak')) {
        msg(state.phase.type === 'bonus' ? 'Bonus round — click Pick Letters / Solve.'
          : state.phase.type === 'tiebreak' ? 'Tiebreaker — first to solve wins. Click Solve to award.'
          : 'Toss-up in progress — click Solve to award.');
        return;
      }
      if (state.speedUpMode) { msg('Speed-Up is active — call a letter or solve. No more spinning.'); return; }
      if (state.canGuess || state.freePlay) { msg('Use your spin: call a letter, buy a vowel, or solve first.'); return; }
      openSpinOverlay();
    };

    document.getElementById('hub-party').onclick = () => {
      if (state.spinning) return;
      const svg = document.getElementById('wheel-party');
      spinWheel(svg, state.cfg.party, (label) => {
        document.getElementById('party-result').textContent = label;
        confettiBurst();
        sfx.solve();
        showReveal(label,'party','',2200);
      });
    };
    bindKeyboard();
  }

  function bindKeyboard(){
    document.addEventListener('keydown', e => {
      if (document.getElementById('modal').classList.contains('show')) return;
      // Do not turn Enter/Space used to activate a focused control into a second
      // game shortcut (for example Start Toss-Up immediately becoming Solve).
      const focusedTag = document.activeElement && document.activeElement.tagName;
      if (['INPUT','TEXTAREA','SELECT'].includes(focusedTag)) return;
      const focusedButton = focusedTag === 'BUTTON';
      const active = document.querySelector('.screen.active');
      if (!active) return;
      const key = e.key.toLowerCase();
      if (active.id === 'screen-classic') {
        if (key === ' ' && !focusedButton) { e.preventDefault(); document.getElementById('hub').click(); }
        if (key === 'enter' && !focusedButton) document.getElementById('btn-solve').click();
        if (key === 'escape') {
          // Close kebab menu if open
          const m = document.getElementById('more-menu');
          if (m && m.classList.contains('open')) closeMoreMenu();
        }
        // Plain A-Z is always a letter call. Host actions stay on visible controls.
        if (/^[a-z]$/.test(key)) {
          const btn = [...document.querySelectorAll('.letter-bank button')].find(b => b.textContent.toLowerCase() === key && !b.disabled && !b.classList.contains('used'));
          if (btn) { e.preventDefault(); btn.click(); btn.blur(); }
        }
      }
      if (active.id === 'screen-party' && (key === ' ' || key === 's')) {
        e.preventDefault();
        document.getElementById('hub-party').click();
      }
    });
  }

  /* ---------- PLAYER SETUP (pre-game) ---------- */
  function updateSponsorStatus(){const el=document.getElementById('setup-sponsor-status');if(el)el.textContent=`${(state.cfg.sponsorSlides||[]).length} sponsor image${(state.cfg.sponsorSlides||[]).length===1?'':'s'} loaded.`;}
  function resizeSponsorImage(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=reject;reader.onload=()=>{const img=new Image();img.onerror=reject;img.onload=()=>{const maxW=1280,maxH=720,scale=Math.min(1,maxW/img.width,maxH/img.height),c=document.createElement('canvas');c.width=Math.round(img.width*scale);c.height=Math.round(img.height*scale);c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.68))};img.src=reader.result};reader.readAsDataURL(file)});}
  async function loadSponsorFiles(files){const chosen=[...(files||[])].slice(0,8);if(!chosen.length)return;const out=[];for(const f of chosen){if(/^image\//.test(f.type)){try{out.push(await resizeSponsorImage(f))}catch(_){}}}state.cfg.sponsorSlides=out;state.cfg.sponsorEnabled=out.length>0;const saved=save();updateSponsorStatus();const cb=document.getElementById('setup-sponsor-enabled');if(cb)cb.checked=state.cfg.sponsorEnabled;publishAudienceDisplay();toast(saved?`${out.length} sponsor slide${out.length===1?'':'s'} ready`:'Slides loaded for this session, but browser storage is full.','ok');}
  function populateV4Selects(){
    const labels=window.WHEEL_V4_THEME_LABELS||{};
    const themeNight=document.getElementById('ed-theme-night');
    if(themeNight&&!themeNight.options.length)Object.keys(labels).forEach(key=>themeNight.add(new Option(labels[key]+' Night',key)));
    const puzzleTheme=document.getElementById('setup-puzzle-theme');
    if(puzzleTheme&&puzzleTheme.options.length<=2)Object.keys(labels).forEach(key=>puzzleTheme.add(new Option(labels[key]+' puzzles',key)));
    if(puzzleTheme)puzzleTheme.value=state.cfg.puzzleTheme||'all';
    const themes=window.WHEEL_V4_VISUAL_THEMES||{};
    ['setup-visual-theme','title-visual-theme'].forEach(id=>{const visual=document.getElementById(id);if(visual&&!visual.options.length)Object.keys(themes).forEach(key=>visual.add(new Option(themes[key].label,key)));if(visual)visual.value=state.cfg.visualTheme||'classic'});
    const category=document.getElementById('setup-puzzle-category');
    if(category&&category.options.length===1){
      const cats=[...new Set((state.cfg.puzzles||[]).map(p=>String(p.cat||'').toUpperCase()).filter(Boolean))].sort();
      cats.forEach(cat=>category.add(new Option(cat,cat)));
    }
  }
  function openSetup(){
    populateV4Selects();
    const list = (state.cfg.players && state.cfg.players.length >= 1)
      ? state.cfg.players.map(p => ({ name:p.name, color:p.color, avatar:p.avatar }))
      : normalizePlayers(defaults.players.slice(0, 3));
    renderPlayerEditor(list, 'setup-players-list');
    const count = document.getElementById('setup-player-count');
    if (count) count.value = String(Math.max(2, Math.min(6, list.length)));
    const welcome = document.getElementById('setup-welcome-message');
    if (welcome) welcome.value = String(state.cfg.welcomeMessage || '');
    const winnerMessage=document.getElementById('setup-winner-message');if(winnerMessage)winnerMessage.value=String(state.cfg.winnerMessage||'');
    const visual=document.getElementById('setup-visual-theme');if(visual)visual.value=state.cfg.visualTheme||'classic';
    const difficulty=document.getElementById('setup-puzzle-difficulty');if(difficulty)difficulty.value=state.cfg.puzzleDifficulty||'random';
    const puzzleTheme=document.getElementById('setup-puzzle-theme');if(puzzleTheme)puzzleTheme.value=state.cfg.puzzleTheme||'all';
    const category=document.getElementById('setup-puzzle-category');if(category)category.value=(state.cfg.enabledCategories||[]).length===1?state.cfg.enabledCategories[0]:'';
    const sponsor=document.getElementById('setup-sponsor-enabled');if(sponsor)sponsor.checked=!!state.cfg.sponsorEnabled;updateSponsorStatus();
    const lbl = document.getElementById('setup-mode-label');
    if (lbl) {
      lbl.textContent = state.mode === 'party'
        ? 'Party Wheel — add your players, then start.'
        : state.cfg.solveMode === 'hostless'
          ? 'Hostless — type answers, auto-judged. Add players, then start.'
          : 'TV Mode — a host runs the game. Add players, then start.';
    }
    show('setup');
    // First-run onboarding: auto-show the How-to-Play carousel once (covers the
    // special wedges MYSTERY/DOUBLE/WILD). Shown over the setup screen so it never
    // overlaps the first-player picker or live gameplay.
    if (!storageGet('spinSolveSeenHelp')) {
      storageSet('spinSolveSeenHelp', '1');
      setTimeout(() => { try { openHelp(); } catch (_) {} }, 380);
    }
  }
  function setupStartGame(){
    const players = collectPlayerEditor('setup-players-list');
    if (players.length < 2) { toast('Add at least 2 players to start.', 'warn'); return; }
    state.cfg.players = normalizePlayers(players);
    const welcome = document.getElementById('setup-welcome-message');
    if (welcome) state.cfg.welcomeMessage = welcome.value.trim();
    const winnerMessage=document.getElementById('setup-winner-message');if(winnerMessage)state.cfg.winnerMessage=winnerMessage.value.trim();
    const visual=document.getElementById('setup-visual-theme');if(visual)state.cfg.visualTheme=visual.value||'classic';
    const difficulty=document.getElementById('setup-puzzle-difficulty');if(difficulty)state.cfg.puzzleDifficulty=difficulty.value||'random';
    const puzzleTheme=document.getElementById('setup-puzzle-theme');if(puzzleTheme)state.cfg.puzzleTheme=puzzleTheme.value||'all';
    const category=document.getElementById('setup-puzzle-category');if(category)state.cfg.enabledCategories=category.value?[category.value]:[];
    const sponsor=document.getElementById('setup-sponsor-enabled');if(sponsor)state.cfg.sponsorEnabled=!!sponsor.checked&&!!(state.cfg.sponsorSlides||[]).length;
    save();
    applyVisualTheme();
    const start = () => { if (state.mode === 'classic') startClassic(); else startParty(); };
    if (state.mode === 'classic') playIntroVideo(start);
    else start();
  }
  function setupAddPlayer(){
    const players = collectPlayerEditor('setup-players-list');
    if (players.length >= 6) { toast('Maximum 6 players.', 'warn'); return; }
    const palette = ['#ff2f7f','#ffd60a','#27d9ff','#37e36b','#b06bff','#ff9f1c'];
    const avs = ['🐼','🦁','🐯','🦊','🐻','🐨'];
    const i = players.length;
    players.push({ name: 'Player ' + (i + 1), color: palette[i % palette.length], avatar: avs[i % avs.length] });
    renderPlayerEditor(players, 'setup-players-list');
    const count = document.getElementById('setup-player-count');
    if (count) count.value = String(players.length);
  }

  function setSetupPlayerCount(wanted){
    wanted = Math.max(2, Math.min(6, wanted || 3));
    const players = collectPlayerEditor('setup-players-list');
    const palette = ['#ff2f7f','#ffd60a','#27d9ff','#37e36b','#b06bff','#ff9f1c'];
    const avs = ['🐼','🦁','🐯','🦊','🐻','🐨'];
    while (players.length < wanted) {
      const i = players.length;
      players.push({name:'Player '+(i+1),color:palette[i],avatar:avs[i]});
    }
    players.length = wanted;
    renderPlayerEditor(players, 'setup-players-list');
  }

  let pendingBgImage = null; // null = unchanged, '' = clear, string = new data URL
  let pendingTileImage = null;
  function openEditor(){
    populateV4Selects();
    show('edit');
    setEditorStatus('');
    pendingBgImage = null;
    pendingTileImage = null;
    renderPuzzleEditor(state.cfg.puzzles);
    document.getElementById('ed-slices').value = state.cfg.slices.join(', ');
    document.getElementById('ed-party').value = state.cfg.party.join(', ');
    renderPlayerEditor(state.cfg.players);
    const timerOn = (state.cfg.timeLimit ?? 20) > 0;
    document.getElementById('ed-timer-on').checked = timerOn;
    document.getElementById('ed-timer').value = (state.cfg.timeLimit && state.cfg.timeLimit > 0) ? state.cfg.timeLimit : 20;
    syncTimerEnabled();
    document.getElementById('ed-auto-advance').checked = state.cfg.autoAdvance !== false;
    const siEl = document.getElementById('ed-skip-intro');
    if (siEl) siEl.checked = state.cfg.skipIntro === true;
    const smEl = document.getElementById('ed-solve-mode');
    if (smEl) {
      const rawCur = state.cfg.solveMode || 'tv';
      const cur = (rawCur === 'party' || rawCur === 'tv') ? 'tv' : 'hostless';
      smEl.querySelectorAll('.seg-opt').forEach(b => {
        b.classList.toggle('active', b.dataset.val === cur);
        b.onclick = () => {
          smEl.querySelectorAll('.seg-opt').forEach(x => x.classList.remove('active'));
          b.classList.add('active');
        };
      });
    }
    const spEl = document.getElementById('ed-sound-pack');
    if (spEl) spEl.value = state.cfg.soundPack || 'tv';
    setEditorChecked('ed-crowd-enabled', state.cfg.crowdEnabled !== false);
    setEditorValue('ed-crowd-volume', Math.round(Number(state.cfg.crowdVolume ?? .60) * 100));
    setEditorChecked('ed-music-enabled', state.cfg.musicEnabled !== false);
    setEditorValue('ed-music-volume', Math.round(Number(state.cfg.musicVolume ?? .22) * 100));
    const crowdOut = document.getElementById('ed-crowd-volume-out');
    const musicOut = document.getElementById('ed-music-volume-out');
    if (crowdOut) crowdOut.textContent = `${document.getElementById('ed-crowd-volume').value}%`;
    if (musicOut) musicOut.textContent = `${document.getElementById('ed-music-volume').value}%`;
    document.getElementById('ed-vowel-cost').value = state.cfg.vowelCost ?? 250;
    document.getElementById('ed-solve-bonus').value = state.cfg.solveBonus ?? 1000;
    document.getElementById('ed-shuffle').checked = !!state.cfg.shuffle;
    { const mdEl = document.getElementById('ed-max-diff'); if (mdEl) mdEl.value = state.cfg.maxDiff || 'all'; }
    document.getElementById('ed-max-rounds').value = state.cfg.maxRounds || 0;
    const rmOn = state.cfg.roundMode !== false;
    document.getElementById('ed-round-mode').checked = rmOn;
    document.getElementById('ed-round-count').value = state.cfg.roundCount || 4;
    document.getElementById('ed-round-mults').value = (state.cfg.roundMultipliers || [1, 1.5, 2]).join(', ');
    document.getElementById('ed-tossup-enabled').checked = state.cfg.tossupEnabled !== false;
    document.getElementById('ed-tossup-values').value = (state.cfg.tossupValues || [1000, 2000, 3000]).join(', ');
    document.getElementById('ed-tossup-ms').value = state.cfg.tossupRevealMs || 1500;
    document.getElementById('ed-bonus-enabled').checked = state.cfg.bonusEnabled !== false;
    document.getElementById('ed-bonus-prize').value = state.cfg.bonusPrize ?? 50000;
    document.getElementById('ed-bonus-timer').value = state.cfg.bonusTimerSeconds ?? 20;
    syncRoundModeEnabled();
    updateMaxRoundsHint();
    renderCategoryFilter();
    renderBgPreview(state.cfg.bgImage || '');
    renderTilePreview(state.cfg.tileImage || '');
  }

  function updateMaxRoundsHint(){
    const list = document.getElementById('ed-puzzles-list');
    const total = list ? list.children.length : (state.cfg.puzzles || []).length;
    const inp = document.getElementById('ed-max-rounds');
    const hint = document.getElementById('ed-max-hint');
    if (inp) inp.max = String(total || 500);
    if (hint) hint.textContent = total ? `(max ${total})` : '';
  }

  function makePuzzleRow(p, idx){
    const row = document.createElement('div');
    row.className = 'puzzle-row';
    row.dataset.idx = String(idx);
    // Fallback store; the visible <select> below is the source of truth.
    row.dataset.diff = p.diff || '';
    row.dataset.custom = p.custom === true ? '1' : '0';

    const num = document.createElement('span');
    num.className = 'puzzle-num';
    num.textContent = String(idx + 1);

    const cat = document.createElement('input');
    cat.className = 'puzzle-cat';
    cat.setAttribute('list', 'puzzle-categories');
    cat.placeholder = 'CATEGORY';
    cat.maxLength = 24;
    cat.value = p.cat || '';

    const txt = document.createElement('input');
    txt.className = 'puzzle-text';
    txt.placeholder = 'PHRASE';
    txt.maxLength = 42;
    txt.value = p.text || '';

    const len = document.createElement('span');
    len.className = 'puzzle-len';
    const updateLen = () => {
      const v = txt.value.trim();
      len.textContent = `${v.length}/42`;
      const over = v.length > 42;
      const empty = v.length === 0;
      len.classList.toggle('over', over);
      len.classList.toggle('empty', empty);
      row.classList.toggle('invalid', over || empty || !cat.value.trim());
    };
    txt.addEventListener('input', updateLen);
    cat.addEventListener('input', updateLen);
    updateLen();

    const diff = document.createElement('select');
    diff.className = 'puzzle-diff';
    diff.title = 'Difficulty tier (controls which round this puzzle appears in)';
    [['easy','Easy'],['med','Med'],['hard','Hard']].forEach(([v,label]) => {
      const o = document.createElement('option');
      o.value = v; o.textContent = label;
      diff.appendChild(o);
    });
    diff.value = normDiff(p.diff);
    row.dataset.diff = diff.value;
    diff.addEventListener('change', () => { row.dataset.diff = diff.value; });

    const up = document.createElement('button');
    up.type = 'button'; up.className = 'puzzle-mv'; up.textContent = '↑'; up.title = 'Move up';
    up.onclick = () => movePuzzleRow(row, -1);

    const dn = document.createElement('button');
    dn.type = 'button'; dn.className = 'puzzle-mv'; dn.textContent = '↓'; dn.title = 'Move down';
    dn.onclick = () => movePuzzleRow(row, 1);

    const rm = document.createElement('button');
    rm.type = 'button'; rm.className = 'puzzle-rm'; rm.textContent = '✕'; rm.title = 'Remove puzzle';
    rm.onclick = () => removePuzzleRow(row);

    row.append(num, cat, txt, diff, len, up, dn, rm);
    return row;
  }

  function renderPuzzleEditor(list){
    const wrap = document.getElementById('ed-puzzles-list');
    if (!wrap) return;
    wrap.innerHTML = '';
    list.forEach((p, i) => wrap.appendChild(makePuzzleRow(p, i)));
    refreshPuzzleNumbers();
  }

  function refreshPuzzleNumbers(){
    const wrap = document.getElementById('ed-puzzles-list');
    if (!wrap) return;
    Array.from(wrap.children).forEach((row, i) => {
      const n = row.querySelector('.puzzle-num');
      if (n) n.textContent = String(i + 1);
    });
    const cnt = document.getElementById('ed-puzzle-count');
    if (cnt) cnt.textContent = String(wrap.children.length);
    updateMaxRoundsHint();
    renderCategoryFilter();
  }

  function getCurrentCategoryCounts(){
    // read from open editor if present, else from saved cfg
    const wrap = document.getElementById('ed-puzzles-list');
    const counts = {};
    if (wrap && wrap.children.length){
      Array.from(wrap.children).forEach(row => {
        const cat = (row.querySelector('.puzzle-cat')?.value || '').trim().toUpperCase();
        if (!cat) return;
        counts[cat] = (counts[cat] || 0) + 1;
      });
    } else {
      (state.cfg.puzzles || []).forEach(p => {
        const cat = String(p.cat).toUpperCase();
        counts[cat] = (counts[cat] || 0) + 1;
      });
    }
    return counts;
  }

  function renderCategoryFilter(){
    const wrap = document.getElementById('ed-categories-list');
    if (!wrap) return;
    const prevChecked = collectEnabledCategories();
    const counts = getCurrentCategoryCounts();
    const cats = Object.keys(counts).sort();
    const enabledSet = new Set((Array.isArray(state.cfg.enabledCategories) && state.cfg.enabledCategories.length)
      ? state.cfg.enabledCategories.map(c => String(c).toUpperCase())
      : cats); // empty/missing = all enabled by default
    // Preserve user's in-edit selection if present
    if (prevChecked.length) {
      enabledSet.clear();
      prevChecked.forEach(c => enabledSet.add(c));
    }
    wrap.innerHTML = '';
    cats.forEach(cat => {
      const lbl = document.createElement('label');
      lbl.className = 'cat-row';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = cat;
      cb.checked = enabledSet.has(cat);
      const text = document.createElement('span');
      text.className = 'cat-name';
      text.textContent = cat;
      const count = document.createElement('span');
      count.className = 'cat-count';
      count.textContent = `(${counts[cat]})`;
      lbl.append(cb, text, count);
      wrap.appendChild(lbl);
    });
    updateCategoryHint();
  }

  function collectEnabledCategories(){
    const wrap = document.getElementById('ed-categories-list');
    if (!wrap) return [];
    return Array.from(wrap.querySelectorAll('input[type="checkbox"]'))
      .filter(cb => cb.checked)
      .map(cb => cb.value);
  }

  function updateCategoryHint(){
    const hint = document.getElementById('ed-cat-hint');
    if (!hint) return;
    const wrap = document.getElementById('ed-categories-list');
    if (!wrap) return;
    const total = wrap.querySelectorAll('input[type="checkbox"]').length;
    const checked = wrap.querySelectorAll('input[type="checkbox"]:checked').length;
    if (checked === total) hint.textContent = 'All categories';
    else if (checked === 0) hint.textContent = 'None — falls back to all';
    else hint.textContent = `${checked} of ${total}`;
  }

  function movePuzzleRow(row, delta){
    const wrap = row.parentNode;
    const sib = delta < 0 ? row.previousElementSibling : row.nextElementSibling;
    if (!sib) return;
    if (delta < 0) wrap.insertBefore(row, sib);
    else wrap.insertBefore(sib, row);
    refreshPuzzleNumbers();
    row.querySelector('.puzzle-cat').focus();
  }

  function removePuzzleRow(row){
    const wrap = row.parentNode;
    if (wrap.children.length <= 1) return;
    row.remove();
    refreshPuzzleNumbers();
  }

  function addPuzzleRow(){
    const wrap = document.getElementById('ed-puzzles-list');
    if (!wrap) return;
    const row = makePuzzleRow({cat:'PHRASE', text:'', custom:true}, wrap.children.length);
    wrap.appendChild(row);
    refreshPuzzleNumbers();
    row.scrollIntoView({block:'nearest'});
    row.querySelector('.puzzle-text').focus();
  }

  async function loadThemeNight(replaceExisting){
    const key=document.getElementById('ed-theme-night')?.value||'80s';
    const src=THEME_NIGHT_PACKS[key]||[];
    if(!src.length)return;
    if(replaceExisting){
      const ok=await openModal({title:'Use This Theme Night?',copy:`This will replace the puzzle list currently shown in the editor with ${src.length} themed puzzles. Your saved list is not changed until you click Save.`,input:false,confirmText:'Use Theme Night'});
      if(!ok)return;
      renderPuzzleEditor(src.map(p=>Array.isArray(p)?{cat:p[0],text:p[1],diff:p[2],custom:true}:{...p,custom:true}));
      setEditorStatus(`${src.length} themed puzzles loaded. Review them, then click Save.`);
    }else{
      const wrap=document.getElementById('ed-puzzles-list');
      src.forEach(p=>wrap.appendChild(makePuzzleRow(Array.isArray(p)?{cat:p[0],text:p[1],diff:p[2],custom:true}:{...p,custom:true},wrap.children.length)));
      refreshPuzzleNumbers();
      setEditorStatus(`Added ${src.length} themed puzzles. Click Save to keep them.`);
    }
  }

  async function copyAiThemePrompt(){
    const select=document.getElementById('ed-theme-night');
    const theme=select?.options[select.selectedIndex]?.textContent.replace(/^\S+\s*/,'')||'custom theme';
    const prompt=`Create 30 original Wheel-style word puzzles for a ${theme} live game night. Return only one puzzle per line in this exact format: CATEGORY | PUZZLE. Use varied categories such as PHRASE, THING, PLACE, PERSON, EVENT, TITLE, FOOD & DRINK, OCCUPATION, AROUND THE HOUSE, BEFORE & AFTER, and SAME LETTER. Every complete puzzle must be 42 characters or fewer including spaces. No single word may exceed 14 characters. Use family-friendly language, avoid duplicate answers, avoid obscure trivia, and mix easy, medium, and hard puzzles.`;
    try{await navigator.clipboard.writeText(prompt);setEditorStatus('AI puzzle prompt copied. Paste it into ChatGPT, save the returned lines as a .txt file, then use Add Pack (.txt).');toast('AI puzzle prompt copied','ok',3500)}
    catch(_){await openModal({title:'AI Puzzle Generator Prompt',copy:prompt,input:false,confirmText:'Done'});}
  }

  // Append puzzles from a pasted/loaded "CATEGORY | PHRASE" text block (non-destructive).
  function appendPuzzlesFromText(text){
    const wrap = document.getElementById('ed-puzzles-list');
    if (!wrap) return 0;
    let added = 0;
    (text || '').split(/\r?\n/).forEach(raw => {
      const line = raw.trim();
      if (!line || line.startsWith('#') || line.startsWith('//')) return;
      const bar = line.indexOf('|');
      if (bar < 0) return;
      const cat = line.slice(0, bar).trim().toUpperCase() || 'PHRASE';
      const txt = line.slice(bar + 1).trim().toUpperCase().replace(/\s+/g, ' ');
      if (!txt) return;
      wrap.appendChild(makePuzzleRow({ cat, text: txt, diff: 'med', custom: true }, wrap.children.length));
      added++;
    });
    if (added) refreshPuzzleNumbers();
    return added;
  }

  function collectPuzzleEditor(){
    const wrap = document.getElementById('ed-puzzles-list');
    if (!wrap) return [];
    return Array.from(wrap.querySelectorAll('.puzzle-row')).map(row => ({
      cat: row.querySelector('.puzzle-cat').value.trim().toUpperCase(),
      text: row.querySelector('.puzzle-text').value.trim().toUpperCase().replace(/\s+/g,' '),
      diff: (row.querySelector('.puzzle-diff')?.value) || row.dataset.diff || 'med',
      custom: row.dataset.custom === '1'
    }));
  }

  function filterPuzzleRows(q){
    const wrap = document.getElementById('ed-puzzles-list');
    if (!wrap) return;
    const term = (q || '').trim().toUpperCase();
    Array.from(wrap.children).forEach(row => {
      const cat = row.querySelector('.puzzle-cat').value.toUpperCase();
      const txt = row.querySelector('.puzzle-text').value.toUpperCase();
      const match = !term || cat.includes(term) || txt.includes(term);
      row.style.display = match ? '' : 'none';
    });
  }

  function renderPlayerEditor(list, wrapId){
    const wrap = document.getElementById(wrapId || 'ed-players-list');
    if (!wrap) return;
    wrap.innerHTML = '';
    list.forEach((p, idx) => {
      const row = document.createElement('div');
      row.className = 'player-row';
      row.dataset.idx = String(idx);

      // avatar — click to cycle through preset emojis (or upload image)
      const av = document.createElement('button');
      av.type = 'button';
      av.className = 'player-avatar-btn';
      av.dataset.avatar = p.avatar || '⭐';
      renderAvatarBtn(av);
      av.title = 'Click to cycle emoji';
      av.onclick = () => {
        const cur = av.dataset.avatar;
        const idx = AVATAR_OPTIONS.indexOf(cur);
        const next = AVATAR_OPTIONS[(idx + 1) % AVATAR_OPTIONS.length];
        av.dataset.avatar = next;
        renderAvatarBtn(av);
      };
      const upload = document.createElement('button');
      upload.type = 'button';
      upload.className = 'player-upload-btn';
      upload.title = 'Upload custom photo';
      upload.textContent = '📷';
      const fileIn = document.createElement('input');
      fileIn.type = 'file';
      fileIn.accept = 'image/*';
      fileIn.hidden = true;
      upload.onclick = () => fileIn.click();
      fileIn.onchange = (e) => {
        const f = e.target.files && e.target.files[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = () => {
          av.dataset.avatar = String(reader.result);
          renderAvatarBtn(av);
        };
        reader.readAsDataURL(f);
        fileIn.value = '';
      };

      // color
      const col = document.createElement('input');
      col.type = 'color';
      col.value = p.color;
      col.className = 'player-color-input';
      col.title = 'Player color';

      // name
      const nm = document.createElement('input');
      nm.type = 'text';
      nm.value = p.name;
      nm.maxLength = 14;
      nm.className = 'player-name-input';
      nm.placeholder = 'Player name';

      // remove
      const rm = document.createElement('button');
      rm.type = 'button';
      rm.className = 'player-remove-btn';
      rm.textContent = '✕';
      rm.title = 'Remove player';
      rm.onclick = () => {
        const all = collectPlayerEditor(wrapId);
        if (all.length <= 1) return;
        all.splice(idx, 1);
        renderPlayerEditor(all, wrapId);
      };

      row.append(av, upload, fileIn, col, nm, rm);
      wrap.appendChild(row);
    });
  }

  function renderAvatarBtn(btn){
    const val = btn.dataset.avatar || '⭐';
    btn.innerHTML = '';
    if (/^data:image/.test(val)) {
      const img = document.createElement('img');
      img.src = val;
      img.alt = 'avatar';
      btn.appendChild(img);
    } else {
      btn.textContent = val;
    }
  }

  function escapeHtml(value){ return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
  function avatarHtml(val){
    if (/^data:image/.test(val||'')) return `<img src="${escapeHtml(val)}" alt="" class="avatar-img">`;
    return escapeHtml(val || '⭐');
  }

  function collectPlayerEditor(wrapId){
    const wrap = document.getElementById(wrapId || 'ed-players-list');
    if (!wrap) return [];
    return Array.from(wrap.querySelectorAll('.player-row')).map(row => ({
      name: row.querySelector('.player-name-input').value.trim() || 'Player',
      color: row.querySelector('.player-color-input').value || '#ff2f7f',
      avatar: row.querySelector('.player-avatar-btn').dataset.avatar || '⭐'
    }));
  }

  function syncRoundModeEnabled(){
    const on = document.getElementById('ed-round-mode').checked;
    const body = document.getElementById('ed-round-mode-body');
    if (body) body.style.opacity = on ? '1' : '.5';
    const inputs = ['ed-round-count','ed-round-mults'];
    inputs.forEach(id => { const el = document.getElementById(id); if (el) el.disabled = !on; });
  }

  function syncTimerEnabled(){
    const on = document.getElementById('ed-timer-on').checked;
    const inp = document.getElementById('ed-timer');
    const dec = document.getElementById('btn-timer-dec');
    const inc = document.getElementById('btn-timer-inc');
    inp.disabled = !on;
    if (dec) dec.disabled = !on;
    if (inc) inc.disabled = !on;
  }
  function clampTimer(v){ return Math.max(5, Math.min(300, v|0)); }

  function renderBgPreview(url){
    const prev = document.getElementById('bg-preview');
    const info = document.getElementById('bg-info');
    if (url){
      prev.style.backgroundImage = `url("${url}")`;
      prev.classList.add('has');
      info.textContent = 'Custom background — click Save to apply';
    } else {
      prev.style.backgroundImage = '';
      prev.classList.remove('has');
      info.textContent = 'Default background';
    }
  }
  function renderTilePreview(url){const prev=document.getElementById('tile-preview'),info=document.getElementById('tile-info');if(!prev||!info)return;prev.style.backgroundImage=url?`url("${url}")`:'';prev.classList.toggle('has',!!url);info.textContent=url?'Custom unused-tile art — click Save to apply':'Theme tile pattern'}

  function setEditorValue(id, value){
    const el = document.getElementById(id);
    if (el) el.value = value;
  }

  function setEditorChecked(id, checked){
    const el = document.getElementById(id);
    if (el) el.checked = !!checked;
  }

  function applyPacingPreset(kind){
    const balancedSlices = ['500','600','700','LOSE','650','800','FREE','700','900','BANKRUPT','600','750','WILD','800','900','LOSE','650','1000','FREE','700','800','BANKRUPT','900','1200'];
    const partySlices = ['700','900','MYSTERY','800','1100','BANKRUPT','650','1000','900','750','LOSE','800','1200','WILD','950','750','BANKRUPT','5000','900','1100','FREE','700','800','1500'];
    if (kind === 'balanced') {
      setEditorValue('ed-slices', balancedSlices.join(', '));
      setEditorValue('ed-round-count', '5');
      setEditorValue('ed-round-mults', '1, 1.25, 1.5, 1.75, 2');
      setEditorValue('ed-tossup-values', '1000, 1500, 2000, 2500, 3000');
      setEditorValue('ed-solve-bonus', '1000');
      setEditorValue('ed-bonus-prize', '5000');
      setEditorStatus('Classic Balanced preset loaded. Click Save to apply.');
      toast('Classic Balanced preset loaded', 'ok');
    } else {
      setEditorValue('ed-slices', partySlices.join(', '));
      setEditorValue('ed-round-count', '10');
      setEditorValue('ed-round-mults', '1, 1.25, 1.5, 1.75, 2, 2.5, 3, 3.5, 4, 4.5');
      setEditorValue('ed-tossup-values', '1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000');
      setEditorValue('ed-solve-bonus', '1000');
      setEditorValue('ed-bonus-prize', '50000');
      setEditorStatus('High-Stakes Party preset loaded. 10 rounds is a full-length event; click Save to apply.');
      toast('High-Stakes Party preset loaded', 'ok');
    }
    setEditorChecked('ed-round-mode', true);
    setEditorChecked('ed-bonus-enabled', true);
    syncRoundModeEnabled();
  }

  function saveEditor(){
    const parsed = parseEditor();
    if (parsed.error) { setEditorStatus(parsed.error); toast(parsed.error, 'err', 3500); return; }
    state.cfg.puzzles = parsed.puzzles;
    state.cfg.slices = parsed.slices;
    state.cfg.party = parsed.party;
    state.cfg.players = parsed.players;
    if (pendingBgImage !== null) state.cfg.bgImage = pendingBgImage;
    if (pendingTileImage !== null) state.cfg.tileImage = pendingTileImage;
    const tOn = document.getElementById('ed-timer-on').checked;
    const tRaw = parseInt(document.getElementById('ed-timer').value, 10);
    state.cfg.timeLimit = !tOn ? 0 : (isNaN(tRaw) ? 20 : clampTimer(tRaw));
    state.cfg.autoAdvance = document.getElementById('ed-auto-advance').checked;
    const siEl2 = document.getElementById('ed-skip-intro');
    if (siEl2) state.cfg.skipIntro = siEl2.checked;
    const smEl2 = document.getElementById('ed-solve-mode');
    if (smEl2) {
      const sel = smEl2.querySelector('.seg-opt.active');
      state.cfg.solveMode = (sel && sel.dataset.val) || 'tv';
    }
    const spEl2 = document.getElementById('ed-sound-pack');
    if (spEl2) state.cfg.soundPack = spEl2.value || 'tv';
    state.cfg.crowdEnabled = document.getElementById('ed-crowd-enabled')?.checked !== false;
    state.cfg.crowdVolume = Math.max(0, Math.min(1, (parseInt(document.getElementById('ed-crowd-volume')?.value, 10) || 0) / 100));
    state.cfg.musicEnabled = document.getElementById('ed-music-enabled')?.checked !== false;
    state.cfg.musicVolume = Math.max(0, Math.min(1, (parseInt(document.getElementById('ed-music-volume')?.value, 10) || 0) / 100));
    showAudio.syncMusicButton();
    const vRaw = parseInt(document.getElementById('ed-vowel-cost').value, 10);
    state.cfg.vowelCost = isNaN(vRaw) ? 250 : Math.max(0, Math.min(2000, vRaw));
    const sRaw = parseInt(document.getElementById('ed-solve-bonus').value, 10);
    state.cfg.solveBonus = isNaN(sRaw) ? 1000 : Math.max(0, Math.min(20000, sRaw));
    state.cfg.shuffle = document.getElementById('ed-shuffle').checked;
    { const mdEl = document.getElementById('ed-max-diff'); state.cfg.maxDiff = mdEl ? mdEl.value : 'all'; }
    const mRaw = parseInt(document.getElementById('ed-max-rounds').value, 10);
    state.cfg.maxRounds = isNaN(mRaw) ? 0 : Math.max(0, Math.min(500, mRaw));
    state.cfg.roundMode = document.getElementById('ed-round-mode').checked;
    const rcRaw = parseInt(document.getElementById('ed-round-count').value, 10);
    state.cfg.roundCount = isNaN(rcRaw) ? 4 : Math.max(1, Math.min(20, rcRaw));
    const multsRaw = (document.getElementById('ed-round-mults').value || '').split(',')
      .map(s => parseFloat(s.trim())).filter(n => isFinite(n) && n > 0);
    state.cfg.roundMultipliers = multsRaw.length ? multsRaw : [1, 1.5, 2];
    state.cfg.tossupEnabled = document.getElementById('ed-tossup-enabled').checked;
    const tvRaw = (document.getElementById('ed-tossup-values').value || '').split(',')
      .map(s => parseInt(s.trim(), 10)).filter(n => isFinite(n) && n > 0);
    state.cfg.tossupValues = tvRaw.length ? tvRaw : [1000, 2000, 3000];
    const tmRaw = parseInt(document.getElementById('ed-tossup-ms').value, 10);
    state.cfg.tossupRevealMs = isNaN(tmRaw) ? 1500 : Math.max(300, Math.min(6000, tmRaw));
    state.cfg.bonusEnabled = document.getElementById('ed-bonus-enabled').checked;
    const bpRaw = parseInt(document.getElementById('ed-bonus-prize').value, 10);
    state.cfg.bonusPrize = isNaN(bpRaw) ? 50000 : Math.max(0, Math.min(1000000, bpRaw));
    const btRaw = parseInt(document.getElementById('ed-bonus-timer').value, 10);
    state.cfg.bonusTimerSeconds = isNaN(btRaw) ? 20 : Math.max(3, Math.min(60, btRaw));
    state.phases = null;
    const checkedCats = collectEnabledCategories();
    const totalCats = document.querySelectorAll('#ed-categories-list input[type="checkbox"]').length;
    // store [] when all categories enabled (or none, which falls back to all)
    state.cfg.enabledCategories = (totalCats > 0 && checkedCats.length > 0 && checkedCats.length < totalCats) ? checkedCats : [];
    state.activePuzzles = null; // rebuild next puzzle load
    const vBtn = document.getElementById('btn-vowel');
    if (vBtn) vBtn.textContent = `Buy Vowel ($${state.cfg.vowelCost})`;
    save();
    applyBackground();
    show('title');
    toast(`Settings saved · ${state.cfg.puzzles.length} puzzles · ${state.cfg.players.length} players`, 'ok');
  }

  function setEditorStatus(text){
    const el = document.getElementById('editor-status');
    el.textContent = text || '';
    el.classList.toggle('show', !!text);
  }

  function parseEditor(){
    const collected = collectPuzzleEditor();
    if (!collected.length) return { error: 'Add at least one puzzle.' };
    const puzzles = [];
    for (let i = 0; i < collected.length; i++){
      const { cat, text, diff, custom } = collected[i];
      if (!cat || !text) return { error: `Puzzle ${i+1} needs both a category and a phrase.` };
      if (!/[A-Z]/.test(text)) return { error: `Puzzle ${i+1} needs at least one letter.` };
      if (text.length > 42) return { error: `Puzzle ${i+1} is long; keep phrases under 42 characters for the board.` };
      puzzles.push({ cat, text, diff: diff || 'med', custom: custom === true });
    }

    const slices = document.getElementById('ed-slices').value.split(',').map(s=>s.trim().toUpperCase()).filter(Boolean);
    if (slices.length < 6) return { error: 'Add at least 6 classic wheel slices.' };
    const allowed = new Set(['BANKRUPT','LOSE','FREE','MYSTERY','WILD','EXPRESS']);
    for (const s of slices) {
      if (!allowed.has(s) && !/^\d+$/.test(s)) return { error: `Classic slice "${s}" must be a number, or one of BANKRUPT, LOSE, FREE, MYSTERY, WILD, EXPRESS.` };
    }

    const party = document.getElementById('ed-party').value.split(',').map(s=>s.trim()).filter(Boolean);
    if (party.length < 2) return { error: 'Add at least 2 party wheel slices.' };
    const longParty = party.find(s => s.length > 24);
    if (longParty) return { error: `Party slice "${longParty}" is too long for the wheel. Keep labels under 24 characters.` };

    const players = collectPlayerEditor();
    if (players.length < 1) return { error: 'Add at least one player.' };
    if (players.length > 6) return { error: 'Use 1 to 6 players so the scoreboard stays readable.' };
    const longPlayer = players.find(p => p.name.length > 14);
    if (longPlayer) return { error: `Player name "${longPlayer.name}" is too long. Keep names under 14 characters.` };

    return { puzzles, slices, party, players };
  }

  /* ---------- GAME OVER ---------- */
  const HELP_CARDS = [
    {icon:'🎡', title:'Spin the Wheel', body:'Press SPIN (or hit Space). The wheel sets the dollar value of your next consonant guess.'},
    {icon:'🔤', title:'Call a Consonant', body:'Click any consonant in the letter bank — or just press its key. Each match earns you the spin value × number of letters.'},
    {icon:'A', title:'Buy a Vowel', body:'Click a vowel directly in the host letter controls. Its configured cost is automatically deducted from the active player.'},
    {icon:'💡', title:'Solve the Puzzle', body:'When you know the answer, hit Solve (or Enter). Correct = bank your full round value. Wrong = turn passes. With one letter left, solve first for full value or call that letter for an automatic half-value finish.'},
    {icon:'🔥', title:'Build a Streak', body:'Three correct consonants in a row earns a 10% bonus. Five in a row = 20%. Wrong guesses reset the streak.'},
    {icon:'🎰', title:'Special Wedges', body:'MYSTERY = risk the round bank for $10,000 or BANKRUPT. WILD = one free consonant call. FREE PLAY = call any letter free without losing the turn on a miss. EXPRESS = continue calling consonants for $1,000 each. BANKRUPT/LOSE = bad luck.'}
  ];
  const PARTY_HELP_CARDS = [
    {icon:'🎉', title:'Party Wheel', body:'Party Wheel is a simple action spinner. It does not use puzzles, scores, vowels, or money wedges.'},
    {icon:'🎡', title:'Spin the Wheel', body:'Press SPIN, hit Space, or press S. The selected action appears below the wheel for the group to follow.'},
    {icon:'✏️', title:'Customize Slices', body:'Use Customize Slices to replace the action labels with your own dares, prizes, chores, icebreakers, or classroom prompts.'}
  ];
  function openHelp(){
    let i = 0;
    const cards = state.mode === 'party' ? PARTY_HELP_CARDS : HELP_CARDS;
    const overlay = document.createElement('div');
    overlay.className = 'help-overlay';
    overlay.innerHTML = `
      <div class="help-card">
        <button class="help-close" aria-label="Close">✕</button>
        <div class="help-icon"></div>
        <h2 class="help-title"></h2>
        <p class="help-body"></p>
        <div class="help-dots"></div>
        <div class="help-nav">
          <button class="btn ghost help-prev">← Prev</button>
          <button class="btn primary help-next">Next →</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    const render = () => {
      const c = cards[i];
      overlay.querySelector('.help-icon').textContent = c.icon;
      overlay.querySelector('.help-title').textContent = c.title;
      overlay.querySelector('.help-body').textContent = c.body;
      overlay.querySelector('.help-dots').innerHTML = cards.map((_,idx) => `<span class="dot${idx===i?' active':''}"></span>`).join('');
      overlay.querySelector('.help-prev').disabled = (i === 0);
      overlay.querySelector('.help-next').textContent = (i === cards.length - 1) ? 'Got it!' : 'Next →';
    };
    let closed = false;
    const onKeydown = e => { if (e.key === 'Escape') close(); };
    const close = () => {
      if (closed) return;
      closed = true;
      document.removeEventListener('keydown', onKeydown);
      overlay.classList.remove('show');
      setTimeout(()=>overlay.remove(), 300);
    };
    overlay.querySelector('.help-close').onclick = close;
    overlay.querySelector('.help-prev').onclick = () => { if (i>0){i--;render();} };
    overlay.querySelector('.help-next').onclick = () => { if (i<cards.length-1){i++;render();} else close(); };
    overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
    document.addEventListener('keydown', onKeydown);
    render();
    requestAnimationFrame(()=>overlay.classList.add('show'));
  }

  function captureMomentPng(){
    const W = 1200, H = 900;
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    const ctx = c.getContext('2d');
    // bg gradient
    const g = ctx.createLinearGradient(0,0,0,H);
    g.addColorStop(0,'#1a1430'); g.addColorStop(1,'#04060f');
    ctx.fillStyle = g; ctx.fillRect(0,0,W,H);
    // gold frame
    ctx.strokeStyle = '#ffd60a'; ctx.lineWidth = 6;
    ctx.strokeRect(28,28,W-56,H-56);
    // header
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffd60a';
    ctx.font = '900 42px Impact, Arial Black, sans-serif';
    ctx.fillText('WHEEL GAME · LIVE', W/2, 86);
    ctx.fillStyle = '#8da4e6';
    ctx.font = '900 14px Inter, Segoe UI, sans-serif';
    const phaseLabel = state.phase
      ? (state.phase.type === 'round' ? `ROUND ${state.phase.num}` : (state.phase.type === 'tossup' ? `TOSS-UP ${state.phase.num}` : 'BONUS ROUND'))
      : 'IN PROGRESS';
    ctx.fillText(phaseLabel + ' · ' + (state.puzzle?.cat || 'PUZZLE'), W/2, 116);
    // puzzle text
    ctx.fillStyle = '#fff';
    ctx.font = '900 56px Impact, Arial Black, sans-serif';
    const display = [...(state.puzzle?.text || '')].map(ch => {
      if (ch === ' ') return '  ';
      if (!/[A-Z]/.test(ch)) return ch;
      return state.revealed.has(ch) ? ch : '_';
    }).join(' ');
    ctx.fillText(display, W/2, 230);
    // separator
    ctx.strokeStyle = 'rgba(255,255,255,.16)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(120,290); ctx.lineTo(W-120,290); ctx.stroke();
    // scoreboard
    ctx.textAlign = 'left';
    ctx.font = '900 26px Inter, Segoe UI, sans-serif';
    (state.cfg.players || []).forEach((p, i) => {
      const y = 360 + i*64;
      const isActive = i === state.activePlayer;
      if (isActive) {
        ctx.fillStyle = 'rgba(255,214,10,.12)';
        ctx.fillRect(110, y-32, W-220, 50);
        ctx.strokeStyle = '#ffd60a';
        ctx.strokeRect(110, y-32, W-220, 50);
      }
      ctx.fillStyle = isActive ? '#fff' : '#aab2d0';
      ctx.fillText((isActive ? '▶ ' : '  ') + p.name, 140, y);
      ctx.textAlign = 'right';
      ctx.fillStyle = p.color || '#ffd60a';
      ctx.font = '900 30px Impact, Arial Black, sans-serif';
      ctx.fillText(`$${(state.totals[i]||0).toLocaleString()}`, W-140, y);
      ctx.font = '700 16px Inter, sans-serif';
      ctx.fillStyle = '#7d89b7';
      ctx.fillText(`bank $${(state.scores[i]||0).toLocaleString()}`, W-140, y+22);
      ctx.textAlign = 'left';
      ctx.font = '900 26px Inter, sans-serif';
    });
    // footer
    ctx.textAlign = 'center';
    ctx.fillStyle = '#5d6fa3';
    ctx.font = '800 16px Inter, sans-serif';
    ctx.fillText('GAMYFY · ' + new Date().toLocaleString(), W/2, H - 60);
    c.toBlob(blob => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `wheel-moment-${Date.now()}.png`;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(()=>URL.revokeObjectURL(url), 1000);
    }, 'image/png');
    // brief feedback
    const tip = document.createElement('div');
    tip.className = 'capture-toast';
    tip.textContent = '📷 Saved!';
    document.body.appendChild(tip);
    requestAnimationFrame(()=>tip.classList.add('show'));
    setTimeout(()=>{tip.classList.remove('show');setTimeout(()=>tip.remove(),300)}, 1500);
  }

  function downloadTrophyCard(){
    const W = 1080, H = 1080;
    const canvas = document.createElement('canvas');
    canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext('2d');
    // background
    const grad = ctx.createLinearGradient(0,0,0,H);
    grad.addColorStop(0,'#1a1430'); grad.addColorStop(1,'#04060f');
    ctx.fillStyle = grad; ctx.fillRect(0,0,W,H);
    // confetti dots
    for (let i=0;i<80;i++){
      ctx.fillStyle = ['#ffd60a','#ff2f7f','#27d9ff','#39d353'][i%4];
      ctx.fillRect(Math.random()*W, Math.random()*H, 6, 10);
    }
    // gold border
    ctx.strokeStyle = '#ffd60a'; ctx.lineWidth = 8;
    ctx.strokeRect(40,40,W-80,H-80);
    // title
    ctx.fillStyle = '#ffd60a';
    ctx.textAlign = 'center';
    ctx.font = '900 56px Impact, Arial Black, sans-serif';
    ctx.fillText('🏆 CHAMPION 🏆', W/2, 160);
    // game name
    ctx.fillStyle = '#8da4e6';
    ctx.font = '900 22px Inter, Segoe UI, sans-serif';
    const date = new Date().toLocaleDateString();
    ctx.fillText('WHEEL GAME · ' + date.toUpperCase(), W/2, 210);
    // winner section
    const sorted = state.cfg.players.map((p,i)=>({...p,total:state.totals[i]||0})).sort((a,b)=>b.total-a.total);
    const winner = sorted[0];
    ctx.fillStyle = '#fff';
    ctx.font = '900 110px Impact, Arial Black, sans-serif';
    ctx.fillText(winner.name.toUpperCase(), W/2, 360);
    ctx.fillStyle = winner.color || '#ffd60a';
    ctx.font = '900 80px Impact, Arial Black, sans-serif';
    ctx.fillText('$' + winner.total.toLocaleString(), W/2, 460);
    // separator
    ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(180,520); ctx.lineTo(W-180,520); ctx.stroke();
    // leaderboard
    ctx.textAlign = 'left';
    ctx.font = '900 36px Inter, Segoe UI, sans-serif';
    sorted.forEach((p, i) => {
      const y = 600 + i*72;
      ctx.fillStyle = i === 0 ? '#ffd60a' : '#aab2d0';
      ctx.fillText(`#${i+1}`, 180, y);
      ctx.fillStyle = '#fff';
      ctx.fillText(p.name, 280, y);
      ctx.textAlign = 'right';
      ctx.fillStyle = p.color || '#aab2d0';
      ctx.fillText('$' + p.total.toLocaleString(), W - 180, y);
      ctx.textAlign = 'left';
    });
    // footer
    ctx.textAlign = 'center';
    ctx.fillStyle = '#5d6fa3';
    ctx.font = '800 18px Inter, sans-serif';
    ctx.fillText('GAMYFY · INTERACTIVE WHEEL GAME', W/2, H - 80);
    // download
    canvas.toBlob(blob => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `wheel-champion-${winner.name.replace(/\s+/g,'_')}-${Date.now()}.png`;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(()=>URL.revokeObjectURL(url), 1000);
    }, 'image/png');
  }

  function showGameOver(){
    const el = document.getElementById('gameover');
    if (!el) return;
    stopAllGameTimers();   // ensure no countdown keeps running behind the results
    recordLeaderboard();

    const players = state.cfg.players.map((p, i) => ({
      i, name: p.name, color: p.color, avatar: p.avatar,
      total: state.totals[i] || 0
    }));
    const sorted = players.slice().sort((a, b) => b.total - a.total);
    // A sudden-death tiebreaker winner takes the #1 slot even though totals are equal.
    if (typeof state.forcedWinner === 'number') {
      const fwIdx = sorted.findIndex(p => p.i === state.forcedWinner);
      if (fwIdx > 0) { const [w] = sorted.splice(fwIdx, 1); sorted.unshift(w); }
    }
    const winner = sorted[0];
    document.getElementById('gameover-avatar').innerHTML = avatarHtml(winner.avatar || '⭐');
    document.getElementById('gameover-avatar').style.borderColor = winner.color || '#ffd60a';
    const joint = typeof state.forcedWinner !== 'number' && sorted.filter(p => p.total === winner.total).length > 1;
    const winnerName = joint ? 'Shared winners: ' + sorted.filter(p => p.total === winner.total).map(p => p.name).join(' & ') : winner.name;
    document.getElementById('gameover-name').textContent = winnerName;
    const prizeEl = document.getElementById('gameover-prize');
    prizeEl.textContent = '$0';
    const board = document.getElementById('gameover-board');
    board.innerHTML = '';
    sorted.forEach((p, rank) => {
      const row = document.createElement('div');
      row.className = 'gameover-row' + (rank === 0 || (joint && p.total === winner.total) ? ' is-winner' : '');
      const r = document.createElement('div'); r.className = 'gameover-rank'; r.textContent = '#' + (joint && p.total === winner.total ? 1 : rank + 1);
      const a = document.createElement('div'); a.className = 'row-avatar'; a.innerHTML = avatarHtml(p.avatar || '⭐');
      const n = document.createElement('div'); n.className = 'row-name'; n.textContent = p.name;
      const t = document.createElement('div'); t.className = 'row-total'; t.textContent = '$0'; t.dataset.target = String(p.total);
      row.append(r, a, n, t);
      board.appendChild(row);
    });
    el.classList.add('show');
    el.setAttribute('aria-hidden', 'false');
    confettiBurst();
    setTimeout(()=>confettiBurst(), 500);
    setTimeout(()=>confettiBurst(), 1000);
    sfx.fanfare();
    showAudio.playVictory();
    setTimeout(()=>sfx.applause(), 350);
    publishAudienceSpin('audience-gameover', { winnerName, winnerTotal:winner.total, winnerColor:winner.color || '#ffd60a', winnerAvatar:winner.avatar || '⭐', winnerMessage:state.cfg.winnerMessage || '' });
    animateGameOverTotals(prizeEl, winner.total, board);
    const finishedEpoch=state.epoch;
    setTimeout(()=>{
      if(state.epoch!==finishedEpoch)return;
      const rows=getTop25(),joinUrl=buzzerAvailable()?window.WheelBuzzer.getPoolState().url:'';
      publishAudienceSpin('audience-gameover-clear');
      publishAudienceSpin('audience-leaderboard',{rows,joinUrl});
      state.leaderboardShowing=true;
      syncLeaderboardButtons();
    },9000);
    clearSavedGame();
  }

  function animateGameOverTotals(prizeEl, prizeTarget, board){
    const dur = 1400;
    const ease = t => 1 - Math.pow(1 - t, 3);
    const fmt = n => '$' + Math.round(n).toLocaleString();
    const rows = [...board.querySelectorAll('.row-total')];
    // Pre-paint the final values so a throttled/paused tab still shows the right number.
    const setFinal = () => {
      prizeEl.textContent = fmt(prizeTarget);
      rows.forEach(r => { r.textContent = fmt(Number(r.dataset.target) || 0); });
    };
    const start = performance.now();
    let done = false;
    function tick(now){
      if (done) return;
      const p = Math.min(1, (now - start) / dur);
      const e = ease(p);
      prizeEl.textContent = fmt(prizeTarget * e);
      rows.forEach(r => {
        const target = Number(r.dataset.target) || 0;
        r.textContent = fmt(target * e);
      });
      if (p < 1) requestAnimationFrame(tick);
      else { done = true; setFinal(); }
    }
    requestAnimationFrame(tick);
    // Fallback: if rAF doesn't fire (hidden tab / very low-power) snap to final after dur+200ms.
    setTimeout(() => { if (!done) { done = true; setFinal(); } }, dur + 200);
  }

  function hideGameOver(){
    const el = document.getElementById('gameover');
    if (!el) return;
    el.classList.remove('show');
    el.setAttribute('aria-hidden', 'true');
    publishAudienceSpin('audience-gameover-clear');
  }

  /* ---------- TOAST ---------- */
  function toast(msg, kind='ok', ms=2800){
    const wrap = document.getElementById('toasts');
    if (!wrap) return;
    const el = document.createElement('div');
    el.className = `toast toast-${kind}`;
    const icons = { ok:'✓', err:'⚠', info:'ℹ' };
    el.innerHTML = `<span class="toast-icon">${icons[kind]||''}</span><span class="toast-msg"></span>`;
    el.querySelector('.toast-msg').textContent = msg;
    wrap.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => {
      el.classList.remove('show');
      setTimeout(() => el.remove(), 280);
    }, ms);
  }

  /* ---------- IMPORT / EXPORT ---------- */
  function exportConfig(){
    try {
      const data = JSON.stringify(state.cfg, null, 2);
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const stamp = new Date().toISOString().slice(0,10);
      a.href = url;
      a.download = `spin-solve-config-${stamp}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setEditorStatus('Config exported.');
      toast(`Exported "${a.download}"`, 'ok');
    } catch(e){
      const m = 'Export failed: ' + (e?.message || 'unknown error');
      setEditorStatus(m);
      toast(m, 'err');
    }
  }

  function validateImportedCfg(obj){
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return 'File is not a valid config object.';
    for (const key of ['puzzles','slices','party','players']) {
      if (key in obj && (!Array.isArray(obj[key]) || !obj[key].length)) return key + ' must be a nonempty array.';
    }
    if (obj.players && (obj.players.length < 1 || obj.players.length > 6 || obj.players.some(p => !p || (typeof p !== 'string' && typeof p.name !== 'string')))) return 'Use 1–6 named players.';
    if (obj.slices && obj.slices.some(x => typeof x !== 'string' || !(/^(BANKRUPT|LOSE|FREE|MYSTERY|WILD|EXPRESS)$/.test(x) || (/^\d+$/.test(x) && Number(x)>0 && Number(x)<=1e6)))) return 'Use positive money values or supported special wedges.';
    if (obj.party && obj.party.some(x => typeof x !== 'string' || !x.trim())) return 'Party wedges need text.';
    for (const key of ['vowelCost','solveBonus','bonusPrize','maxRounds','roundCount','timeLimit','bonusTimerSeconds','tossupRevealMs']) {
      if (key in obj && (typeof obj[key] !== 'number' || !Number.isFinite(obj[key]) || obj[key]<0 || obj[key]>1e6)) return 'Invalid ' + key + '.';
    }
    for (const key of ['roundMultipliers','tossupValues']) if (key in obj && (!Array.isArray(obj[key]) || !obj[key].length || obj[key].some(n => typeof n !== 'number' || !Number.isFinite(n) || n <= 0 || n > 1e6))) return 'Invalid ' + key + '.';
    if (obj.puzzles && !Array.isArray(obj.puzzles)) return '"puzzles" must be an array.';
    if (obj.slices && !Array.isArray(obj.slices)) return '"slices" must be an array.';
    if (obj.party && !Array.isArray(obj.party)) return '"party" must be an array.';
    if (obj.players && !Array.isArray(obj.players)) return '"players" must be an array.';
    if (Array.isArray(obj.puzzles)) {
      for (const p of obj.puzzles) {
        if (!p || typeof p.cat !== 'string' || typeof p.text !== 'string' || !/[A-Za-z]/.test(p.text) || p.text.length > 42) return 'Every puzzle needs cat and text strings.';
      }
    }
    return null;
  }

  async function importConfig(file){
    if (!file) return;
    if (!/\.json$/i.test(file.name) && file.type !== 'application/json'){
      setEditorStatus('Pick a .json file exported from this game.');
      return;
    }
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const err = validateImportedCfg(parsed);
      if (err) { setEditorStatus('Import failed: ' + err); return; }
      const ok = await openModal({
        title: 'Replace settings?',
        copy: 'This will overwrite your current puzzles, players, slices, and game rules with the imported file. Continue?',
        input: false,
        confirmText: 'Replace'
      });
      if (!ok) { setEditorStatus('Import cancelled.'); return; }
      const merged = Object.assign({}, defaults, parsed);
      // Normalize difficulty so imported puzzles tier correctly and the editor
      // dropdowns reflect the true tier (handles casing/shorthand/missing diff).
      if (Array.isArray(merged.puzzles)) {
        merged.puzzles = merged.puzzles.map(p => Object.assign({}, p, { custom:true, diff: normDiff(p.diff), text: p.text.trim().toUpperCase().replace(/\s+/g, ' '), cat: p.cat.trim().toUpperCase() }));
      }
      merged.players = normalizePlayers(merged.players);
      state.cfg = merged;
      state.activePuzzles = null;
      save();
      openEditor();
      setEditorStatus(`Imported "${file.name}".`);
      toast(`Imported "${file.name}"`, 'ok');
    } catch(e){
      const m = 'Import failed: ' + (e?.message || 'could not parse JSON');
      setEditorStatus(m);
      toast(m, 'err', 4000);
    }
  }

  async function resetEditorDefaults(){
    const ok = await openModal({
      title: 'Restore Defaults?',
      copy: 'This replaces the editor fields with the starter puzzles, slices, and players.',
      input: false,
      confirmText: 'Restore'
    });
    if (!ok) return;
    state.cfg = JSON.parse(JSON.stringify(defaults));
    state.cfg.players = normalizePlayers(state.cfg.players);
    state.activePuzzles = null;
    save();
    openEditor();
    setEditorStatus('Defaults restored.');
    toast('Defaults restored', 'ok');
  }

  const SAVE_KEY = 'spinSolveGame';
  function saveGame(){
    try {
      if (!state.cfg) return;
      const snap = {
        v: 2,
        duel: state.phase?.type === 'bonus' && state.duelRecovery ? {...state.duelRecovery, puzzle:state.puzzle, queue:[...(state.tossupQueue || [])], lockout:[...(state.tossupLockout || [])]} : null,
        fingerprint: JSON.stringify(state.cfg),
        ts: Date.now(),
        mode: state.mode,
        puzzleIdx: state.puzzleIdx,
        scores: state.scores,
        totals: state.totals,
        activePlayer: state.activePlayer,
        revealed: [...(state.revealed||[])],
        used: [...(state.used||[])],
        streaks: state.streaks,
        // Mid-turn advantages so closing the tab never silently removes them.
        wildCards: state.wildCards || null,
        hintsUsed: state.hintsUsed || null,
        pendingDouble: !!state.pendingDouble,
        freePlay: !!state.freePlay,
        spinValue: (state.spinValue != null ? state.spinValue : null),
        canGuess: !!state.canGuess,
        roundOver: !!state.roundOver,
        tossupWinner: state.tossupWinner,
        // Persist the exact drawn set so a shuffled game restores identically.
        activePuzzles: state.activePuzzles || null,
        // light cfg fingerprint so a totally different puzzle set doesn't restore wrong
        puzCount: (state.cfg.puzzles||[]).length,
        playerCount: (state.cfg.players||[]).length,
        roundMode: !!state.cfg.roundMode,
      };
      storageSet(SAVE_KEY, JSON.stringify(snap));
    } catch(e){}
  }
  function loadGame(){
    try {
      const raw = storageGet(SAVE_KEY);
      if (!raw) return null;
      const s = JSON.parse(raw);
      if (!s || s.v !== 2 || s.fingerprint !== JSON.stringify(state.cfg)) return null;
      const n = state.cfg.players.length;
      const amounts = a => Array.isArray(a) && a.length === n && a.every(v => Number.isFinite(v) && v >= 0);
      if (!amounts(s.scores) || !amounts(s.totals) || !amounts(s.streaks)) return null;
      if (!Number.isInteger(s.activePlayer) || s.activePlayer < 0 || s.activePlayer >= n) return null;
      if (!Array.isArray(s.activePuzzles) || !s.activePuzzles.length || validateImportedCfg({puzzles:s.activePuzzles})) return null;
      if (!Number.isInteger(s.puzzleIdx) || s.puzzleIdx < 0 || s.puzzleIdx >= s.activePuzzles.length) return null;
      for (const key of ['used','revealed']) if (!Array.isArray(s[key]) || s[key].some(ch => typeof ch !== 'string' || !/^[A-Z]$/.test(ch))) return null;
      if (s.wildCards && !amounts(s.wildCards)) return null;
      if (s.hintsUsed && (!Array.isArray(s.hintsUsed) || s.hintsUsed.length !== n || s.hintsUsed.some(v => typeof v !== 'boolean'))) return null;
      if (s.spinValue !== null && (!Number.isFinite(s.spinValue) || s.spinValue < 0)) return null;
      if (!Number.isFinite(s.ts) || s.ts > Date.now()+60000 || s.mode !== 'classic') return null;
      if (s.duel && !validDuelSave(s.duel, n)) return null;
      // expire after 24h
      if (Date.now() - (s.ts||0) > 24*60*60*1000) return null;
      // fingerprint check
      if (s.puzCount !== (state.cfg.puzzles||[]).length) return null;
      if (s.playerCount !== (state.cfg.players||[]).length) return null;
      if (s.roundMode !== !!state.cfg.roundMode) return null;
      return s;
    } catch(e){ return null; }
  }
  function validDuelSave(d, n){
    const seats = a => Array.isArray(a) && a.length <= n && new Set(a).size === a.length && a.every(i => Number.isInteger(i) && i >= 0 && i < n);
    const letters = a => Array.isArray(a) && a.length <= 26 && new Set(a).size === a.length && a.every(c => typeof c === 'string' && /^[A-Z]$/.test(c));
    if (!d || !d.puzzle || validateImportedCfg({puzzles:[d.puzzle]}) || !letters(d.queue) || !seats(d.lockout)) return false;
    if (d.kind === 'bonus') return seats(d.finalists) && d.finalists.length === 2;
    if (d.kind !== 'qualifier' || !seats(d.group) || !seats(d.won) || !seats(d.seated) || !Number.isInteger(d.need) || d.need < 1 || d.need > 2 || d.won.length > d.need) return false;
    return seats([...d.group,...d.won,...d.seated]) && d.need + d.seated.length === 2 && d.group.length + d.won.length >= d.need;
  }
  function restoreDuel(d, opts){
    const advance = winners => startBonusDuel([...d.seated, ...winners].slice(0,2));
    if (d.kind === 'qualifier' && d.advance) {
      runQualifier(d.group.slice(), d.need, d.won.slice(), advance, null, d.seated.slice());
      return;
    }
    if (d.kind === 'qualifier') runQualifier(d.group.slice(), d.need, d.won.slice(), advance, d, d.seated.slice());
    else startBonusDuel(d.finalists.slice(), d);
    stopTossupReveal();
    state.revealed = new Set(opts.restoredRevealed || []);
    state.used = new Set(opts.restoredUsed || []);
    state.tossupQueue = d.queue.filter(c => !state.revealed.has(c));
    state.tossupLockout = new Set(d.lockout);
    state.tossupStarted = false;
    state.roundOver = !!opts.restoredRoundOver;
    if (state.roundOver) state.bonusDuelActive = false;
    renderPuzzle(); renderBank(); applyPhaseUI(state.phase);
    msg(state.roundOver ? 'Bonus complete. Press → to see the final result.' : 'Bonus progress restored. Reconnect phones, then click Start Toss-Up when everyone is ready.');
    saveGame();
  }
  function clearSavedGame(){ storageRemove(SAVE_KEY); }

  /* ---------- HOST TOOLS: single-level undo, skip, score adjust ---------- */
  let _undoSnap = null;
  // Capture the game state right BEFORE a turn-changing action so the host can revert
  // a mis-tap (wrong solver, wrong wedge, wrong letter) without nuking the round bank.
  function captureUndo(label){
    if (state.mode !== 'classic') return;
    try {
      _undoSnap = {
        label: label || 'last action',
        puzzleIdx: state.puzzleIdx,
        puzzle: state.puzzle,                       // reference is fine (puzzles aren't mutated)
        phase: state.phase ? Object.assign({}, state.phase) : null,
        scores: (state.scores || []).slice(),
        totals: (state.totals || []).slice(),
        streaks: (state.streaks || []).slice(),
        activePlayer: state.activePlayer,
        revealed: [...(state.revealed || [])],
        used: [...(state.used || [])],
        wildCards: state.wildCards ? state.wildCards.slice() : null,
        hintsUsed: state.hintsUsed ? state.hintsUsed.slice() : null,
        pendingDouble: !!state.pendingDouble,
        freePlay: !!state.freePlay,
        spinValue: state.spinValue,
        canGuess: !!state.canGuess,
        roundOver: !!state.roundOver,
        tossupStarted: !!state.tossupStarted,
        tossupLockout: [...(state.tossupLockout || [])],
      };
      updateUndoButton();
    } catch (e) {}
  }
  function undoLast(){
    if (!_undoSnap) { msg('Nothing to undo yet.'); sfx.wrong(); return; }
    const s = _undoSnap; _undoSnap = null;
    if (typeof stopAllGameTimers === 'function') stopAllGameTimers();
    if (state.advanceHandle) { clearInterval(state.advanceHandle); state.advanceHandle = null; }
    forceCloseModal();
    // Scores/totals/streaks aren't touched by loadPuzzle — restore them first.
    state.scores = s.scores.slice();
    state.totals = s.totals.slice();
    state.streaks = s.streaks.slice();
    state.activePlayer = s.activePlayer;
    if (s.wildCards) state.wildCards = s.wildCards.slice();
    // Rebuild the puzzle's meta (category, topbar, phase frame) via the normal path.
    loadPuzzle(s.puzzleIdx);
    state.scores = s.scores.slice();
    const phaseType = (state.phase && state.phase.type) || 'round';
    if (phaseType === 'round' || phaseType === 'bonus') {
      // Restore mid-puzzle progress that loadPuzzle just cleared.
      state.revealed = new Set(s.revealed);
      state.used = new Set(s.used);
      if (s.hintsUsed) state.hintsUsed = s.hintsUsed.slice();
      state.pendingDouble = s.pendingDouble;
      state.freePlay = s.freePlay;
      state.spinValue = s.spinValue;
      state.canGuess = s.canGuess;
      state.roundOver = s.roundOver;
    }
    // (For toss-up / tiebreak we leave loadPuzzle's clean re-init so the host can replay it.)
    state.activePlayer = s.activePlayer;
    state.solveLocked = false;
    renderPuzzle();
    renderScore();
    if (typeof renderBank === 'function') renderBank();
    applyPhaseUI(state.phase || currentPhase());
    updateHintButton();
    renderActivePlayerCard();
    scheduleClassicFit();
    saveGame();
    msg(`Undid ${s.label}.`);
    if (sfx && sfx.click) sfx.click();
    updateUndoButton();
  }
  function updateUndoButton(){
    const b = document.getElementById('btn-undo');
    if (!b) return;
    b.disabled = !_undoSnap;
    b.textContent = _undoSnap ? `↶ Undo: ${_undoSnap.label}` : '↶ Undo (nothing yet)';
  }

  function skipPuzzle(){
    if (state.mode !== 'classic') return;
    const list = (state.activePuzzles && state.activePuzzles.length) ? state.activePuzzles : state.cfg.puzzles;
    if (typeof stopAllGameTimers === 'function') stopAllGameTimers();
    if (state.advanceHandle) { clearInterval(state.advanceHandle); state.advanceHandle = null; }
    if ((state.puzzleIdx + 1) >= list.length) { msg('Last puzzle — ending the game.'); setTimeout(endOrTiebreak, 600); return; }
    captureUndo('skip puzzle');
    loadPuzzle(state.puzzleIdx + 1);
    msg('Skipped to the next puzzle — no points awarded.');
  }

  async function adjustPlayerBank(i){
    const p = state.cfg.players[i]; if (!p) return;
    const cur = state.scores[i] || 0;
    const val = await openModal({
      title: `Adjust ${p.name}'s round bank`,
      copy: 'Host correction — set this player’s current round-bank amount.',
      placeholder: 'e.g. 2500',
      value: String(cur),
      confirmText: 'Set',
      validate: v => (v === '' || !Number.isFinite(Number(v)) || Math.abs(Number(v)) > 1e9) ? 'Enter a finite amount up to 1 billion.' : ''
    });
    if (val === null || val === undefined || val === '') return;
    captureUndo('score adjust');
    state.scores[i] = Math.max(0, Math.round(Number(val)));
    renderScore();
    msg(`${p.name}'s round bank set to $${state.scores[i].toLocaleString()}.`);
  }
  function restoreGame(snap){
    state.mode = snap.mode || 'classic';
    state.scores = snap.scores || state.cfg.players.map(()=>0);
    state.totals = snap.totals || state.cfg.players.map(()=>0);
    state.streaks = snap.streaks || state.cfg.players.map(()=>0);
    state.activePlayer = snap.activePlayer || 0;
    state.tossupWinner = Number.isInteger(snap.tossupWinner) ? snap.tossupWinner : null;
    if (state.mode === 'classic') startClassic({restoredScores: snap.scores, restoredIdx: snap.puzzleIdx, restoredRevealed: snap.revealed, restoredUsed: snap.used, restoredPuzzles: snap.activePuzzles, restoredWilds: snap.wildCards, restoredHints: snap.hintsUsed, restoredDouble: snap.pendingDouble, restoredFreePlay: snap.freePlay, restoredSpinValue: snap.spinValue, restoredCanGuess: snap.canGuess, restoredRoundOver: snap.roundOver, restoredDuel: snap.duel});
    else { buildActivePuzzles(); startParty(); }
  }
  async function offerResumeIfAny(){
    const snap = loadGame();
    if (!snap) return false;
    const ok = await openModal({
      title: 'Resume previous game?',
      copy: `Saved ${Math.round((Date.now() - snap.ts)/60000)} min ago. Scores, letters and turn advantages return. Bonus and qualifier reveals resume when you click Start Toss-Up. Reconnect phones after reopening.`,
      input: false,
      confirmText: 'Resume',
      cancelText: 'New Game'
    });
    if (ok) { restoreGame(snap); return true; }
    clearSavedGame();
    return false;
  }

  function applyUrlModes(){
    const p = new URLSearchParams(location.search);
    if (p.get('mode') === 'tv' || p.has('tv')) document.documentElement.classList.add('tv-mode');
    if (p.get('debug') === '1' || p.has('debug')) setTimeout(buildDebugPanel, 50);
    if (p.has('nofit')) fitToScreen._disabled = true; // escape hatch
  }

  /* ---------- SCALE-UP FOR BIG TVs ONLY ----------
   * The classic layout is genuinely fluid (the stage flex-fills the viewport and
   * the wheel/board/keyboard use vh/vw sizing), so it fills laptops and normal
   * monitors of ANY aspect ratio with no gaps and no clipping. We therefore leave
   * those alone. We ONLY engage the fixed-box transform to scale the design UP on
   * very large 4K-class displays, where the fluid size caps would otherwise leave
   * the content small. (4K/large TVs are 16:9, so the scale-up fills cleanly.)
   * tv-mode opts out; ?nofit disables entirely. */
  function fitToScreen(){
    const de = document.documentElement;
    const app = document.getElementById('app');
    if (!app) return;
    if (fitToScreen._disabled || de.classList.contains('tv-mode')) {
      de.classList.remove('fit-screen'); app.style.transform = ''; return;
    }
    const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
    // Only step in for genuinely large displays (~2880×1620 and up). Everything
    // smaller — laptops, 1080p/1200p monitors, 1440p — uses the native fluid fill.
    if (scale >= 1.5) {
      de.classList.add('fit-screen');
      app.style.transform = `translate(-50%,-50%) scale(${Math.min(scale, 3)})`;
    } else {
      de.classList.remove('fit-screen');
      app.style.transform = '';
    }
    fitClassicStage();
  }

  /* Gameplay must fill the screen with NO scrollbar and NO cropping. The classic
   * stage content (which grows taller in toss-up/bonus phases, and on shorter
   * screens) is scaled down uniformly to fit its available box and vertically
   * centered — so the phase banner, puzzle board, letter bank, action buttons and
   * player cards are always fully visible, from a small laptop up to an 80" 4K TV. */
  function fitClassicStage(){
    const screen = document.getElementById('screen-classic');
    if (!screen || !screen.classList.contains('active')) return;
    const stage = screen.querySelector('.stage');
    const sb = screen.querySelector('.scoreboard');
    if (!stage) return;
    // V4.4 uses a bounded CSS grid with real rows for the board, controls and
    // scoreboard. Never transform-scale this grid: the prior measurement pass
    // could calculate against a fixed side rail and crush the remaining content
    // into a horizontal sliver on common laptop/TV resolutions.
    stage.style.transform = 'none';
    stage.style.transformOrigin = '';
    stage.querySelectorAll('.wheel-col,.play-rail').forEach(el => { el.style.transform = 'none'; });
    return;
    if (window.innerWidth <= 900) {
      stage.style.transform = 'none';
      stage.querySelectorAll('.wheel-col,.play-rail').forEach(el => el.style.transform = 'none');
      return;
    }
    // Reset, then measure in viewport coords (robust for grid/overflow, unlike scrollHeight).
    stage.style.transform = 'none';
    // Vertically align the left (wheel/turn) and right (letters/actions) rails to the
    // board's center. The category banner above the board offsets simple track-centering,
    // and which column is tallest flips the sign — so measure and correct it exactly here.
    const board = stage.querySelector('.puzzle-board');
    const rails = [stage.querySelector('.wheel-col'), stage.querySelector('.play-rail')];
    rails.forEach(r => { if (r) r.style.transform = 'none'; });
    const stageTop = stage.getBoundingClientRect().top;
    if (board) {
      const bb = board.getBoundingClientRect();
      const boardMid = bb.top + bb.height / 2;
      rails.forEach(r => {
        if (!r) return;
        const rb = r.getBoundingClientRect();
        let dy = Math.round(boardMid - (rb.top + rb.height / 2));
        // A rail taller than the board (e.g. the full letter bank) would, when
        // centered on the board's midpoint, push its top above the stage — which
        // is overflow:hidden, so the top "Called Letters" consonant row gets cropped.
        // The letter bank's "Called Letters" pill is a ::before pinned above the
        // bank's edge, so the rail's visible top sits a little above its border box;
        // clamp against that real top so neither the badge nor the first row clip.
        let topMost = rb.top;
        const bank = r.querySelector('.letter-bank');
        if (bank) {
          const overhang = parseFloat(getComputedStyle(bank, '::before').top);
          if (!isNaN(overhang) && overhang < 0) topMost = bank.getBoundingClientRect().top + overhang;
        }
        const minDy = stageTop - topMost;
        if (dy < minDy) dy = minDy;
        if (dy) r.style.transform = `translateY(${dy}px)`;
      });
    }
    const limit = sb ? sb.getBoundingClientRect().top : window.innerHeight;
    let deepest = stageTop;
    for (const col of stage.children) {
      const b = col.getBoundingClientRect().bottom;
      if (b > deepest) deepest = b;
    }
    const content = deepest - stageTop;       // natural height of the tallest column
    const avail = limit - stageTop;            // space between stage top and scoreboard
    if (avail <= 0 || content <= 0) return;
    // Reserve a little breathing room top and bottom so the content never butts up
    // against the header (where the round/timer badge lives) or the scoreboard. We
    // scale to the reduced box and then center, which lowers the top row (wheel,
    // category banner, letter bank) a touch below the header instead of pinning it
    // to the very edge — the gap shrinks gracefully on the tightest screens.
    const GAP = Math.min(16, Math.round(avail * 0.04));
    const fitAvail = Math.max(40, avail - GAP * 2);
    let s = content > fitAvail ? Math.max(0.5, fitAvail / content) : 1;
    s = Math.floor(s * 1000) / 1000;           // avoid sub-pixel residue re-clipping
    const ty = Math.max(GAP, Math.round((avail - content * s) / 2));  // vertical centering with a top gap
    stage.style.transformOrigin = 'top center';
    stage.style.transform = `translateY(${ty}px) scale(${s})`;
  }
  // Fit immediately and again after the phase-banner/board entrance animations
  // (~0.45s) settle, so late layout changes can't leave content cropped.
  // fitClassicStage is idempotent, so repeating is safe.
  function scheduleClassicFit(){
    requestAnimationFrame(() => requestAnimationFrame(fitClassicStage));
    setTimeout(fitClassicStage, 160);
    setTimeout(fitClassicStage, 480);
  }
  let _fitTimer = null;
  function scheduleFit(){
    if (_fitTimer) clearTimeout(_fitTimer);
    _fitTimer = setTimeout(() => { _fitTimer = null; fitToScreen(); }, 80);
  }

  function buildDebugPanel(){
    if (document.getElementById('debug-panel')) return;
    const panel = document.createElement('div');
    panel.id = 'debug-panel';
    panel.className = 'debug-panel';
    panel.innerHTML = `
      <div class="dbg-head">
        <strong>UI / Audio Audit</strong>
        <span class="dbg-hint">Click any button. Audio needs one user click first.</span>
        <button class="dbg-x" id="dbg-close">✕</button>
      </div>
      <div class="dbg-row">
        <div class="dbg-group">
          <div class="dbg-label">Sound pack</div>
          <select id="dbg-pack">
            <option value="tv">Classic TV</option>
            <option value="casino">Vegas Casino</option>
            <option value="arcade">Arcade</option>
          </select>
        </div>
        <div class="dbg-group">
          <div class="dbg-label">Run every sound (3s)</div>
          <button class="dbg-btn" data-act="play-all">▶ Play all sfx</button>
        </div>
      </div>
      <div class="dbg-grid">
        <button class="dbg-btn" data-sfx="cha">💰 cha (money)</button>
        <button class="dbg-btn" data-sfx="chime">🔔 chime (letter)</button>
        <button class="dbg-btn" data-sfx="correct">✓ correct</button>
        <button class="dbg-btn" data-sfx="wrong">✗ wrong</button>
        <button class="dbg-btn" data-sfx="vowel">A vowel</button>
        <button class="dbg-btn" data-sfx="free">⭐ free</button>
        <button class="dbg-btn" data-sfx="lose">↓ lose</button>
        <button class="dbg-btn" data-sfx="solve">🎉 solve</button>
        <button class="dbg-btn" data-sfx="applause">👏 applause</button>
        <button class="dbg-btn" data-sfx="buzzer">🚨 buzzer</button>
        <button class="dbg-btn" data-sfx="bankrupt">💀 bankrupt</button>
        <button class="dbg-btn" data-sfx="fanfare">🏆 fanfare</button>
      </div>
      <div class="dbg-section">Visual moments</div>
      <div class="dbg-grid">
        <button class="dbg-btn" data-fx="reveal-money">Reveal $650</button>
        <button class="dbg-btn" data-fx="reveal-bankrupt">Reveal BANKRUPT + shake</button>
        <button class="dbg-btn" data-fx="reveal-lose">Reveal LOSE A TURN</button>
        <button class="dbg-btn" data-fx="reveal-free">Reveal FREE PLAY</button>
        <button class="dbg-btn" data-fx="reveal-solve">Reveal SOLVED!</button>
        <button class="dbg-btn" data-fx="money-burst">Money coin burst</button>
        <button class="dbg-btn" data-fx="confetti">Confetti burst</button>
        <button class="dbg-btn" data-fx="crown">Crown winner (P1)</button>
        <button class="dbg-btn" data-fx="theme">Cycle theme + banner</button>
        <button class="dbg-btn" data-fx="land-money">Wheel ring pulse (money)</button>
        <button class="dbg-btn" data-fx="land-bad">Wheel ring pulse (bad)</button>
        <button class="dbg-btn" data-fx="bonus-reveal">Bonus letter reveal (RSTLE)</button>
      </div>
      <div class="dbg-section">Flows</div>
      <div class="dbg-grid">
        <button class="dbg-btn" data-flow="gameover">Open Champion screen</button>
        <button class="dbg-btn" data-flow="trophy">Download trophy PNG now</button>
        <button class="dbg-btn" data-flow="tv">Toggle TV mode</button>
        <button class="dbg-btn" data-flow="editor">Open Editor</button>
      </div>
      <div id="dbg-log" class="dbg-log"></div>
    `;
    document.body.appendChild(panel);

    const log = (m) => {
      const el = document.getElementById('dbg-log');
      const line = document.createElement('div');
      line.textContent = '› ' + m;
      el.appendChild(line);
      el.scrollTop = el.scrollHeight;
    };

    document.getElementById('dbg-close').onclick = () => panel.remove();
    document.getElementById('dbg-pack').value = state.cfg.soundPack || 'tv';
    document.getElementById('dbg-pack').onchange = (e) => {
      state.cfg.soundPack = e.target.value;
      save();
      log('Sound pack → ' + e.target.value);
    };

    panel.addEventListener('click', async (e) => {
      const sfxKey = e.target.dataset.sfx;
      const fxKey = e.target.dataset.fx;
      const act = e.target.dataset.act;
      const flow = e.target.dataset.flow;

      if (sfxKey) {
        ensureAudio();
        if (sfx[sfxKey]) { sfx[sfxKey](); log('▶ sfx.' + sfxKey); }
        else log('Missing sfx: ' + sfxKey);
      }
      if (act === 'play-all') {
        ensureAudio();
        const order = ['cha','chime','correct','vowel','free','wrong','lose','bankrupt','solve','applause','buzzer','fanfare'];
        for (const k of order) {
          log('▶ ' + k);
          if (sfx[k]) sfx[k]();
          await new Promise(r => setTimeout(r, 900));
        }
        log('All sfx complete.');
      }
      if (fxKey === 'reveal-money')    showReveal('$650','money','per consonant',1500);
      if (fxKey === 'reveal-bankrupt'){showReveal('BANKRUPT','bankrupt','round bank cleared',2000);shakeScreen();}
      if (fxKey === 'reveal-lose')     showReveal('LOSE A TURN','lose','',1600);
      if (fxKey === 'reveal-free')     showReveal('FREE PLAY','free','no penalty',1800);
      if (fxKey === 'reveal-solve')    showReveal('SOLVED!','solve','demo winner',2000);
      if (fxKey === 'money-burst')     moneyBurst(document.querySelector('.wheel-wrap'));
      if (fxKey === 'confetti')        confettiBurst();
      if (fxKey === 'crown') {
        if (document.querySelector('.screen.active')?.id !== 'screen-classic') {
          log('Switch to Classic first so the scoreboard exists.');
        } else {
          crownWinner(0);
        }
      }
      if (fxKey === 'theme')           cycleTheme();
      if (fxKey === 'land-money')      wheelLandingPulse('money');
      if (fxKey === 'land-bad')        wheelLandingPulse('bad');
      if (fxKey === 'bonus-reveal')    dramaticLetterReveal(['R','S','T','E']);
      if (flow === 'gameover') {
        state.totals = state.totals.map((_,i)=> [4200, 2800, 1500, 0][i] || 0);
        showGameOver();
      }
      if (flow === 'trophy') {
        if (!state.totals.some(v=>v)) state.totals = [4200,2800,1500,0];
        downloadTrophyCard();
        log('PNG download triggered.');
      }
      if (flow === 'tv') {
        document.documentElement.classList.toggle('tv-mode');
        log('TV mode: ' + (document.documentElement.classList.contains('tv-mode') ? 'ON' : 'OFF'));
      }
      if (flow === 'editor') openEditor();
    });

    log('Audit panel ready. Click any button.');
  }
  // Re-fit the gameplay stage whenever its content height changes (phase swaps,
  // banner show/hide, board reveals, font load). Transform-based scaling doesn't
  // change content-box size, so this never loops.
  function observeClassicFit(){
    const stage = document.querySelector('#screen-classic .stage');
    if (!stage || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(() => scheduleClassicFit());
    for (const col of stage.children) ro.observe(col);   // content-height changes (phases)
    ro.observe(document.documentElement);                // viewport size changes
  }
  document.addEventListener('DOMContentLoaded', () => {
    populateV4Selects();applyUrlModes(); setTheme(getTheme()); applyVisualTheme(); bind();
    fitToScreen();
    observeClassicFit();
    window.addEventListener('resize', scheduleFit);
  });
})();
