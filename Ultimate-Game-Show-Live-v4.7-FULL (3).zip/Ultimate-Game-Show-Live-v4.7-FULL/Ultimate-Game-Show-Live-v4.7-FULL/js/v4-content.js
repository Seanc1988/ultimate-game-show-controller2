/* Ultimate Game Show Live V4.7 visual theme registry.
 * Puzzle content is intentionally excluded from this core presentation module.
 */
(function(){
  window.WHEEL_V4_VISUAL_THEMES={
    classic:{label:'Classic Studio',icon:'✦',accent:'#27d9ff',accent2:'#ffd60a',cover:'#058b57',bg:'#071126',art:'radial-gradient(circle at 50% 5%,#134f88 0,transparent 42%),linear-gradient(145deg,#071126,#17092f)'},
    hollywood:{label:'Hollywood · Red Carpet',icon:'★',accent:'#f4d35e',accent2:'#ff4d6d',cover:'#8b1028',bg:'#090909',art:'url("assets/themes/hollywood-background.jpg")',tileArt:'url("assets/themes/hollywood-tile.svg")'},
    halloween:{label:'Halloween · Spooky',icon:'👻',accent:'#ff7b00',accent2:'#b56cff',cover:'#d65b00',bg:'#100619',art:'url("assets/themes/halloween-background.jpg")',tileArt:'url("assets/themes/halloween-tile.png")'},
    christmas:{label:'Christmas',icon:'🎄',accent:'#ec1c24',accent2:'#f6d55c',cover:'#087f3f',bg:'#17070b',art:'url("assets/themes/christmas-background.jpg")',tileArt:'url("assets/themes/christmas-tile.jfif")'},
    easter:{label:'Easter · Pastel',icon:'🥚',accent:'#ff8fc7',accent2:'#8ce6ff',cover:'#9d77d5',bg:'#17112b',art:'url("assets/themes/easter-background.svg")',tileArt:'url("assets/themes/easter-tile.svg")'},
    winter:{label:'Winter Wonderland',icon:'❄',accent:'#9de8ff',accent2:'#ffffff',cover:'#2879a7',bg:'#061326',art:'url("assets/themes/winter-background.avif")',tileArt:'url("assets/themes/winter-tile.jfif")'},
    fall:{label:'Fall Harvest',icon:'🍁',accent:'#e76f19',accent2:'#f7c948',cover:'#8d3c18',bg:'#1c0b05',art:'url("assets/themes/fall-background.jpg")',tileArt:'url("assets/themes/fall-tile.jfif")'},
    summer:{label:'Summer Sunshine',icon:'☀',accent:'#00d9ff',accent2:'#ffde3b',cover:'#0aa56b',bg:'#061a2b',art:'url("assets/themes/summer-background.svg")',tileArt:'url("assets/themes/summer-tile.svg")'},
    beach:{label:'Tropical Beach',icon:'🌴',accent:'#31e5e0',accent2:'#ffd166',cover:'#078f9c',bg:'#06243a',art:'url("assets/themes/beach-background.svg")',tileArt:'url("assets/themes/beach-tile.svg")'},
    patriotic:{label:'Patriotic',icon:'★',accent:'#e63946',accent2:'#f1faee',cover:'#174e9b',bg:'#07152f',art:'url("assets/themes/patriotic-background.svg")',tileArt:'url("assets/themes/patriotic-tile.svg")'},
    vegas:{label:'Las Vegas',icon:'♦',accent:'#ffd60a',accent2:'#ff2f7f',cover:'#7d163e',bg:'#110617',art:'url("assets/themes/vegas-background.svg")',tileArt:'url("assets/themes/vegas-tile.svg")'}
  };
})();
