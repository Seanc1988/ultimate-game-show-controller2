/* ===== Wheel Game — Phone Buzzer Host =====
 * Standalone module. The game's `state` lives inside an IIFE and is not global,
 * so player data is passed in via configure(). Decoupled from app.js internals;
 * app.js wires callbacks with onBuzz()/onAnswer().
 *
 * Companion page (always-live on GitHub Pages):
 *   https://seanc1988.github.io/ultimate-game-show-controller/
 *
 * Wire protocol (matches wheel-buzzer/index.html):
 *   phone -> host : {type:'hello', player}  {type:'buzz', player}  {type:'game-answer', player, answer}
 *   host -> phone : {type:'state', armed, winnerIdx, players[]}
 *                   {type:'answer-prompt', player, playerName, question}  {type:'answer-clear'}
 */
(function () {
    /* ====================================================================
     PHONE-BUZZER HOST  --  the only line to change if this ever moves.

     Player phones load the buzzer page from here. It is deliberately a
     single constant so the address can be repointed in one edit.

     To move to your own domain (recommended - it makes already-sold
     copies survivable if the host ever changes):
       1. CNAME the domain to the current host.
       2. Change the URL below to the new domain.
       3. Rebuild the ZIP.
     Copies already sold keep pointing at whatever this said when they
     were built, so a CNAME - not a code change - is what protects them.

     An override can also be supplied at runtime without editing this
     file, e.g. index.html?buzzer=https://buzz.example.com/
     ==================================================================== */
  // Public controller hosted for Ultimate Game Show Live. This lets phones join
  // through cellular data or any Wi-Fi while the game itself runs locally.
  let COMPANION_URL = 'https://seanc1988.github.io/ultimate-game-show-controller/';
  try {
    const savedController = localStorage.getItem('wheelRemoteControllerUrl');
    if (savedController && /^https?:\/\//i.test(savedController)) COMPANION_URL = savedController;
  } catch (_) {}
  // Optional runtime override: ?buzzer=https://... (trailing slash added if missing)
  try {
    var _q = new URLSearchParams(location.search).get('buzzer');
    if (_q && /^https?:\/\//i.test(_q)) {
          COMPANION_URL = _q.replace(/\/?$/, '/');
    }
  } catch (_) {}



  /* ====================================================================
     PHONE-BUZZER CONNECTION SETTINGS

     Phones talk to the host over a direct WebRTC connection. Where a
     direct link is impossible - guest Wi-Fi that isolates devices, or a
     phone on mobile data while the laptop is on Wi-Fi - the TURN relay
     below carries the traffic instead.

     TURN credentials are Gamyfy's Metered relay account. They are TURN
     credentials only, NOT the Metered secret key, which must never ship
     inside a download. If the monthly quota runs out, create a new
     credential at dashboard.metered.ca -> Developers and replace the
     username/credential values below.
     ==================================================================== */
  var BUZZER_RTC = { iceServers: [
    { urls: 'stun:stun.relay.metered.ca:80' },
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'turn:global.relay.metered.ca:80',
      username: 'ba88079176616565ef57f408', credential: '2sorAbF4hI8eMjGO' },
    { urls: 'turn:global.relay.metered.ca:80?transport=tcp',
      username: 'ba88079176616565ef57f408', credential: '2sorAbF4hI8eMjGO' },
    { urls: 'turn:global.relay.metered.ca:443',
      username: 'ba88079176616565ef57f408', credential: '2sorAbF4hI8eMjGO' },
    { urls: 'turns:global.relay.metered.ca:443?transport=tcp',
      username: 'ba88079176616565ef57f408', credential: '2sorAbF4hI8eMjGO' }
  ] };

  const B = {
    roomCode: null,
    sessionId: makeToken('session'),
    peer: null,
    excluded: new Set(),
    conns: {},          // playerIdx -> DataConnection
    slotTokens: {},     // stable device binding used during reconnect/rejoin
    armed: false,
    winnerIdx: null,
    players: [],        // [{name, color}]
    onBuzz: null,
    onAnswer: null,
    onSpin: null,
    onPoolSelected: null,
    onPoolDraw: null,
    onBonusCardPick: null,
    onWild: null,
    onProfileUpdate: null,
    onPoolChange: null,
    onReconnect: null,
    poolEnabled: false,
    pool: [],
    assignedSlots: new Set(),
    drawActive: false,
    game: { activePlayer: 0, spinEnabled: false, status: '', started: false },
    heartbeatTimer: null,
    toast: (m) => { try { console.log('[buzzer]', m); } catch (_) {} },
    sfx: null
  };

  /* ---------- helpers ---------- */
  function playerName(idx) { return B.players[idx]?.name || `Player ${idx + 1}`; }
  function playerColor(idx) { return B.players[idx]?.color || '#27d4e8'; }
  function makeRoomCode() { return Math.random().toString(36).slice(2, 6).toUpperCase(); }
  function connectedCount() { return Object.values(B.conns).filter(conn => conn && conn.open).length; }
  function makeToken(prefix='slot') { return prefix + '-' + Math.random().toString(36).slice(2) + Date.now().toString(36); }
  function fieldIdx(d) {
    // accept either `player` (wheel) or `team` (legacy companion) as the index
    const v = Number.isInteger(d.player) ? d.player : d.team;
    return Number.isInteger(v) ? v : null;
  }

  function ensureStyles() {
    if (document.getElementById('wheel-buzzer-styles')) return;
    const css = `
.wbz-modal{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:rgba(4,8,20,.82);backdrop-filter:blur(6px);padding:18px}
.wbz-card{width:min(760px,96vw);max-height:92vh;overflow:auto;background:#0d1430;border:1px solid rgba(120,160,255,.22);border-radius:20px;padding:22px;color:#eaf0ff;box-shadow:0 24px 80px rgba(0,0,0,.6)}
.wbz-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:8px}
.wbz-head h2{margin:0;font-size:22px}
.wbz-head p{margin:6px 0 0;font-size:13px;color:#aab8de;line-height:1.4}
.wbz-close{background:none;border:none;color:#aab8de;font-size:26px;cursor:pointer;line-height:1}
.wbz-room{display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:rgba(120,160,255,.08);border-radius:12px;padding:10px 14px;margin:10px 0}
.wbz-room span{font-size:12px;color:#aab8de;text-transform:uppercase;letter-spacing:1px}
.wbz-room strong{font-size:26px;letter-spacing:4px;color:#ffd34d}
.wbz-room small{flex:1;min-width:160px;font-size:11px;color:#8aa;line-height:1.3}
.wbz-strip{display:flex;justify-content:space-between;align-items:center;font-size:13px;color:#aab8de;margin:6px 2px}
.wbz-strip strong{color:#4ade80;font-size:15px}
.wbz-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:12px 0}
.wbz-qr{background:#0a1024;border:1px solid var(--c,#27d4e8);border-radius:14px;padding:12px;text-align:center}
.wbz-qr-name{font-weight:900;color:var(--c,#27d4e8);text-transform:uppercase;letter-spacing:1px;font-size:14px;margin-bottom:8px}
.wbz-qr-svg{background:#fff;border-radius:8px;padding:6px;display:flex;justify-content:center}
.wbz-qr-svg svg{width:100%;height:auto;max-width:150px}
.wbz-qr-status{margin-top:8px;font-size:12px;font-weight:800;color:#facc15}
.wbz-qr-status.on{color:#4ade80}
.wbz-url{margin-top:6px;font-size:9px;color:#5a6a8a;word-break:break-all}
.wbz-actions{display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap;margin-top:8px}
.wbz-remote{margin:14px 0 8px;padding:12px;border:1px solid rgba(255,214,10,.35);border-radius:12px;background:rgba(255,214,10,.06)}
.wbz-remote label{display:block;color:#ffd34d;font-size:12px;font-weight:900;margin-bottom:6px}.wbz-remote-row{display:flex;gap:8px}.wbz-remote input{flex:1;min-width:0;margin:0;padding:10px;border-radius:8px;border:1px solid #48618f;background:#050b20;color:#fff}.wbz-remote button{border:0;border-radius:8px;padding:9px 12px;background:#ffd34d;color:#151000;font-weight:900}.wbz-remote small{display:block;margin-top:6px;color:#aab8de}
.wbz-btn{border:none;border-radius:12px;padding:11px 18px;font-weight:800;font-size:14px;cursor:pointer}
.wbz-btn.primary{background:linear-gradient(180deg,#3b82f6,#1d4ed8);color:#fff}
.wbz-btn.ghost{background:rgba(255,255,255,.08);color:#dbe6ff}
.wbz-btn:disabled{opacity:.45;cursor:not-allowed}
.wbz-pool-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin:12px 0}.wbz-pool-person{padding:9px 11px;border:1px solid #385078;border-radius:9px;background:#080e22}.wbz-pool-person.off{opacity:.48}.wbz-pool-person.picked{border-color:#4ade80;color:#8bffad}.wbz-pool-qr{max-width:230px;margin:12px auto;background:#fff;padding:10px;border-radius:12px}.wbz-pool-qr svg{width:100%;height:auto}
.wbz-tools{margin-top:16px;border-top:1px solid #31456f;padding-top:14px}.wbz-tool-row{display:grid;grid-template-columns:minmax(130px,1fr) auto auto auto auto;align-items:center;gap:7px;padding:8px;border:1px solid #263b65;border-radius:10px;margin:7px 0}.wbz-tool-state{font-size:12px;font-weight:900;color:#facc15}.wbz-tool-state.on{color:#4ade80}@media(max-width:620px){.wbz-tool-row{grid-template-columns:1fr 1fr}.wbz-tool-row strong{grid-column:1/-1}}
.wbz-banner{position:fixed;left:50%;top:14%;transform:translateX(-50%);z-index:10000;background:var(--c,#27d4e8);color:#04122a;font-weight:900;font-size:clamp(20px,4vw,34px);letter-spacing:2px;text-transform:uppercase;padding:14px 30px;border-radius:16px;box-shadow:0 14px 50px rgba(0,0,0,.5);animation:wbzPop .25s ease}
@keyframes wbzPop{from{transform:translateX(-50%) scale(.7);opacity:0}to{transform:translateX(-50%) scale(1);opacity:1}}`;
    const el = document.createElement('style');
    el.id = 'wheel-buzzer-styles';
    el.textContent = css;
    document.head.appendChild(el);
  }

  function updateBadge() {
    const count = connectedCount();
    const badge = document.getElementById('wbzConnCount');
    if (badge) badge.textContent = `${count}/${B.players.length}`;
    const ready = document.getElementById('wbzReadyText');
    if (ready) ready.textContent = count === 0 ? 'Waiting for phones to join'
      : count < B.players.length ? 'Some phones live' : 'All phones live';
    B.players.forEach((_, idx) => {
      const st = document.querySelector(`.wbz-qr[data-player="${idx}"] .wbz-qr-status`);
      if (!st) return;
      const on = !!B.conns[idx];
      st.textContent = on ? 'Connected' : 'Waiting';
      st.classList.toggle('on', on);
    });
  }

  function broadcastState() {
    const payload = {
      type: 'state',
      armed: B.armed,
      winnerIdx: B.winnerIdx,
      excluded: [...B.excluded],
      players: B.players.map(p => p.name)
      , activePlayer: B.game.activePlayer
      , spinEnabled: !!B.game.spinEnabled
      , status: B.game.status || ''
      , category: B.game.category || ''
      , puzzle: B.game.puzzle || ''
      , advantages: B.game.advantages || []
      , gameStarted: !!B.game.started
      , wildCardCounts: Array.isArray(B.game.wildCardCounts) ? B.game.wildCardCounts : []
      , wildArmedPlayer: Number.isInteger(B.game.wildArmedPlayer) ? B.game.wildArmedPlayer : null
      , canGuess: !!B.game.canGuess
      , sessionId: B.sessionId
    };
    const sent = new Set();
    Object.values(B.conns).concat(B.pool.map(p=>p.conn)).forEach(conn => { try { if (conn && conn.open && !sent.has(conn)) { sent.add(conn); conn.send(payload); } } catch (_) {} });
  }

  function ensureHost() {
    if (B.peer || typeof Peer === 'undefined') return !!B.peer;
    B.roomCode = makeRoomCode();
    try {
      B.peer = new Peer('wheel-' + B.roomCode, { debug: 0, config: BUZZER_RTC });
    } catch (err) {
      B.toast('Phone buzzers could not start'); return false;
    }
    B.peer.on('open', () => {
      B.toast(`Buzzer room ${B.roomCode} ready`); updateBadge();
      clearInterval(B.heartbeatTimer);
      B.heartbeatTimer = setInterval(() => {
        const now = Date.now();
        const seen = new Set();
        Object.values(B.conns).concat(B.pool.map(p=>p.conn)).forEach(c => {
          if (!c || !c.open || seen.has(c)) return;
          seen.add(c);
          if (c._wheelLastSeen && now - c._wheelLastSeen > 35000) { try { c.close(); } catch (_) {} return; }
          try { c.send({type:'ping',ts:now}); } catch (_) { try { c.close(); } catch (_) {} }
        });
      }, 8000);
    });
    B.peer.on('error', err => B.toast('Buzzer host error: ' + (err?.type || 'unknown')));
    B.peer.on('disconnected', () => { try { if (!B.peer.destroyed) B.peer.reconnect(); } catch (_) {} });
    B.peer.on('connection', conn => {
      let boundIdx = null;
      conn._wheelLastSeen = Date.now();
      conn.on('data', data => {
        if (!data || typeof data !== 'object') return;
        conn._wheelLastSeen = Date.now();
        if (data.type === 'ping') { try { conn.send({type:'pong',ts:data.ts||Date.now()}); } catch (_) {} return; }
        if (data.type === 'pong') return;
        if (Number(data.protocolVersion) !== 47 || (data.sessionId && data.sessionId !== B.sessionId)) { try { conn.send({type:'session-reset',sessionId:B.sessionId}); } catch (_) {} setTimeout(()=>{try{conn.close()}catch(_){}},80); return; }
        const idx = fieldIdx(data);
        if (data.type === 'pool-signup' && B.poolEnabled) {
          const name = String(data.name || '').trim().slice(0, 30);
          const token = String(data.token || conn.peer || '').slice(0, 80);
          const avatar = String(data.avatar || '⭐').slice(0, 180000);
          if (!name || !token) return;
          let entrant = B.pool.find(p => p.token === token);
          if (!entrant) {
            entrant = { token, name, avatar, conn, selected:false };
            B.pool.push(entrant);
          } else {
            entrant.name = name; entrant.avatar = avatar; entrant.conn = conn;
          }
          try { conn.send({type:'pool-confirmed',sessionId:B.sessionId}); } catch (_) {}
          updatePoolModal();
          if (typeof B.onPoolChange === 'function') B.onPoolChange();
          return;
        }
        if (data.type === 'hello' && idx !== null && idx >= 0 && idx < B.players.length) {
          if (boundIdx !== null && boundIdx !== idx) return;
          const token = String(data.bindToken || '').slice(0,100);
          const expected = B.slotTokens[idx] || '';
          if (expected && token && token !== expected) return;
          if (!expected && token) B.slotTokens[idx] = token;
          if (B.conns[idx] && B.conns[idx] !== conn) { try { B.conns[idx].close(); } catch (_) {} }
          boundIdx = idx;
          B.conns[idx] = conn;
          try { conn.send({ type: 'ack', room: B.roomCode, player:idx, bindToken:B.slotTokens[idx] || token, sessionId:B.sessionId }); } catch (_) {}
          updateBadge(); broadcastState();
          if(typeof B.onReconnect==='function')B.onReconnect(idx);
          B.toast(`${playerName(idx)} buzzer connected`);
        }
        if (data.type === 'buzz' && idx === boundIdx && B.conns[idx] === conn) handleBuzz(idx);
        if (data.type === 'spin' && idx === boundIdx && B.conns[idx] === conn &&
            B.game.spinEnabled && idx === B.game.activePlayer) {
          B.game.spinEnabled = false;
          try { conn.send({type:'spin-accepted',gestureId:data.gestureId||null,sessionId:B.sessionId}); } catch (_) {}
          broadcastState();
          if (typeof B.onSpin === 'function') B.onSpin(idx, {
            velocity: Math.max(0, Math.min(3, Number(data.velocity) || 0)),
            duration: Math.max(2400, Math.min(8500, Number(data.duration) || 5200)),
            turns: Math.max(3, Math.min(10, Number(data.turns) || 5))
          });
        }
        if (data.type === 'game-answer' && idx === boundIdx && B.conns[idx] === conn && idx === B.winnerIdx && typeof B.onAnswer === 'function') {
          B.onAnswer({ player: idx, answer: String(data.answer || '') });
        }
        if (data.type === 'bonus-card-pick' && idx === boundIdx && B.conns[idx] === conn &&
            idx === B.game.activePlayer && typeof B.onBonusCardPick === 'function') B.onBonusCardPick(idx, Number(data.card));
        if (data.type === 'use-wild' && idx === boundIdx && B.conns[idx] === conn &&
            idx === B.game.activePlayer && typeof B.onWild === 'function') B.onWild(idx);
        if (data.type === 'profile-update' && idx === boundIdx && B.conns[idx] === conn) {
          const name=String(data.name||'').trim().replace(/[<>]/g,'').slice(0,30);
          const avatar=String(data.avatar||'⭐').slice(0,180000);
          if(name&&typeof B.onProfileUpdate==='function')B.onProfileUpdate(idx,{name,avatar});
        }
      });
      conn.on('close', () => {
        Object.entries(B.conns).forEach(([i, saved]) => { if (saved === conn) delete B.conns[i]; });
        B.pool.forEach(p => { if (p.conn === conn) p.conn = null; });
        updateBadge(); broadcastState();
        updatePoolModal();
        if (typeof B.onPoolChange === 'function') B.onPoolChange();
      });
    });
    return true;
  }

  function joinUrl(idx) {
    if (!B.slotTokens[idx]) B.slotTokens[idx] = makeToken('player'+(idx+1));
    const params = new URLSearchParams({
      room: B.roomCode || '', p: idx, name: playerName(idx), color: playerColor(idx), bind:B.slotTokens[idx], sid:B.sessionId
    });
    return `${COMPANION_URL}?${params.toString()}`;
  }

  function qrMarkup(url) {
    if (typeof qrcode === 'undefined') return `<div class="wbz-url">${url}</div>`;
    const qr = qrcode(0, 'M');
    qr.addData(url); qr.make();
    return qr.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
  }

  function poolUrl(){
    if (!B.poolEnabled || !ensureHost()) return '';
    const params = new URLSearchParams({room:B.roomCode || '',mode:'pool',sid:B.sessionId});
    return `${COMPANION_URL}?${params.toString()}`;
  }

  function updatePoolModal(){
    const list = document.getElementById('wbzPoolList');
    const count = document.getElementById('wbzPoolCount');
    if (count) count.textContent = String(B.pool.length);
    if (!list) return;
    list.innerHTML = B.pool.length ? B.pool.map(p => `<div class="wbz-pool-person ${p.selected?'picked':(p.conn&&p.conn.open?'':'off')}">${p.selected?'✓ ':''}${p.name}${p.conn&&p.conn.open?'':' · offline'}</div>`).join('') : '<div class="wbz-pool-person off">Waiting for sign-ups…</div>';
  }

  function drawContestants(fillAll){
    if(B.drawActive){B.toast('The contestant selector is already spinning.');return;}
    const openSlots = B.players.map((_,i)=>i).filter(i=>!B.assignedSlots.has(i));
    const available = B.pool.filter(p=>!p.selected && p.conn && p.conn.open);
    if (!openSlots.length) { B.toast('All contestant positions are already filled.'); return; }
    if (!available.length) { B.toast('No connected, unselected names are available.'); return; }
    const howMany = fillAll ? Math.min(openSlots.length,available.length) : 1;
    B.drawActive=true;
    let n=0;
    const chooseNext=()=>{
      if(n>=howMany){
        const allFilled=B.assignedSlots.size>=B.players.length;
        if(allFilled) B.pool.filter(p=>!p.selected&&p.conn&&p.conn.open).forEach(p=>{try{p.conn.send({type:'not-selected'})}catch(_){}});
        B.drawActive=false;
        if(typeof B.onPoolChange==='function')B.onPoolChange();
        return;
      }
      const candidates=available.map(p=>p.name),at=Math.floor(Math.random()*available.length),entrant=available.splice(at,1)[0],slot=openSlots[n++];
      if(typeof B.onPoolDraw==='function')B.onPoolDraw({slot,winner:entrant.name,avatar:entrant.avatar||'⭐',names:candidates,duration:5000});
      setTimeout(()=>{
        entrant.selected=true;B.assignedSlots.add(slot);B.slotTokens[slot]=entrant.token;B.players[slot]=Object.assign({},B.players[slot],{name:entrant.name,avatar:entrant.avatar||'⭐'});
        try{entrant.conn.send({type:'selected',player:slot,playerName:entrant.name,color:playerColor(slot),bindToken:entrant.token,avatar:entrant.avatar||'⭐'})}catch(_){}
        updatePoolModal();
        if(typeof B.onPoolSelected==='function')B.onPoolSelected([{slot,name:entrant.name,avatar:entrant.avatar||'⭐'}]);
        chooseNext();
      },5100);
    };
    chooseNext();
  }

  function showPoolManager(){
    ensureStyles();
    B.poolEnabled = true;
    // A new contestant draw is pre-game state. Selected phones remain on their
    // assignment screen until the host explicitly starts the intro.
    B.game.started = false;
    broadcastState();
    if (!ensureHost()) return;
    document.getElementById('wbzPoolModal')?.remove();
    const url = poolUrl();
    const modal=document.createElement('div');modal.className='wbz-modal';modal.id='wbzPoolModal';
    modal.innerHTML=`<div class="wbz-card"><div class="wbz-head"><div><h2>🎟 Contestant Sign-Up Pool</h2><p>Show this QR code before the game. Guests enter their names, then you draw contestants fairly.</p></div><button class="wbz-close" data-pool-close>&times;</button></div><div class="wbz-room"><span>Room Code</span><strong>${B.roomCode}</strong><small><span id="wbzPoolCount">${B.pool.length}</span> people currently in the pool</small></div><div class="wbz-pool-qr">${qrMarkup(url)}</div><div class="wbz-url">${url}</div><div class="wbz-pool-list" id="wbzPoolList"></div><div class="wbz-actions"><button class="wbz-btn ghost" id="wbzPoolDisable">Disable Sign-Ups</button><button class="wbz-btn ghost" id="wbzPoolReset">Reset Draw · Keep Names</button><button class="wbz-btn ghost" id="wbzPoolClear">Start Fresh</button><button class="wbz-btn primary" id="wbzPoolDrawOne">Draw Next Contestant</button><button class="wbz-btn primary" id="wbzPoolFill">Fill All Open Spots</button></div></div>`;
    document.body.appendChild(modal);updatePoolModal();
    modal.querySelectorAll('[data-pool-close]').forEach(b=>b.onclick=()=>modal.remove());
    modal.querySelector('#wbzPoolDrawOne').onclick=()=>drawContestants(false);
    modal.querySelector('#wbzPoolFill').onclick=()=>drawContestants(true);
    modal.querySelector('#wbzPoolDisable').onclick=()=>{B.poolEnabled=false;modal.remove();if(typeof B.onPoolChange==='function')B.onPoolChange();};
    modal.querySelector('#wbzPoolReset').onclick=()=>{B.pool.forEach(p=>{p.selected=false;try{if(p.conn&&p.conn.open)p.conn.send({type:'pool-reopened'})}catch(_){}});B.assignedSlots.clear();updatePoolModal();if(typeof B.onPoolChange==='function')B.onPoolChange();};
    modal.querySelector('#wbzPoolClear').onclick=()=>{
      B.sessionId=makeToken('session');
      const all=new Set(Object.values(B.conns).concat(B.pool.map(p=>p.conn)));
      all.forEach(c=>{try{if(c&&c.open)c.send({type:'session-reset',sessionId:B.sessionId})}catch(_){}setTimeout(()=>{try{c&&c.close()}catch(_){}},120)});
      B.pool=[];B.conns={};B.slotTokens={};B.assignedSlots.clear();B.armed=false;B.winnerIdx=null;
      const freshUrl=poolUrl(),qr=modal.querySelector('.wbz-pool-qr'),urlEl=modal.querySelector('.wbz-url');if(qr)qr.innerHTML=qrMarkup(freshUrl);if(urlEl)urlEl.textContent=freshUrl;
      updatePoolModal();updateBadge();if(typeof B.onPoolChange==='function')B.onPoolChange();
    };
  }

  function showQR() {
    ensureStyles();
    if (typeof Peer === 'undefined') { B.toast('Phone buzzers need an internet connection.'); return; }
    if (!ensureHost()) return;
    document.getElementById('wbzModal')?.remove();

    const cards = B.players.map((p, idx) => {
      const on = !!B.conns[idx];
      return `<div class="wbz-qr" data-player="${idx}" style="--c:${playerColor(idx)}">
        <div class="wbz-qr-name">${p.name}</div>
        <div class="wbz-qr-svg">${qrMarkup(joinUrl(idx))}</div>
        <div class="wbz-qr-status ${on ? 'on' : ''}">${on ? 'Connected' : 'Waiting'}</div>
        <div class="wbz-url">${joinUrl(idx)}</div>
        <div class="wbz-actions"><button class="wbz-btn ghost" data-show-player="${idx}">Large QR</button><button class="wbz-btn ghost" data-sync-player="${idx}">Force Sync</button></div>
      </div>`;
    }).join('');

    const modal = document.createElement('div');
    modal.className = 'wbz-modal';
    modal.id = 'wbzModal';
    modal.innerHTML = `<div class="wbz-card">
      <div class="wbz-head">
        <div>
          <h2>📱 Phone Buzzers</h2>
          <p>Each player scans their QR code once. Phones stay in the room all game and rejoin with the same link if a page closes. Needs internet on every device.</p>
        </div>
        <button class="wbz-close" data-wbz-close>&times;</button>
      </div>
      <div class="wbz-room">
        <span>Room Code</span><strong>${B.roomCode}</strong>
        <small>Players can type this code on the buzzer page if a QR scan fails.</small>
      </div>
      <div class="wbz-strip">
        <span id="wbzReadyText">${connectedCount() ? 'Phones connected' : 'Waiting for phones to join'}</span>
        <strong id="wbzConnCount">${connectedCount()}/${B.players.length}</strong>
      </div>
      <div class="wbz-remote"><label>REMOTE PHONE CONTROLLER URL (OPTIONAL)</label><div class="wbz-remote-row"><input id="wbzRemoteUrl" type="url" value="${COMPANION_URL.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"><button id="wbzSaveRemote" type="button">Save & Refresh QR Codes</button></div><small>Use a public HTTPS controller URL to let contestants join from cellular data or any Wi-Fi. Leave the local address for same-network play.</small></div>
      <div class="wbz-grid">${cards}</div>
      <div class="wbz-actions">
        <button class="wbz-btn ghost" id="wbzTroubleshoot">Troubleshooting</button>
        <button class="wbz-btn ghost" data-wbz-close>Done</button>
      </div>
    </div>`;
    document.body.appendChild(modal);
    modal.querySelectorAll('[data-wbz-close]').forEach(b => b.addEventListener('click', () => modal.remove()));
    modal.querySelectorAll('[data-show-player]').forEach(b=>b.onclick=()=>showPlayerQR(Number(b.dataset.showPlayer)));
    modal.querySelectorAll('[data-sync-player]').forEach(b=>b.onclick=()=>forceSync(Number(b.dataset.syncPlayer)));
    modal.querySelector('#wbzTroubleshoot').onclick=showTroubleshooter;
    modal.querySelector('#wbzSaveRemote')?.addEventListener('click', () => {
      const value = modal.querySelector('#wbzRemoteUrl')?.value.trim();
      if (!value || !/^https?:\/\//i.test(value)) { B.toast('Enter a complete http:// or https:// controller URL.'); return; }
      COMPANION_URL = value.replace(/\/+$/, '');
      try { localStorage.setItem('wheelRemoteControllerUrl', COMPANION_URL); } catch (_) {}
      modal.remove(); showQR(); B.toast('Controller URL saved. QR codes refreshed.');
    });
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
    updateBadge();
  }

  function forceSync(idx){
    const conn=B.conns[idx];
    if(!conn||!conn.open){B.toast(`${playerName(idx)} is offline. Show their Large QR to reconnect.`);return false;}
    try{conn.send({type:'ack',room:B.roomCode,player:idx,bindToken:B.slotTokens[idx]||''});broadcastState();B.toast(`${playerName(idx)} force-synced`);return true}catch(_){return false}
  }

  function kickPlayer(idx){
    const conn=B.conns[idx];
    if(conn){try{conn.send({type:'kicked'});conn.close()}catch(_){}}
    delete B.conns[idx];delete B.slotTokens[idx];updateBadge();broadcastState();
    B.toast(`${playerName(idx)} cleared. Generate a new QR to rebind.`);
  }

  function showPlayerQR(idx){
    ensureStyles();if(!ensureHost()||!B.players[idx])return;
    document.getElementById('wbzPlayerQR')?.remove();
    const modal=document.createElement('div');modal.className='wbz-modal';modal.id='wbzPlayerQR';
    modal.innerHTML=`<div class="wbz-card" style="max-width:520px;text-align:center"><div class="wbz-head"><div><h2>${playerName(idx)} · Rejoin</h2><p>Scan this code on the player's phone. It is bound only to Player ${idx+1}.</p></div><button class="wbz-close">&times;</button></div><div class="wbz-pool-qr" style="max-width:390px">${qrMarkup(joinUrl(idx))}</div><div class="wbz-url">${joinUrl(idx)}</div><div class="wbz-actions"><button class="wbz-btn primary" data-sync>Force Sync</button><button class="wbz-btn ghost" data-close>Done</button></div></div>`;
    document.body.appendChild(modal);modal.querySelector('.wbz-close').onclick=()=>modal.remove();modal.querySelector('[data-close]').onclick=()=>modal.remove();modal.querySelector('[data-sync]').onclick=()=>forceSync(idx);
  }

  function showTroubleshooter(){
    ensureStyles();if(!ensureHost())return;document.getElementById('wbzToolsModal')?.remove();
    const rows=B.players.map((p,i)=>`<div class="wbz-tool-row"><strong>${p.name} · Player ${i+1}</strong><span class="wbz-tool-state ${B.conns[i]&&B.conns[i].open?'on':''}">${B.conns[i]&&B.conns[i].open?'CONNECTED':'OFFLINE'}</span><button class="wbz-btn ghost" data-tool-sync="${i}">Sync</button><button class="wbz-btn ghost" data-tool-qr="${i}">QR</button><button class="wbz-btn ghost" data-tool-kick="${i}">Kick/Rebind</button></div>`).join('');
    const modal=document.createElement('div');modal.className='wbz-modal';modal.id='wbzToolsModal';modal.innerHTML=`<div class="wbz-card"><div class="wbz-head"><div><h2>🛠 Phone Troubleshooting</h2><p>Force the current state, display a single-player QR, or clear a stuck slot.</p></div><button class="wbz-close">&times;</button></div><div class="wbz-tools">${rows}</div><div class="wbz-actions"><button class="wbz-btn primary" data-sync-all>Force Sync All</button><button class="wbz-btn ghost" data-close>Done</button></div></div>`;
    document.body.appendChild(modal);modal.querySelector('.wbz-close').onclick=()=>modal.remove();modal.querySelector('[data-close]').onclick=()=>modal.remove();modal.querySelector('[data-sync-all]').onclick=()=>{broadcastState();B.toast('All connected phones force-synced')};modal.querySelectorAll('[data-tool-sync]').forEach(b=>b.onclick=()=>forceSync(Number(b.dataset.toolSync)));modal.querySelectorAll('[data-tool-qr]').forEach(b=>b.onclick=()=>showPlayerQR(Number(b.dataset.toolQr)));modal.querySelectorAll('[data-tool-kick]').forEach(b=>b.onclick=()=>{kickPlayer(Number(b.dataset.toolKick));modal.remove();showTroubleshooter()});
  }

  function startGameIntro(){
    B.game.started=true;
    const payload={type:'game-intro'};const sent=new Set();
    Object.values(B.conns).concat(B.pool.map(p=>p.conn)).forEach(c=>{try{if(c&&c.open&&!sent.has(c)){sent.add(c);c.send(payload)}}catch(_){}});
  }

  function showBuzzBanner(idx) {
    document.querySelectorAll('.wbz-banner').forEach(el => el.remove());
    const b = document.createElement('div');
    b.className = 'wbz-banner';
    b.style.setProperty('--c', playerColor(idx));
    b.textContent = `${playerName(idx)} buzzed in!`;
    document.body.appendChild(b);
    setTimeout(() => b.remove(), 1500);
  }

  function handleBuzz(idx) {
    if (!B.armed || B.winnerIdx !== null) return;        // first-buzz lockout
    if (!Number.isInteger(idx) || idx < 0 || idx >= B.players.length || B.excluded.has(idx)) return;
    B.winnerIdx = idx;
    B.armed = false;
    showBuzzBanner(idx);
    if (B.sfx && typeof B.sfx.buzzer === 'function') { try { B.sfx.buzzer(); } catch (_) {} }
    broadcastState();
    if (typeof B.onBuzz === 'function') B.onBuzz(idx);
  }

  function arm(excluded = []) {
    B.excluded = new Set(excluded);
    if (!ensureHost()) return false;
    B.armed = true;
    B.winnerIdx = null;
    broadcastState();
    return true;
  }
  function disarm() { B.armed = false; broadcastState(); }
  function reset() { B.armed = false; B.winnerIdx = null; broadcastState(); }

  function sendAnswerPrompt(idx, opts = {}) {
    const conn = B.conns[idx];
    if (!conn || !conn.open) return false;
    conn.send(Object.assign({ type: 'answer-prompt', player: idx, playerName: playerName(idx) }, opts));
    return true;
  }
  function clearAnswerPrompt(idx) {
    if (idx === undefined) { Object.values(B.conns).forEach(c => { try { if (c.open) c.send({ type: 'answer-clear' }); } catch (_) {} }); return; }
    const conn = B.conns[idx];
    if (conn && conn.open) conn.send({ type: 'answer-clear' });
  }

  window.WheelBuzzer = {
    configure(opts = {}) {
      if (Array.isArray(opts.players)) B.players = opts.players;
      if (typeof opts.toast === 'function') B.toast = opts.toast;
      if (opts.sfx) B.sfx = opts.sfx;
      broadcastState();
    },
    onBuzz(cb) { B.onBuzz = cb || null; },
    onAnswer(cb) { B.onAnswer = cb || null; },
    onSpin(cb) { B.onSpin = cb || null; },
    onPoolSelected(cb) { B.onPoolSelected = cb || null; },
    onPoolDraw(cb) { B.onPoolDraw = cb || null; },
    onBonusCardPick(cb) { B.onBonusCardPick = cb || null; },
    onWild(cb) { B.onWild = cb || null; },
    onProfileUpdate(cb) { B.onProfileUpdate = cb || null; },
    onPoolChange(cb) { B.onPoolChange = cb || null; },
    onReconnect(cb) { B.onReconnect = cb || null; },
    setGameState(next = {}) { B.game = Object.assign({}, B.game, next); broadcastState(); },
    showQR, showPoolManager, showPlayerQR, showTroubleshooter, startGameIntro, arm, disarm, reset,
    getPoolState() { return {enabled:B.poolEnabled,url:poolUrl(),count:B.pool.length}; },
    sendAnswerPrompt, clearAnswerPrompt,
    sendToPlayer(idx, data) { const c=B.conns[idx]; if(c&&c.open){try{c.send(data)}catch(_){}} },
    broadcastNotice(data) { Object.values(B.conns).forEach(c=>{if(c&&c.open){try{c.send(Object.assign({type:'special-notice'},data))}catch(_){}}}); },
    clearNotice() { Object.values(B.conns).forEach(c=>{if(c&&c.open){try{c.send({type:'special-clear'})}catch(_){}}}); },
    connectedCount,
    isConnected(idx) { const c = B.conns[idx]; return !!(c && c.open); },
    get winnerIdx() { return B.winnerIdx; },
    get roomReady() { return !!B.peer; }
  };
})();
