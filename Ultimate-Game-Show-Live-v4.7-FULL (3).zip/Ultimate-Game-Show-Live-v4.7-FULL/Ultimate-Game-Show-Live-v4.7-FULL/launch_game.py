#!/usr/bin/env python3
"""Start the local game server and open the host on Spotify-compatible loopback."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import os
import socket
import threading
import webbrowser

PORT = 8765

def lan_ip():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"
    finally:
        sock.close()

os.chdir(os.path.dirname(os.path.abspath(__file__)))
address = lan_ip()
url = f"http://127.0.0.1:{PORT}/index.html"
server = ThreadingHTTPServer(("0.0.0.0", PORT), SimpleHTTPRequestHandler)
threading.Timer(0.8, lambda: webbrowser.open(url)).start()
print("\nInteractive Wheel Game is running.")
print(f"Host address: {url}")
print(f"Local network address: http://{address}:{PORT}/index.html")
print("Keep this window open during the game. Press Ctrl+C after the event.\n")
try:
    server.serve_forever()
except KeyboardInterrupt:
    print("\nGame server stopped.")
finally:
    server.server_close()
