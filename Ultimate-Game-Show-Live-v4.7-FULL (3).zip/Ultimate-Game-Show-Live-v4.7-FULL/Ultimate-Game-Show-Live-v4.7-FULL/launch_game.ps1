$ErrorActionPreference = "Stop"
$port = 8765
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$udp = New-Object System.Net.Sockets.UdpClient
try {
  $udp.Connect("8.8.8.8", 80)
  $ip = ([System.Net.IPEndPoint]$udp.Client.LocalEndPoint).Address.ToString()
} catch {
  $ip = "127.0.0.1"
} finally { $udp.Dispose() }

$mime = @{
  ".html"="text/html; charset=utf-8"; ".js"="text/javascript; charset=utf-8";
  ".css"="text/css; charset=utf-8"; ".txt"="text/plain; charset=utf-8";
  ".mp3"="audio/mpeg"; ".m4a"="audio/mp4"; ".mp4"="video/mp4"; ".png"="image/png";
  ".jpg"="image/jpeg"; ".jpeg"="image/jpeg"; ".avif"="image/avif"; ".svg"="image/svg+xml"; ".ico"="image/x-icon"
}
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Any, $port)
$listener.Start()
$url = "http://127.0.0.1:${port}/index.html"
Start-Process $url
Write-Host "`nInteractive Wheel Game is running."
Write-Host "Host address: $url"
Write-Host "Local network address: http://${ip}:${port}/index.html"
Write-Host "Keep this window open during the game. Press Ctrl+C after the event.`n"

try {
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $stream = $client.GetStream()
      $reader = New-Object System.IO.StreamReader($stream, [Text.Encoding]::ASCII, $false, 1024, $true)
      $line = $reader.ReadLine()
      while (($header = $reader.ReadLine()) -ne "" -and $null -ne $header) {}
      $target = if ($line -match '^GET\s+([^\s]+)') { $Matches[1] } else { "/" }
      $pathOnly = ([Uri]"http://local$target").AbsolutePath
      if ($pathOnly -eq "/") { $pathOnly = "/index.html" }
      $relative = [Uri]::UnescapeDataString($pathOnly.TrimStart('/')).Replace('/', [IO.Path]::DirectorySeparatorChar)
      $full = [IO.Path]::GetFullPath((Join-Path $root $relative))
      if (-not $full.StartsWith([IO.Path]::GetFullPath($root)) -or -not (Test-Path $full -PathType Leaf)) {
        $body = [Text.Encoding]::UTF8.GetBytes("Not Found")
        $head = "HTTP/1.1 404 Not Found`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
      } else {
        $body = [IO.File]::ReadAllBytes($full)
        $ext = [IO.Path]::GetExtension($full).ToLowerInvariant()
        $type = if ($mime.ContainsKey($ext)) { $mime[$ext] } else { "application/octet-stream" }
        $head = "HTTP/1.1 200 OK`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
      }
      $headBytes = [Text.Encoding]::ASCII.GetBytes($head)
      $stream.Write($headBytes, 0, $headBytes.Length)
      $stream.Write($body, 0, $body.Length)
    } catch {} finally { $client.Close() }
  }
} finally { $listener.Stop() }
