/* Ultimate Game Show Live V4.7 optional theme puzzle add-ons.
 * These packs are never part of the everyday core pool unless the host selects
 * a theme. Additional packs may use the same window.UGSL_THEME_PACKS contract.
 */
(function(){
  const themes = {
    christmas:['CHRISTMAS TREE LIGHTS','UGLY SWEATER PARTY','MISTLETOE MEMORIES','NORTH POLE WORKSHOP','GINGERBREAD HOUSE','CHRISTMAS MORNING','SLEIGH BELL PARADE','CANDY CANE LANE','STOCKINGS BY THE FIRE','HOLIDAY COOKIE SWAP'],
    halloween:['HAUNTED HOUSE TOUR','TRICK OR TREAT BAG','MONSTER MASH PARTY','GLOWING JACK O LANTERN','FOGGY GRAVEYARD','WITCHES BREW','COSTUME CONTEST','MIDNIGHT GHOST STORY','CARAMEL APPLE BAR','CREEPY CORN MAZE'],
    easter:['EASTER EGG HUNT','BUNNY HOP DANCE','PASTEL PARTY TABLE','CHOCOLATE BUNNY','SPRING FLOWER BASKET','EASTER SUNDAY BRUNCH','DECORATED EGGS','JELLY BEAN JAR','BUNNY TRAIL','SUNRISE CELEBRATION'],
    winter:['SNOW DAY ADVENTURE','COZY FIREPLACE','WINTER WONDERLAND','HOT COCOA BAR','ICE SKATING PARTY','SNOW COVERED CABIN','WOOL MITTENS','FROZEN LAKE','SLEDDING HILL','FROSTY WINDOW'],
    spring:['SPRING GARDEN PARTY','APRIL SHOWERS','BLOOMING TULIPS','FRESH CUT FLOWERS','RAINBOW AFTER RAIN','PICNIC IN THE PARK','BUTTERFLY GARDEN','WARM SPRING BREEZE','BIRDSONG MORNING','GREEN MEADOW'],
    summer:['SUMMER ROAD TRIP','BACKYARD BARBECUE','POOL PARTY PLAYLIST','LEMONADE STAND','FIREWORKS AT DUSK','BAREFOOT AFTERNOON','SUNNY VACATION','WATERMELON SLICE','COUNTY FAIR NIGHT','LONG SUMMER DAY'],
    fall:['AUTUMN LEAF PILE','PUMPKIN PATCH','COZY FLANNEL SHIRT','APPLE CIDER DONUTS','HARVEST FESTIVAL','SCENIC FALL DRIVE','CORN MAZE CHALLENGE','BONFIRE NIGHT','CRISP MORNING AIR','THANKSGIVING TABLE'],
    hollywood:['RED CARPET PREMIERE','MOVIE STAR ENTRANCE','DIRECTORS CHAIR','BLOCKBUSTER HIT','AWARD SHOW SPEECH','SILVER SCREEN LEGEND','STUDIO BACKLOT','CAMERA READY SMILE','FAMOUS MOVIE QUOTE','OPENING NIGHT'],
    beach:['TROPICAL BEACH PARTY','COLORFUL UMBRELLA','OCEANFRONT BOARDWALK','SUNSET BONFIRE','SEASHELL COLLECTION','BEACH VOLLEYBALL','FROZEN PINA COLADA','MESSAGE IN A BOTTLE','PERFECT WAVE','VACATION MODE'],
    patriotic:['STARS AND STRIPES','FOURTH OF JULY PARADE','HOMETOWN HERO','FIREWORKS FINALE','AMERICAN ROAD TRIP','RED WHITE AND BLUE','BACKYARD COOKOUT','SMALL TOWN MAIN STREET','NATIONAL ANTHEM','LIBERTY BELL'],
    eighties:['CASSETTE MIXTAPE','ARCADE HIGH SCORE','NEON LEG WARMERS','VIDEO RENTAL STORE','ROLLER RINK PARTY','BOOM BOX RADIO','MALL FOOD COURT','BIG HAIR BAND','SATURDAY CARTOONS','RETRO DANCE FLOOR'],
    nineties:['MIXTAPE FOR MY CRUSH','ROLLERBLADE RACE','VIDEO GAME CARTRIDGE','FLANNEL FASHION','DIAL UP INTERNET','SITCOM MARATHON','BOY BAND POSTER','POCKET DIGITAL PET','RADICAL SKATEBOARD','BLOCKBUSTER WEEKEND'],
    two_thousands:['FLIP PHONE CAMERA','BURNED MIX CD','REALITY SHOW FINALE','LOW RISE JEANS','SOCIAL MEDIA PROFILE','RINGTONE DOWNLOAD','DANCE CLUB ANTHEM','ONLINE AWAY MESSAGE','RED CARPET FASHION','WEEKEND MOVIE RENTAL'],
    music:['SING ALONG CHORUS','DANCE FLOOR ANTHEM','ACOUSTIC GUITAR','FRONT ROW TICKETS','ENCORE PERFORMANCE','HIT RECORD','DRUM SOLO','KARAOKE FAVORITE','CONCERT LIGHT SHOW','RADIO COUNTDOWN'],
    movies:['OPENING CREDIT SCENE','SURPRISE PLOT TWIST','POPCORN AND CANDY','ACTION MOVIE HERO','ROMANTIC COMEDY','MIDNIGHT PREMIERE','FAMOUS FILM LINE','SPECIAL EFFECTS','MOVIE MARATHON','FINAL CREDITS'],
    television:['PRIME TIME PREMIERE','SEASON FINALE','LAUGH TRACK','REMOTE CONTROL','LIVE NEWS DESK','REALITY SHOW REUNION','FAVORITE SITCOM','COMMERCIAL BREAK','GAME SHOW HOST','STREAMING MARATHON'],
    sports:['CHAMPIONSHIP TROPHY','GAME WINNING SHOT','HOME TEAM CROWD','OVERTIME THRILLER','STADIUM HOT DOG','VICTORY LAP','HALFTIME SHOW','ALL STAR PLAYER','PLAYOFF BRACKET','SUDDEN DEATH FINISH'],
    food:['SECRET FAMILY RECIPE','SUNDAY DINNER','CHOCOLATE LAVA CAKE','LOADED CHEESE FRIES','FRESH BAKED BREAD','BREAKFAST BUFFET','SPICY CHICKEN WINGS','ICE CREAM SUNDAE','BACKYARD GRILL','MIDNIGHT SNACK'],
    travel:['PASSPORT ADVENTURE','WINDOW SEAT VIEW','TROPICAL GETAWAY','MOUNTAIN ROAD TRIP','HISTORIC CITY TOUR','PACKED SUITCASE','AIRPORT DEPARTURE','SCENIC TRAIN RIDE','WEEKEND ESCAPE','BUCKET LIST JOURNEY'],
    vegas:['JACKPOT WINNER','CASINO FLOOR LIGHTS','LUCKY NUMBER SEVEN','VEGAS SHOWGIRL','HIGH ROLLER SUITE','NEON BOULEVARD','WINNING STREAK','POKER FACE','SPINNING SLOT MACHINE','MIDNIGHT ON THE STRIP'],
    wedding:['FIRST DANCE SONG','WEDDING CAKE CUTTING','BEAUTIFUL BRIDE','GRAND ENTRANCE','FLOWER BOUQUET','HAPPILY EVER AFTER','CEREMONY ARCH','TOAST TO THE COUPLE','DANCE FLOOR MOMENT','SPARKLER SENDOFF'],
    school:['FIRST DAY OF SCHOOL','SCIENCE FAIR PROJECT','SCHOOL SPIRIT RALLY','LUNCHROOM TABLE','HONOR ROLL STUDENT','FIELD TRIP BUS','GRADUATION DAY','HOMEWORK ASSIGNMENT','CLASSROOM PET','RECESS CHAMPION'],
    family:['FAMILY GAME NIGHT','SUNDAY AFTERNOON','GROUP PHOTO','SECRET HANDSHAKE','FAMILY VACATION','BIRTHDAY TRADITION','BACKYARD FUN','FAVORITE STORY','HOLIDAY REUNION','HOME SWEET HOME'],
    superheroes:['SECRET IDENTITY','HEROIC RESCUE','SUPER POWER','MASKED CRUSADER','EPIC BATTLE','HIDDEN HEADQUARTERS','TRUSTY SIDEKICK','CITY SKYLINE','POWERFUL VILLAIN','VICTORY FOR JUSTICE'],
    decades:['ROARING TWENTIES','SWINGING SIXTIES','DISCO SEVENTIES','AWESOME EIGHTIES','RADICAL NINETIES','YOUTH CULTURE','FASHION FLASHBACK','TIME CAPSULE','RETRO RADIO','THROWBACK PARTY']
  };
  const labels={christmas:'Christmas',halloween:'Halloween',easter:'Easter',winter:'Winter',spring:'Spring',summer:'Summer',fall:'Fall',hollywood:'Hollywood',beach:'Beach',patriotic:'Patriotic',eighties:'1980s',nineties:'1990s',two_thousands:'2000s',music:'Music',movies:'Movies',television:'Television',sports:'Sports',food:'Food & Drink',travel:'Travel',vegas:'Las Vegas',wedding:'Wedding',school:'School Days',family:'Family Fun',superheroes:'Superheroes',decades:'Decades'};
  function baseCategory(text){
    if(/(PARTY|PARADE|PREMIERE|FINALE|DINNER|BRUNCH|CEREMONY|CONTEST|TOUR|HUNT|FESTIVAL|COOKOUT|REUNION|DAY|NIGHT|MORNING)$/.test(text))return 'EVENT';
    if(/(HOUSE|WORKSHOP|VILLAGE|CABIN|LAKE|HILL|GRAVEYARD|MAZE|BOARDWALK|STORE|COURT|BACKLOT|CITY|STRIP|SCHOOL|HEADQUARTERS)$/.test(text))return 'PLACE / PLACES';
    if(/(CAKE|BREAD|FRIES|WINGS|SUNDAE|SNACK|COLADA|CHOCOLATE|CIDER|COOKIES|RECIPE|DONUTS|WATERMELON)$/.test(text))return 'FOOD & DRINK';
    if(/(HOST|HERO|VILLAIN|BRIDE|STUDENT|CHAMPION|PLAYER|SHOWGIRL|LEGEND)$/.test(text))return 'PERSON / PEOPLE';
    return 'THING / THINGS';
  }
  const packs={};
  Object.keys(themes).forEach(key=>{
    packs[key]=themes[key].map((core,ci)=>{
      const rootCat=baseCategory(core);
      return {id:`theme-${key}-${ci+1}`,cat:rootCat,text:core.toUpperCase(),diff:ci<4?'easy':ci<8?'med':'hard',theme:key};
    });
  });
  // Curated general play replaces the old adjective/noun combinator. That old
  // generator could create category mistakes such as “Beyond the Happy
  // Bracelet” under Place. These are deliberately authored phrases instead.
  const general=[
    ['PLACE / PLACES','GRAND CENTRAL STATION','med'],['PLACE / PLACES','THE GREAT SMOKY MOUNTAINS','med'],['PLACE / PLACES','A QUIET CORNER BOOKSTORE','easy'],
    ['THING / THINGS','A HANDWRITTEN THANK YOU NOTE','easy'],['THING / THINGS','NOISE CANCELLING HEADPHONES','med'],['THING / THINGS','A VINTAGE POCKET WATCH','easy'],
    ['PHRASE','BETTER LATE THAN NEVER','easy'],['PHRASE','THE BEST IS YET TO COME','easy'],['PHRASE','READ BETWEEN THE LINES','med'],
    ['EVENT','A SURPRISE BIRTHDAY PARTY','easy'],['EVENT','THE OPENING CEREMONY','med'],['EVENT','A SOLD OUT CONCERT','easy'],
    ['FOOD & DRINK','HOMEMADE MACARONI AND CHEESE','easy'],['FOOD & DRINK','FRESH STRAWBERRY SHORTCAKE','easy'],['FOOD & DRINK','ROASTED GARLIC MASHED POTATOES','med'],
    ['AROUND THE HOUSE','A BASKET OF CLEAN LAUNDRY','easy'],['AROUND THE HOUSE','THE JUNK DRAWER','easy'],['AROUND THE HOUSE','A COMFORTABLE READING CHAIR','easy'],
    ['OCCUPATION','EMERGENCY ROOM NURSE','easy'],['OCCUPATION','HIGH SCHOOL PRINCIPAL','easy'],['OCCUPATION','WILDLIFE PHOTOGRAPHER','med'],
    ['PERSON / PEOPLE','MY FAVORITE COUSIN','easy'],['PERSON / PEOPLE','A GENEROUS NEXT DOOR NEIGHBOR','med'],['FICTIONAL CHARACTER','THE WIZARD OF OZ','easy'],
    ['BEFORE & AFTER','BOOK CLUB SANDWICH','med'],['BEFORE & AFTER','MOVIE STAR FRUIT','hard'],['SAME NAME','WASHINGTON SQUARE','med'],
    ['SAME LETTER','PERFECTLY PLUMP PUMPKINS','med'],['SAME LETTER','BRIGHT BLUE BALLOONS','easy'],['WHAT ARE YOU DOING?','PACKING FOR A WEEKEND TRIP','easy']
  ];
  /* The legacy curated general rows are retained below only as source notes;
   * the active everyday library is js/core-puzzles.js. */
  // Short, public-domain lyric fragments only. Song Lyrics never receives
  // generated text; the validator in app.js also requires verifiedLyrics.
  const lyrics=[
    ['AMAZING GRACE HOW SWEET THE SOUND','Amazing Grace'],['OH SAY CAN YOU SEE','The Star-Spangled Banner'],['MY COUNTRY TIS OF THEE','America'],
    ['JINGLE BELLS JINGLE BELLS','Jingle Bells'],['SILENT NIGHT HOLY NIGHT','Silent Night'],['DECK THE HALLS WITH BOUGHS OF HOLLY','Deck the Halls'],
    ['ROW ROW ROW YOUR BOAT','Row Row Row Your Boat'],['TWINKLE TWINKLE LITTLE STAR','Twinkle Twinkle Little Star'],['MARY HAD A LITTLE LAMB','Mary Had a Little Lamb'],
    ['YANKEE DOODLE WENT TO TOWN','Yankee Doodle'],['HOME HOME ON THE RANGE','Home on the Range'],['TAKE ME OUT TO THE BALL GAME','Take Me Out to the Ball Game']
  ];
  window.UGSL_THEME_PACKS=Object.freeze(Object.fromEntries(Object.entries(packs).map(([key,items])=>[key,Object.freeze(items.map(Object.freeze))])));
  window.UGSL_THEME_LABELS=Object.freeze(labels);
  window.WHEEL_V4_THEME_NIGHTS=window.UGSL_THEME_PACKS;
  window.WHEEL_V4_THEME_LABELS=window.UGSL_THEME_LABELS;
  window.WHEEL_V4_VISUAL_THEMES={
    classic:{label:'Classic Studio',icon:'✦',accent:'#27d9ff',accent2:'#ffd60a',cover:'#058b57',bg:'#071126',art:'radial-gradient(circle at 50% 5%,#134f88 0,transparent 42%),linear-gradient(145deg,#071126,#17092f)'},
    hollywood:{label:'Hollywood · Red Carpet',icon:'★',accent:'#f4d35e',accent2:'#ff4d6d',cover:'#8b1028',bg:'#090909',art:'url("assets/themes/hollywood-background.jpg")',tileArt:'url("assets/themes/hollywood-tile.svg")'},
    halloween:{label:'Halloween · Spooky',icon:'👻',accent:'#ff7b00',accent2:'#b56cff',cover:'#d65b00',bg:'#100619',art:'url("assets/themes/halloween-background.jpg")',tileArt:'url("assets/themes/halloween-tile.png")'},
    christmas:{label:'Christmas',icon:'🎄',accent:'#ec1c24',accent2:'#f6d55c',cover:'#087f3f',bg:'#17070b',art:'url("assets/themes/christmas-background.jpg")',tileArt:'url("assets/themes/christmas-tile.jfif")'},
    easter:{label:'Easter · Pastel',icon:'🥚',accent:'#ff8fc7',accent2:'#8ce6ff',cover:'#9d77d5',bg:'#17112b',art:'url("assets/themes/easter-background.svg")',tileArt:'url("assets/themes/easter-tile.svg")'},
    winter:{label:'Winter Wonderland',icon:'❄',accent:'#9de8ff',accent2:'#ffffff',cover:'#2879a7',bg:'#061326',art:'url("assets/themes/winter-background.avif")',tileArt:'url("assets/themes/winter-tile.jfif")'},
    fall:{label:'Fall Harvest',icon:'🍁',accent:'#e76f19',accent2:'#f7c948',cover:'#8d3c18',bg:'#1c0b05',art:'url("assets/themes/fall-background.jpg")',tileArt:'url("assets/themes/fall-tile.jfif")'},
    summer:{label:'Summer Sunshine',icon:'☀',accent:'#00d9ff',accent2:'#ffde3b',cover:'#0aa56b',bg:'#061a2b',art:'url("assets/themes/summer-background.svg")',tileArt:'url("assets/themes/summer-tile.svg")'},
    beach:{label:'Tropical Beach',icon:'🌴',accent:'#31e5e0',accent2:'#ffd166',cover:'#078f9c',bg:'#06243a',art:'url("assets/themes/beach-background.svg")',tileArt:'url("assets/themes/beach-tile.svg")'},
    patriotic:{label:'Patriotic',icon:'★',accent:'#e63946',accent2:'#f1faee',cover:'#174e9b',bg:'#07152f',art:'url("assets/themes/patriotic-background.svg")',tileArt:'url("assets/themes/patriotic-tile.svg")'},
    vegas:{label:'Las Vegas',icon:'♦',accent:'#ffd60a',accent2:'#ff2f7f',cover:'#7d163e',bg:'#110617',art:'url("assets/themes/vegas-background.svg")',tileArt:'url("assets/themes/vegas-tile.svg")'}
  };
})();
