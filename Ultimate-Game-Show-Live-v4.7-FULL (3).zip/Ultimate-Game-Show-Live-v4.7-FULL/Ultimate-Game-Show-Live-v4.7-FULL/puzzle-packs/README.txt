📦 PUZZLE PACKS
================

These optional banks and add-ons extend the 1,000-puzzle everyday library.
Mix-and-match to fit your event!

  holiday-pack.txt     — Christmas, Hanukkah, Kwanzaa & New Year
  kids-pack.txt        — easy puzzles for ages 6–12
  office-pack.txt      — corporate buzzwords & workplace humor
  classroom-pack.txt   — geography, science, history, literature
  movie-night-pack.txt — famous movies, characters, quotes

HOW TO LOAD A PACK
------------------
1. Open the game (index.html)
2. Click "Edit puzzles & slices" on the title screen
3. Open the "Puzzles" section
4. Click 📋 Add Pack (.txt)
5. Pick a pack file from this folder
6. The puzzles are ADDED to your bank (nothing is erased)
7. Click Save

Tip: Load several packs in a row to build a big themed bank.
Your bank is saved in the browser for next time.

CREATE YOUR OWN
---------------
Each line follows this format:

  CATEGORY | PHRASE IN ALL CAPS

Example:
  MOVIE | THE WIZARD OF OZ
  PHRASE | BETTER LATE THAN NEVER

Lines starting with # are ignored. Save as a .txt file with UTF-8
encoding, then load it with 📋 Add Pack (.txt).

BACKING UP YOUR WHOLE SETUP
---------------------------
Use Export in the editor to save your entire configuration
(puzzles + players + wheel + rules) as a .json file. Use Import
to restore it later or move it to another computer.



UI AND RECOVERY UPDATE
Balanced preset: 5 rounds, $5,000 bonus, no Mystery or $5,000 wheel wedge.
High-Stakes preset: 10 rounds, $50,000 bonus, Mystery jackpot. Save to apply.
Hint price: $300 plus $150 for each distinct revealed letter type. One hint
per player per regular round; the current price is shown before purchase.
Same Letter: main words share an initial; connecting words may differ.
Before & After: expressions share a word or word part; compounds may split.
Movie Night is for teens/adults and includes mature-film references, familiar
quotes and shortened titles. Preview every pack for your group.
Resume now preserves bonus/qualifier puzzles, revealed letters, finalists,
lockouts and earned qualifier seats. Click Start Toss-Up to resume reveals.
Phones reconnect separately. Use the same browser, folder and settings.
Ordinary turn timers restart on Resume; current bonus duels have no solve countdown.
