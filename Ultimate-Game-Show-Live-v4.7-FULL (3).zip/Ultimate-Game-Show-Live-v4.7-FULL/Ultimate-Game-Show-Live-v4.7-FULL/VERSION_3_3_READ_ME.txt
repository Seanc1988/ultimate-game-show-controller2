ULTIMATE GAME SHOW LIVE — VERSION 3.3

This is the screenshot-correction build. V3.2 remains separate and unchanged.

Latest live-show corrections:
- Toss-up Correct/Wrong judging opens immediately after a buzz.
- Solve recovers from stale dialog locks and explains blocked actions.
- The intro preloads a lighter 720p/30 audience video.
- Room applause replaces the old cheer recording.
- Audience board letters, contestant names, banks, and totals are larger.
- The signup QR is sized for across-the-room viewing.
- Game Setup includes an optional birthday/special announcement.
- The audience display celebrates the champion and final winnings.

The host screen was rebuilt for landscape laptops after reviewing screenshots
captured at approximately 1366 × 648. It now uses a large two-level layout:
wheel and puzzle above, full-width host controls below, and a compact player
strip at the bottom.

The bonus prize is now a true mystery envelope. The amount is selected and
stored but is not displayed until the host judges the final puzzle. The host
can use Judge Early Solve before the countdown ends.

Five optional 15-puzzle theme-night collections are included: 1980s, Beach,
Holiday, Christmas and Halloween. The editor can replace the current list or
append a theme pack. Copy AI Puzzle Prompt provides a no-key-required workflow
for generating additional properly sized packs with ChatGPT.

Use V3.3_TEST_CHECKLIST.txt before live use.
